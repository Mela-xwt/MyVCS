use super::*;
use pack::Snapshot;
use transport::Connection;
use wire::{Message, expect_ok, recv, send};

mod delta;
mod pack;
mod team;
mod transport;
mod wire;

fn branch_ref(branch: &str) -> Result<String> {
    let name = format!("refs/heads/{branch}");
    validate_ref(&name)?;
    Ok(name)
}
fn remote_name(name: &str) -> Result<()> {
    if name.contains('/') {
        bail!("remote name must be one component");
    }
    validate_ref(&format!("refs/remotes/{name}/main"))
}

fn send_objects(
    snapshot: &Snapshot,
    r: &mut impl Read,
    w: &mut impl Write,
    mode: wire::Mode,
) -> Result<usize> {
    let mut reader = pack::Counted::new(r);
    let mut writer = pack::Counted::new(w);
    let r = &mut reader;
    let w = &mut writer;
    let ids: Vec<_> = snapshot.entries.keys().cloned().collect();
    let mut missing = BTreeSet::new();
    for batch in ids.chunks(wire::BATCH) {
        send(
            w,
            &Message::Offer {
                ids: batch.to_vec(),
            },
        )?;
        let Message::Missing { ids } = recv(r)? else {
            bail!("expected missing-object batch");
        };
        if ids.len() > batch.len() {
            bail!("invalid missing-object batch");
        }
        for id in ids {
            if !batch.contains(&id) || !missing.insert(id) {
                bail!("unoffered or duplicate requested object");
            }
        }
    }
    let mut pinned = BTreeSet::new();
    if mode == wire::Mode::Thin {
        let candidates = snapshot.base_candidates(&missing);
        send(
            w,
            &Message::Bases {
                ids: candidates.clone(),
            },
        )?;
        let Message::Pinned { ids } = recv(r)? else {
            bail!("expected pinned-base acknowledgement");
        };
        if ids.len() > candidates.len() {
            bail!("too many confirmed bases");
        }
        for id in ids {
            if !candidates.contains(&id) || !pinned.insert(id) {
                bail!("invalid or duplicate confirmed base");
            }
        }
    }
    send(w, &Message::Pack)?;
    let stats = snapshot.write(w, &missing, mode, &pinned)?;
    send(w, &Message::End)?;
    if std::env::var("MYVCS_TRACE_TRANSFER").as_deref() == Ok("1") {
        eprintln!(
            "MYVCS_TRANSFER {}",
            serde_json::json!({"mode":mode.capability(),"objects":missing.len(),"pinned_bases":pinned.len(),"sent_bytes":w.bytes,"received_bytes":r.bytes,"pack":stats})
        );
    }
    Ok(missing.len())
}

fn receive_objects(
    repo: &Repo,
    r: &mut impl Read,
    w: &mut impl Write,
    mode: wire::Mode,
) -> Result<ReceiveTransaction> {
    let mut offered = BTreeSet::new();
    let mut missing = BTreeSet::new();
    let mut tx = repo.begin_receive(ReceiveLimits {
        max_objects: wire::MAX_OBJECTS + delta::MAX_BASES,
        ..ReceiveLimits::default()
    })?;
    let mut pinned = BTreeSet::new();
    let mut bases_requested = false;
    loop {
        match recv(r)? {
            Message::Offer { ids } => {
                if bases_requested {
                    bail!("offers after base confirmation are forbidden");
                }
                if ids.is_empty() || ids.len() > wire::BATCH {
                    bail!("invalid object batch size");
                }
                for id in &ids {
                    validate_oid(id)?;
                    if !offered.insert(id.clone()) || offered.len() > wire::MAX_OBJECTS {
                        bail!("duplicate or excessive offered objects");
                    }
                }
                let absent = repo.with_repo_lock(|repo| {
                    let mut absent = Vec::new();
                    for id in ids {
                        // A corrupt existing object is an error, never an affirmative 'have'.
                        if repo.object_path(&id)?.exists() {
                            repo.read_blob_resolved(&id)?;
                        } else {
                            absent.push(id);
                        }
                    }
                    Ok(absent)
                })?;
                missing.extend(absent.iter().cloned());
                send(w, &Message::Missing { ids: absent })?;
            }
            Message::Bases { ids } if mode == wire::Mode::Thin && !bases_requested => {
                bases_requested = true;
                if ids.len() > delta::MAX_BASES {
                    bail!("delta base count limit exceeded");
                }
                let mut requested = BTreeSet::new();
                for id in &ids {
                    validate_oid(id)?;
                    if !offered.contains(id)
                        || missing.contains(id)
                        || !requested.insert(id.clone())
                    {
                        bail!("base was not acknowledged as present or was duplicated");
                    }
                }
                repo.with_repo_lock(|_| {
                    for id in ids {
                        if tx.pin_base(&id, delta::MAX_BYTES)? {
                            pinned.insert(id);
                        }
                    }
                    Ok(())
                })?;
                send(
                    w,
                    &Message::Pinned {
                        ids: pinned.iter().cloned().collect(),
                    },
                )?;
            }
            Message::Pack => {
                if mode == wire::Mode::Thin && !bases_requested {
                    bail!("missing base confirmation phase");
                }
                break;
            }
            _ => bail!("expected object offer or pack"),
        }
    }
    pack::read(r, &mut tx, &missing, mode, &pinned)?;
    if !matches!(recv(r)?, Message::End) {
        bail!("missing pack end marker");
    }
    Ok(tx)
}

fn advertisement(c: &mut Connection) -> Result<(String, BTreeMap<String, String>, wire::Mode)> {
    let mode = wire::Mode::configured()?;
    send(&mut c.writer, &wire::hello(mode))?;
    if wire::check_hello(recv(&mut c.reader)?)? != mode {
        bail!("server changed required pack capability");
    }
    let Message::Refs { head, refs } = recv(&mut c.reader)? else {
        bail!("expected reference advertisement");
    };
    branch_ref(&head)?;
    for (name, id) in &refs {
        validate_ref(name)?;
        validate_oid(id)?;
        if !name.starts_with("refs/heads/") {
            bail!("unexpected advertised namespace");
        }
    }
    Ok((head, refs, mode))
}

impl Repo {
    pub fn remote_list(&self) -> Result<BTreeMap<String, String>> {
        let path = self.meta.join("remotes.json");
        self.check_internal_path(&path)?;
        if !path.exists() {
            return Ok(BTreeMap::new());
        }
        let config: BTreeMap<String, String> = serde_json::from_str(&self.read_metadata(&path)?)?;
        for (name, url) in &config {
            remote_name(name)?;
            transport::Address::parse(url)?;
        }
        Ok(config)
    }

    /// Mutations acquire their own repo lock, like receive/update_ref.
    pub fn remote_configure(&self, action: &str, name: &str, url: Option<&str>) -> Result<()> {
        remote_name(name)?;
        if let Some(url) = url {
            transport::Address::parse(url)?;
        }
        self.with_repo_lock(|repo| {
            let mut config = repo.remote_list()?;
            match action {
                "add" if !config.contains_key(name) => {
                    config.insert(name.into(), url.context("missing URL")?.into());
                }
                "set-url" if config.contains_key(name) => {
                    config.insert(name.into(), url.context("missing URL")?.into());
                }
                "remove" if config.contains_key(name) => {
                    config.remove(name);
                }
                _ => bail!("invalid remote operation, duplicate remote, or remote not found"),
            }
            let raw = serde_json::to_vec_pretty(&config)?;
            if raw.len() > repo.limits.metadata_bytes {
                bail!("remote configuration too large");
            }
            repo.atomic_write(&repo.meta.join("remotes.json"), &raw)
        })
    }

    fn remote_url(&self, name: &str) -> Result<String> {
        remote_name(name)?;
        self.remote_list()?
            .remove(name)
            .context("remote not found; use remote add")
    }

    pub fn push(&self, remote: &str, branch: Option<&str>) -> Result<()> {
        let branch = branch
            .map(str::to_owned)
            .or_else(|| self.current_branch_name())
            .context("push requires a branch")?;
        let name = branch_ref(&branch)?;
        let (new, snapshot) = self.with_repo_lock(|repo| {
            let new = repo.read_ref(&name)?.context("cannot push unborn branch")?;
            let snapshot = Snapshot::create(repo, &new)?;
            Ok((new, snapshot))
        })?;
        let tracking = format!("refs/remotes/{remote}/{branch}");
        let tracking_old = self.with_repo_lock(|repo| repo.read_ref(&tracking))?;
        let mut c = Connection::open(&self.remote_url(remote)?)?;
        let (_, refs, mode) = advertisement(&mut c)?;
        let expected = refs.get(&name).cloned();
        // The server repeats the ancestry check and CAS under its publication lock.
        send(
            &mut c.writer,
            &Message::Push {
                branch: branch.clone(),
                expected,
                new: new.clone(),
            },
        )?;
        expect_ok(&mut c.reader)?;
        let count = send_objects(&snapshot, &mut c.reader, &mut c.writer, mode)?;
        expect_ok(&mut c.reader).context("push not acknowledged; it may have committed: fetch and inspect the remote tip before retrying")?;
        self.with_repo_lock(|repo| {
            repo.apply_local_changes_locked(
                &[RefChange {
                    name: tracking,
                    expected: tracking_old,
                    new: Some(new.clone()),
                }],
                "push tracking refresh",
            )
        })
        .context("remote push succeeded; local tracking CAS failed, fetch to refresh")?;
        println!("pushed {remote}/{branch} {new} ({count} objects)");
        Ok(())
    }

    // One selected branch per fetch; all ancestry is transferred, never shallow.
    pub fn fetch(&self, remote: &str, branch: Option<&str>) -> Result<(String, Option<String>)> {
        let mut c = Connection::open(&self.remote_url(remote)?)?;
        let (head, refs, mode) = advertisement(&mut c)?;
        let branch = branch
            .map(str::to_owned)
            .or_else(|| self.current_branch_name())
            .unwrap_or(head.clone());
        let name = branch_ref(&branch)?;
        let tip = refs.get(&name).cloned();
        if tip.is_none() && branch != head {
            bail!("remote branch does not exist");
        }
        let tracking = format!("refs/remotes/{remote}/{branch}");
        let expected = self.with_repo_lock(|repo| repo.read_ref(&tracking))?;
        send(
            &mut c.writer,
            &Message::Fetch {
                branch: branch.clone(),
                tip: tip.clone(),
            },
        )?;
        expect_ok(&mut c.reader)?;
        if let Some(id) = &tip {
            let tx = receive_objects(self, &mut c.reader, &mut c.writer, mode)?;
            expect_ok(&mut c.reader)?;
            tx.commit_fetch(RefUpdate {
                name: tracking.clone(),
                expected,
                new: id.clone(),
                allow_non_fast_forward: true,
            })?;
        } else {
            self.with_repo_lock(|repo| {
                repo.atomic_write(
                    &repo.meta.join("FETCH_HEAD"),
                    format!("\t{tracking}\n").as_bytes(),
                )
            })?;
        }
        println!(
            "fetched {remote}/{branch} {}",
            tip.as_deref().unwrap_or("(unborn)")
        );
        Ok((branch, tip))
    }

    pub fn pull(&self, remote: &str, branch: Option<&str>, ff_only: bool) -> Result<()> {
        self.require_worktree()?;
        let (_, tip) = self.fetch(remote, branch)?;
        let Some(tip) = tip else {
            return Ok(());
        };
        self.with_repo_lock(|repo| repo.integrate_fetched(&tip, ff_only))
            .context("fetch succeeded; local integration failed (downloaded history is retained)")
    }

    fn integrate_fetched(&self, tip: &str, ff_only: bool) -> Result<()> {
        self.require_worktree()?;
        if self.current_ref()?.is_none() {
            bail!("pull requires an attached local branch");
        }
        if self.read_merge_head()?.is_some() || !self.read_merge_conflicts()?.is_empty() {
            bail!("merge already in progress");
        }
        let index = self.read_index()?;
        if !index.entries.is_empty() || !index.removed.is_empty() {
            bail!("staged changes; commit or unstage before pull");
        }
        let current = self.head_tree()?;
        self.validate_closure(tip)?;
        let target = self.read_commit(tip)?.tree;
        for (name, oid) in &current {
            let path = self.work_path(name)?;
            if !path.is_file() || hex_sha256_file(&path)? != *oid {
                bail!("local changes would be overwritten: {name}");
            }
        }
        // Conservative collision preflight, including file/directory and case aliases.
        // Reject structural transitions in stage 1, before any file is touched.
        for name in target.keys() {
            let path = self
                .work_path(name)
                .with_context(|| format!("unsafe path or file/directory conflict: {name}"))?;
            if !current.contains_key(name) && path.exists() {
                bail!("untracked path would be overwritten: {name}");
            }
            let mut parent = path.parent();
            while let Some(p) = parent {
                if p == self.root {
                    break;
                }
                if p.exists() && !p.is_dir() {
                    bail!("file/directory conflict: {name}");
                }
                parent = p.parent();
            }
            if current
                .keys()
                .any(|p| p != name && p.eq_ignore_ascii_case(name))
            {
                bail!("case-only path transition requires manual checkout");
            }
        }
        match self.head_commit_id()? {
            None => {
                let prepared = self.prepare_head_commit_locked(tip, "pull initial branch")?;
                self.restore_tree(&current, &target)?;
                if let Some(p) = prepared {
                    self.publish_refs_locked(p)?;
                } else {
                    self.update_head_to_commit(tip)?;
                }
                self.write_index(&Index::default())
            }
            Some(head) => {
                if ff_only && !self.is_ancestor(&head, tip)? && !self.is_ancestor(tip, &head)? {
                    bail!("pull --ff-only refuses divergent history");
                }
                self.merge_fast_forward_only(tip)
            }
        }
    }

    pub fn clone_remote(url: &str, destination: &Path, branch: Option<&str>) -> Result<()> {
        transport::Address::parse(url)?;
        // Never merge a clone into an existing directory, even an empty one.
        fs::create_dir(destination)
            .context("clone destination must not exist and its parent must exist")?;
        let repo = Repo::init_at(destination, false, true)?;
        repo.remote_configure("add", "origin", Some(url))?;
        let selected = if let Some(branch) = branch {
            branch.to_owned()
        } else {
            let mut c = Connection::open(url)?;
            let (head, _, _) = advertisement(&mut c)?;
            send(&mut c.writer, &Message::End)?;
            expect_ok(&mut c.reader)?;
            head
        };
        let name = branch_ref(&selected)?;
        repo.with_repo_lock(|repo| repo.set_head_locked(&format!("ref: {name}"), "clone HEAD"))?;
        repo.pull("origin", Some(&selected), true)?;
        repo.set_upstream(Some(&selected), Some(&format!("origin/{selected}")))?;
        println!("cloned into {}", destination.display());
        Ok(())
    }

    pub fn serve(root: &Path, repository: &str, read_only: bool) -> Result<()> {
        let _deadline = transport::ServerDeadline::start()?;
        transport::repository_name(repository)?;
        let root = fs::canonicalize(root).context("invalid server repository root")?;
        let path = root.join(repository);
        no_symlinks(&root, &path)?;
        let actual = fs::canonicalize(&path)?;
        if !actual.starts_with(&root) || actual == root {
            bail!("repository is outside allowed root");
        }
        let repo = Repo::open(actual)?;
        if !repo.bare {
            bail!("SSH service requires a bare repository");
        }
        let mut r = std::io::stdin().lock();
        let mut w = std::io::stdout().lock();
        let result = repo.serve_session(&mut r, &mut w, read_only);
        if let Err(e) = &result {
            let _ = send(
                &mut w,
                &Message::Error {
                    message: format!("{e:#}").chars().take(4096).collect(),
                },
            );
        }
        result
    }

    fn serve_session(&self, r: &mut impl Read, w: &mut impl Write, read_only: bool) -> Result<()> {
        self.serve_team_session(r, w, read_only)
    }
}
