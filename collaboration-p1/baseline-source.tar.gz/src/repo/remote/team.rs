use super::*;

fn public_ref(name: &str) -> Result<()> {
    validate_ref(name)?;
    if !name.starts_with("refs/heads/") && !name.starts_with("refs/tags/") {
        bail!("remote reference must be refs/heads/... or refs/tags/...");
    }
    Ok(())
}
fn expanded(name: &str) -> Result<String> {
    let full = if name.starts_with("refs/") {
        name.into()
    } else {
        branch_ref(name)?
    };
    public_ref(&full)?;
    Ok(full)
}
fn advertised(
    c: &mut Connection,
    version: u32,
) -> Result<(String, BTreeMap<String, String>, wire::Mode)> {
    let mode = wire::Mode::configured()?;
    send(&mut c.writer, &wire::hello_version(mode, version))?;
    let (v, m) = wire::check_hello_version(recv(&mut c.reader)?)
        .context("remote does not support required control protocol v2; upgrade the service")?;
    if v != version || m != mode {
        bail!("remote does not support required control protocol v{version}");
    }
    let Message::Refs { head, refs } = recv(&mut c.reader)? else {
        bail!("expected reference advertisement");
    };
    branch_ref(&head)?;
    if refs.len() > wire::MAX_OBJECTS {
        bail!("excessive reference advertisement");
    }
    for (name, id) in &refs {
        public_ref(name)?;
        validate_oid(id)?;
    }
    Ok((head, refs, mode))
}
fn validate_commands(
    changes: &[RefChange],
    leases: &BTreeMap<String, String>,
    advertisement: &BTreeMap<String, String>,
) -> Result<BTreeSet<String>> {
    if changes.is_empty() || changes.len() > 256 {
        bail!("push requires 1..256 ref commands");
    }
    let mut names = BTreeSet::new();
    let mut allowed = BTreeSet::new();
    for c in changes {
        public_ref(&c.name)?;
        if !names.insert(c.name.to_ascii_lowercase()) {
            bail!("duplicate push reference");
        }
        for id in [&c.expected, &c.new].into_iter().flatten() {
            validate_oid(id)?;
        }
        if advertisement.get(&c.name) != c.expected.as_ref() {
            bail!("reference changed since advertisement or stale lease");
        }
        if c.name.starts_with("refs/tags/")
            && c.expected.is_some()
            && c.new.is_some()
            && c.expected != c.new
        {
            bail!("tag overwrite rejected: tags are immutable");
        }
        if let Some(lease) = leases.get(&c.name) {
            validate_oid(lease)?;
            if c.name.starts_with("refs/tags/") || c.new.is_none() {
                bail!("lease only applies to branch updates");
            }
            if c.expected.as_ref() != Some(lease) {
                bail!("stale force-with-lease");
            }
            allowed.insert(c.name.clone());
        }
        if c.new.is_none() {
            allowed.insert(c.name.clone());
        }
    }
    for name in leases.keys() {
        if !changes.iter().any(|c| &c.name == name) {
            bail!("unused force-with-lease");
        }
    }
    Ok(allowed)
}

impl Repo {
    pub fn push_with_options(
        &self,
        remote: Option<&str>,
        refspecs: &[String],
        set_upstream: bool,
        atomic: bool,
        tags: bool,
        lease_args: &[String],
    ) -> Result<()> {
        let (remote, selected) = self.remote_selection(remote, None)?;
        let current = self.current_branch_name();
        let mut specs = refspecs.to_vec();
        if specs.is_empty() && !tags {
            let local = current
                .clone()
                .context("push requires an attached branch or explicit refspec")?;
            let dest = selected.unwrap_or_else(|| local.clone());
            specs.push(format!("{local}:{dest}"));
        }
        if tags {
            for n in self
                .list_refs()?
                .keys()
                .filter(|n| n.starts_with("refs/tags/"))
            {
                specs.push(format!("{n}:{n}"));
            }
        }
        if specs.is_empty() {
            bail!("no refs to push");
        }
        // Retain old-server interoperability for ordinary same-name one-branch pushes.
        let simple = specs.len() == 1
            && !tags
            && lease_args.is_empty()
            && !atomic
            && specs[0]
                .split_once(':')
                .map(|(a, b)| a == b && !a.starts_with("refs/"))
                .unwrap_or(!specs[0].starts_with("refs/"));
        if simple {
            let local = specs[0].split(':').next().unwrap();
            self.push(&remote, Some(local))?;
            if set_upstream {
                self.set_upstream(Some(local), Some(&format!("{remote}/{local}")))?;
            }
            return Ok(());
        }
        let mut pairs = Vec::new();
        for spec in &specs {
            let (src, dst) = spec.split_once(':').unwrap_or((spec, spec));
            let dst = expanded(dst)?;
            let src = if src.is_empty() {
                None
            } else {
                Some(expanded(src)?)
            };
            if let Some(s) = &src {
                if s.starts_with("refs/tags/") != dst.starts_with("refs/tags/") {
                    bail!("refspec cannot cross heads/tags namespaces");
                }
            }
            pairs.push((src, dst));
        }
        if set_upstream
            && (pairs.len() != 1
                || pairs[0]
                    .0
                    .as_ref()
                    .is_none_or(|s| !s.starts_with("refs/heads/"))
                || !pairs[0].1.starts_with("refs/heads/"))
        {
            bail!("-u requires one branch refspec");
        }
        let mut leases = BTreeMap::new();
        for arg in lease_args {
            let (name, id) = arg
                .split_once(':')
                .context("force-with-lease must be full-reference:expected-oid")?;
            public_ref(name)?;
            validate_oid(id)?;
            if leases.insert(name.to_owned(), id.to_owned()).is_some() {
                bail!("duplicate force-with-lease");
            }
        }
        let (updates, snapshot, tracking_old) = self.with_repo_lock(|repo| {
            let mut updates = Vec::new();
            let mut tips = Vec::new();
            let mut old = BTreeMap::new();
            for (src, dst) in &pairs {
                let new = src
                    .as_deref()
                    .map(|n| {
                        repo.read_ref(n)?
                            .context("local push reference does not exist")
                    })
                    .transpose()?;
                if let Some(id) = &new {
                    tips.push(id.clone());
                }
                if let Some(b) = dst.strip_prefix("refs/heads/") {
                    let n = format!("refs/remotes/{remote}/{b}");
                    old.insert(n.clone(), repo.read_ref(&n)?);
                }
                updates.push((dst.clone(), new));
            }
            Ok((updates, Snapshot::create_many(repo, &tips)?, old))
        })?;
        let mut c = Connection::open(&self.remote_url(&remote)?)?;
        let (_, refs, mode) = advertised(&mut c, 2)?;
        let mut changes = Vec::new();
        for (name, new) in updates {
            let expected = leases
                .get(&name)
                .cloned()
                .or_else(|| refs.get(&name).cloned());
            changes.push(RefChange {
                name,
                expected,
                new,
            });
        }
        validate_commands(&changes, &leases, &refs)?;
        send(
            &mut c.writer,
            &Message::PushRefs {
                changes: changes.clone(),
                leases,
            },
        )?;
        expect_ok(&mut c.reader)?;
        send_objects(&snapshot, &mut c.reader, &mut c.writer, mode)?;
        expect_ok(&mut c.reader).context(
            "push not acknowledged; it may have committed: fetch and inspect before retrying",
        )?;
        self.with_repo_lock(|repo| {
            let tracking: Vec<_> = changes
                .iter()
                .filter_map(|c| {
                    c.name.strip_prefix("refs/heads/").map(|b| RefChange {
                        name: format!("refs/remotes/{remote}/{b}"),
                        expected: tracking_old[&format!("refs/remotes/{remote}/{b}")].clone(),
                        new: c.new.clone(),
                    })
                })
                .filter(|c| c.expected.is_some() || c.new.is_some())
                .collect();
            repo.apply_local_changes_locked(&tracking, "push tracking refresh")
        })
        .context("remote push succeeded; local tracking CAS failed, fetch to refresh")?;
        if set_upstream {
            let (src, dst) = &pairs[0];
            self.set_upstream(
                src.as_deref().and_then(|s| s.strip_prefix("refs/heads/")),
                Some(&format!(
                    "{remote}/{}",
                    dst.strip_prefix("refs/heads/").unwrap()
                )),
            )?;
        }
        println!("pushed {} refs to {remote}", changes.len());
        Ok(())
    }
    pub fn fetch_with_options(
        &self,
        remote: Option<&str>,
        branch: Option<&str>,
        prune: bool,
        tags: bool,
    ) -> Result<(String, Option<String>)> {
        let (remote, selected) = self.remote_selection(remote, branch)?;
        if !prune && !tags {
            return self.fetch(&remote, selected.as_deref());
        }
        if self.format_version()? != 2 {
            bail!(
                "extended fetch requires local format 2; stop old processes and upgrade --quiescent"
            );
        }
        let local = self.refs_snapshot()?;
        let mut c = Connection::open(&self.remote_url(&remote)?)?;
        let (head, refs, mode) = advertised(&mut c, 2)?;
        let branch = selected.unwrap_or(head.clone());
        let full = branch_ref(&branch)?;
        let tip = refs.get(&full).cloned();
        if tip.is_none() && branch != head && !prune {
            bail!("remote branch does not exist");
        }
        let mut wanted = BTreeMap::new();
        if let Some(id) = &tip {
            wanted.insert(full, id.clone());
        }
        if tags {
            for (n, id) in refs.iter().filter(|(n, _)| n.starts_with("refs/tags/")) {
                if local.refs.get(n).is_some_and(|old| old != id) {
                    bail!("local tag conflict; tags are immutable");
                }
                wanted.insert(n.clone(), id.clone());
            }
        }
        let prefix = format!("refs/remotes/{remote}/");
        let mut changes = Vec::new();
        if let Some(id) = &tip {
            let n = format!("{prefix}{branch}");
            changes.push(RefChange {
                name: n.clone(),
                expected: local.refs.get(&n).cloned(),
                new: Some(id.clone()),
            });
        }
        if tags {
            for (n, id) in wanted.iter().filter(|(n, _)| n.starts_with("refs/tags/")) {
                changes.push(RefChange {
                    name: n.clone(),
                    expected: local.refs.get(n).cloned(),
                    new: Some(id.clone()),
                });
            }
        }
        if prune {
            for (n, id) in &local.refs {
                if let Some(b) = n.strip_prefix(&prefix) {
                    if !refs.contains_key(&format!("refs/heads/{b}")) {
                        changes.push(RefChange {
                            name: n.clone(),
                            expected: Some(id.clone()),
                            new: None,
                        });
                    }
                }
            }
        }
        if changes.len() > 256 {
            bail!(
                "fetch reference transaction exceeds 256 refs; reduce tracking/tag set explicitly"
            );
        }
        send(&mut c.writer, &Message::FetchRefs { refs: wanted })?;
        expect_ok(&mut c.reader)?;
        let tx = receive_objects(self, &mut c.reader, &mut c.writer, mode)?;
        expect_ok(&mut c.reader)?;
        if !changes.is_empty() {
            let allowed = changes.iter().map(|c| c.name.clone()).collect();
            tx.commit_many(
                &changes,
                &allowed,
                "local fetch",
                "fetch refs",
                |_, _, _| Ok(()),
            )?;
        }
        println!(
            "fetched {remote}/{branch} {}",
            tip.as_deref().unwrap_or("(absent)")
        );
        Ok((branch, tip))
    }
    pub fn pull_with_options(
        &self,
        remote: Option<&str>,
        branch: Option<&str>,
        ff_only: bool,
    ) -> Result<()> {
        let (r, b) = self.remote_selection(remote, branch)?;
        self.pull(&r, b.as_deref(), ff_only)
    }

    pub(super) fn serve_team_session(
        &self,
        r: &mut impl Read,
        w: &mut impl Write,
        read_only: bool,
    ) -> Result<()> {
        let principal = super::super::policy::principal();
        let actor = principal.as_ref().ok().and_then(|p| p.clone());
        let mut requested = Vec::new();
        let mut op = "session";
        let result = (|| -> Result<()> {
            principal?;
            let (version, mode) = wire::check_hello_version(recv(r)?)?;
            let (head, refs) = self.with_repo_lock(|repo| {
                repo.authorize_read(actor.as_deref())?;
                repo.audit_attempt_locked(actor.as_deref(), "read", &[], "allowed")?;
                let snapshot = repo.refs_snapshot()?;
                let head = snapshot
                    .current_ref()
                    .and_then(|n| n.strip_prefix("refs/heads/"))
                    .context("server HEAD must be symbolic")?
                    .to_owned();
                let refs: BTreeMap<String, String> = snapshot
                    .refs
                    .into_iter()
                    .filter(|(n, _)| {
                        n.starts_with("refs/heads/")
                            || (version == 2 && n.starts_with("refs/tags/"))
                    })
                    .collect();
                Ok((head, refs))
            })?;
            send(w, &wire::hello_version(mode, version))?;
            send(
                w,
                &Message::Refs {
                    head: head.clone(),
                    refs: refs.clone(),
                },
            )?;
            match recv(r)? {
                Message::End => send(w, &Message::Ok),
                Message::Fetch { branch, tip } => {
                    op = "read";
                    let n = branch_ref(&branch)?;
                    if refs.get(&n) != tip.as_ref() {
                        bail!("requested tip differs from advertisement");
                    }
                    let snapshot = self.with_repo_lock(|repo| {
                        repo.authorize_read(actor.as_deref())?;
                        if repo.read_ref(&n)? != tip {
                            bail!("reference changed since advertisement; retry fetch");
                        }
                        tip.as_deref()
                            .map(|id| Snapshot::create(repo, id))
                            .transpose()
                    })?;
                    send(w, &Message::Ok)?;
                    if let Some(snapshot) = snapshot {
                        send_objects(&snapshot, r, w, mode)?;
                        send(w, &Message::Ok)?;
                    }
                    Ok(())
                }
                Message::FetchRefs { refs: wanted } if version == 2 => {
                    op = "read";
                    if wanted.len() > 256 {
                        bail!("fetch reference limit exceeded");
                    }
                    for (n, id) in &wanted {
                        public_ref(n)?;
                        validate_oid(id)?;
                        if refs.get(n) != Some(id) {
                            bail!("unadvertised fetch reference");
                        }
                    }
                    let snapshot = self.with_repo_lock(|repo| {
                        repo.authorize_read(actor.as_deref())?;
                        for (n, id) in &wanted {
                            if repo.read_ref(n)?.as_ref() != Some(id) {
                                bail!("reference changed since advertisement");
                            }
                        }
                        Snapshot::create_many(repo, &wanted.values().cloned().collect::<Vec<_>>())
                    })?;
                    send(w, &Message::Ok)?;
                    send_objects(&snapshot, r, w, mode)?;
                    send(w, &Message::Ok)
                }
                Message::Push {
                    branch,
                    expected,
                    new,
                } => {
                    op = "push";
                    requested = vec![RefChange {
                        name: branch_ref(&branch)?,
                        expected,
                        new: Some(new),
                    }];
                    self.receive_team_push(
                        r,
                        w,
                        read_only,
                        mode,
                        actor.as_deref(),
                        &requested,
                        &BTreeMap::new(),
                        &refs,
                        false,
                    )
                }
                Message::PushRefs { changes, leases } if version == 2 => {
                    op = "push";
                    requested = changes;
                    self.receive_team_push(
                        r,
                        w,
                        read_only,
                        mode,
                        actor.as_deref(),
                        &requested,
                        &leases,
                        &refs,
                        true,
                    )
                }
                _ => bail!("unsupported request for control protocol v{version}"),
            }
        })();
        if let Err(error) = result {
            let outcome = if format!("{error:#}").contains("denied") {
                "denied"
            } else {
                "failed"
            };
            // Invalid requests never copy unbounded or attacker-controlled fields into the journal.
            let safe = requested.len() <= 256
                && requested.iter().all(|c| {
                    public_ref(&c.name).is_ok()
                        && [&c.expected, &c.new]
                            .into_iter()
                            .flatten()
                            .all(|id| validate_oid(id).is_ok())
                });
            self.with_repo_lock(|repo| {
                repo.audit_attempt_locked(
                    actor.as_deref(),
                    op,
                    if safe { &requested } else { &[] },
                    outcome,
                )
            })
            .context("required failure audit could not be recorded")?;
            return Err(error);
        }
        Ok(())
    }
    #[allow(clippy::too_many_arguments)]
    fn receive_team_push(
        &self,
        r: &mut impl Read,
        w: &mut impl Write,
        read_only: bool,
        mode: wire::Mode,
        actor: Option<&str>,
        changes: &[RefChange],
        leases: &BTreeMap<String, String>,
        refs: &BTreeMap<String, String>,
        extended: bool,
    ) -> Result<()> {
        if read_only {
            bail!("denied: service is read-only");
        }
        let allowed = validate_commands(changes, leases, refs)?;
        let forced: BTreeSet<_> = leases.keys().cloned().collect();
        self.with_repo_lock(|repo| {
            repo.authorize_write(actor, changes, &forced)?;
            if extended && repo.format_version()? != 2 {
                bail!(
                    "extended receive requires format 2; stop old processes and upgrade --quiescent"
                );
            }
            for c in changes {
                if repo.read_ref(&c.name)? != c.expected {
                    bail!("reference changed concurrently");
                }
                if repo.current_ref()?.as_deref() == Some(&c.name) && c.new.is_none() {
                    bail!("cannot delete default HEAD branch");
                }
            }
            Ok(())
        })?;
        send(w, &Message::Ok)?;
        let tx = receive_objects(self, r, w, mode)?;
        if self.format_version()? == 2 {
            tx.commit_many(
                changes,
                &allowed,
                actor.unwrap_or("single-account"),
                "remote push",
                |repo, _, cs| repo.authorize_write(actor, cs, &forced),
            )?;
        } else {
            // Format1 only has a one-ref publication point. Policy or extended operations cannot enter it.
            let c = &changes[0];
            tx.publish_authorized(
                RefUpdate {
                    name: c.name.clone(),
                    expected: c.expected.clone(),
                    new: c.new.clone().context("legacy deletion forbidden")?,
                    allow_non_fast_forward: false,
                },
                |repo| {
                    if repo.format_version()? != 1 {
                        bail!("repository upgraded during receive; retry against format 2");
                    }
                    repo.authorize_write(actor, changes, &forced)
                },
            )?;
        }
        send(w, &Message::Ok)
    }
}
