use super::*;
use sha2::{Digest, Sha256};
use std::io::{BufRead, BufReader};

const MAGIC: &[u8; 8] = b"MYVCSPK1";
const DELTA_MAGIC: &[u8; 8] = b"MYVCSPK2";
const MAX_TOTAL: u64 = 512 * 1024 * 1024;
const MAX_OBJECT: u64 = 256 * 1024 * 1024;

#[derive(Default, Debug, serde::Serialize)]
pub(super) struct Stats {
    pub pack_bytes: u64,
    pub full_equivalent_bytes: u64,
    pub full_objects: usize,
    pub internal_deltas: usize,
    pub external_deltas: usize,
    pub max_depth: usize,
}

pub(super) struct Counted<T> {
    pub inner: T,
    pub bytes: u64,
}
impl<T> Counted<T> {
    pub fn new(inner: T) -> Self {
        Self { inner, bytes: 0 }
    }
}
impl<T: Write> Write for Counted<T> {
    fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
        let n = self.inner.write(b)?;
        self.bytes += n as u64;
        Ok(n)
    }
    fn flush(&mut self) -> std::io::Result<()> {
        self.inner.flush()
    }
}
impl<T: Read> Read for Counted<T> {
    fn read(&mut self, b: &mut [u8]) -> std::io::Result<usize> {
        let n = self.inner.read(b)?;
        self.bytes += n as u64;
        Ok(n)
    }
}

pub(super) struct Snapshot {
    directory: PathBuf,
    pub entries: BTreeMap<String, (u8, u64)>,
}

impl Snapshot {
    // Materialize logical objects while locked. Network I/O never holds a repo
    // lock, and GC cannot invalidate this private, immutable outgoing snapshot.
    pub fn create(repo: &Repo, tip: &str) -> Result<Self> {
        Self::create_many(repo, &[tip.to_owned()])
    }
    pub fn create_many(repo: &Repo, tips: &[String]) -> Result<Self> {
        let mut snapshot = Self {
            directory: repo.meta.join("outgoing").join(unique_suffix()),
            entries: BTreeMap::new(),
        };
        repo.create_dirs_durable(&snapshot.directory)?;
        let mut pending = tips.to_vec();
        let mut commits = BTreeSet::new();
        let mut objects = BTreeMap::new();
        while let Some(id) = pending.pop() {
            if !commits.insert(id.clone()) {
                continue;
            }
            let c = repo.read_commit(&id)?;
            objects.insert(id, 1);
            for id in c.tree.values() {
                objects.entry(id.clone()).or_insert(0);
            }
            if objects.len() > wire::MAX_OBJECTS {
                bail!("snapshot object limit exceeded");
            }
            pending.extend(Repo::commit_parents(&c));
        }
        let mut total = 0u64;
        for (id, kind) in objects {
            let raw = repo.read_blob_resolved(&id)?;
            total += raw.len() as u64;
            if raw.len() as u64 > MAX_OBJECT || total > MAX_TOTAL {
                bail!("snapshot byte limit exceeded");
            }
            let f = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(snapshot.directory.join(&id))?;
            let mut encoder = ZlibEncoder::new(f, flate2::Compression::default());
            encoder.write_all(&raw)?;
            encoder.finish()?;
            snapshot.entries.insert(id, (kind, raw.len() as u64));
        }
        Ok(snapshot)
    }

    pub fn base_candidates(&self, missing: &BTreeSet<String>) -> Vec<String> {
        // Only offer small blobs similar in length to at least one missing blob.
        let sizes: BTreeSet<_> = missing
            .iter()
            .filter_map(|id| {
                let (kind, len) = self.entries[id];
                (kind == 0 && len >= 1024 && len <= delta::MAX_BYTES as u64).then_some(len)
            })
            .collect();
        self.entries
            .iter()
            .filter(|(id, (kind, len))| {
                *kind == 0
                    && *len >= 1024
                    && *len <= delta::MAX_BYTES as u64
                    && !missing.contains(*id)
                    && sizes
                        .range((len / 2)..=len.saturating_mul(2))
                        .next()
                        .is_some()
            })
            .take(delta::MAX_BASES)
            .map(|(id, _)| id.clone())
            .collect()
    }

    fn logical(&self, id: &str) -> Result<Vec<u8>> {
        let (_, length) = self.entries.get(id).context("unknown snapshot object")?;
        if *length > delta::MAX_BYTES as u64 {
            bail!("delta working-set size limit exceeded");
        }
        let mut raw = Vec::new();
        flate2::read::ZlibDecoder::new(File::open(self.directory.join(id))?)
            .take(*length + 1)
            .read_to_end(&mut raw)?;
        if raw.len() as u64 != *length || hex_sha256(&raw) != id {
            bail!("snapshot object corrupt");
        }
        Ok(raw)
    }

    pub fn write(
        &self,
        w: &mut impl Write,
        ids: &BTreeSet<String>,
        mode: wire::Mode,
        pinned: &BTreeSet<String>,
    ) -> Result<Stats> {
        let mut w = Counted::new(w);
        let mut stats = Stats {
            full_equivalent_bytes: 44,
            ..Stats::default()
        };
        let mut previous: Vec<String> = Vec::new();
        let mut depths: BTreeMap<String, usize> = BTreeMap::new();
        let mut candidate_work = 0u64;
        let mut receiver_work = 0u64;
        let mut hash = Sha256::new();
        let mut output = |bytes: &[u8]| -> Result<()> {
            w.write_all(bytes)?;
            hash.update(bytes);
            Ok(())
        };
        output(if mode == wire::Mode::Full {
            MAGIC
        } else {
            DELTA_MAGIC
        })?;
        output(&(ids.len() as u32).to_be_bytes())?;
        for id in ids {
            let (kind, len) = self.entries.get(id).context("unoffered object requested")?;
            let mut file = File::open(self.directory.join(id))?;
            let full_size = file.metadata()?.len();
            stats.full_equivalent_bytes += 82 + full_size;
            let mut best: Option<(String, Vec<u8>, usize)> = None;
            if mode != wire::Mode::Full
                && *kind == 0
                && *len >= 1024
                && *len <= delta::MAX_BYTES as u64
                && receiver_work + delta::MAX_BYTES as u64 + *len <= 1024 * 1024 * 1024
            {
                let mut candidates: Vec<_> = previous
                    .iter()
                    .chain(pinned.iter())
                    .filter(|base| {
                        let (k, n) = self.entries[*base];
                        k == 0
                            && n >= len / 2
                            && n <= len.saturating_mul(2)
                            && n <= delta::MAX_BYTES as u64
                            && depths.get(*base).copied().unwrap_or(0) < delta::MAX_DEPTH
                    })
                    .collect();
                candidates.sort_by_key(|base| (self.entries[*base].1.abs_diff(*len), *base));
                if !candidates.is_empty() {
                    let target = self.logical(id)?;
                    for base in candidates.into_iter().take(delta::CANDIDATES) {
                        let cost = self.entries[base].1 + *len;
                        if candidate_work + cost > 1024 * 1024 * 1024 {
                            break;
                        }
                        candidate_work += cost;
                        let base_raw = self.logical(base)?;
                        let raw = delta::encode(&base_raw, &target)?;
                        drop(base_raw);
                        let mut z = ZlibEncoder::new(Vec::new(), flate2::Compression::default());
                        z.write_all(&raw)?;
                        let compressed = z.finish()?;
                        drop(raw);
                        let cost = compressed.len() as u64 + 64; // additional base OID on wire
                        if cost + 64 <= full_size
                            && cost <= full_size - full_size / 8
                            && best
                                .as_ref()
                                .is_none_or(|(_, payload, _)| compressed.len() < payload.len())
                        {
                            best = Some((
                                base.clone(),
                                compressed,
                                depths.get(base).copied().unwrap_or(0) + 1,
                            ));
                        }
                    }
                }
            }
            let encoding = best
                .as_ref()
                .map(|(base, _, _)| if pinned.contains(base) { 2 } else { 1 })
                .unwrap_or(0);
            output(&[*kind, encoding])?;
            output(id.as_bytes())?;
            output(&len.to_be_bytes())?;
            if let Some((base, compressed, depth)) = best {
                receiver_work += delta::MAX_BYTES as u64 + *len;
                output(&(compressed.len() as u64).to_be_bytes())?;
                output(base.as_bytes())?;
                output(&compressed)?;
                depths.insert(id.clone(), depth);
                stats.max_depth = stats.max_depth.max(depth);
                if encoding == 1 {
                    stats.internal_deltas += 1;
                } else {
                    stats.external_deltas += 1;
                }
            } else {
                output(&full_size.to_be_bytes())?;
                let mut buffer = [0; 65536];
                loop {
                    let n = file.read(&mut buffer)?;
                    if n == 0 {
                        break;
                    }
                    output(&buffer[..n])?;
                }
                depths.insert(id.clone(), 0);
                stats.full_objects += 1;
            }
            if *kind == 0 && *len <= delta::MAX_BYTES as u64 {
                previous.push(id.clone());
                if previous.len() > delta::MAX_BASES {
                    previous.remove(0);
                }
            }
        }
        w.write_all(&hash.finalize())?;
        w.flush()?;
        stats.pack_bytes = w.bytes;
        Ok(stats)
    }
}

#[cfg(test)]
#[path = "pack_tests.rs"]
mod tests;

impl Drop for Snapshot {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.directory);
    }
}

struct Hashed<'a, R> {
    reader: &'a mut R,
    hash: Sha256,
}
impl<R: Read> Read for Hashed<'_, R> {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        let n = self.reader.read(buf)?;
        self.hash.update(&buf[..n]);
        Ok(n)
    }
}
fn bytes<const N: usize>(r: &mut impl Read) -> Result<[u8; N]> {
    let mut b = [0; N];
    r.read_exact(&mut b)?;
    Ok(b)
}

pub(super) fn read(
    r: &mut impl Read,
    tx: &mut ReceiveTransaction,
    expected: &BTreeSet<String>,
    mode: wire::Mode,
    pinned: &BTreeSet<String>,
) -> Result<()> {
    let mut input = Hashed {
        reader: r,
        hash: Sha256::new(),
    };
    if &bytes::<8>(&mut input)?
        != if mode == wire::Mode::Full {
            MAGIC
        } else {
            DELTA_MAGIC
        }
    {
        bail!("invalid pack magic/version");
    }
    let count = u32::from_be_bytes(bytes(&mut input)?) as usize;
    if count != expected.len() || count > wire::MAX_OBJECTS {
        bail!("pack object count mismatch");
    }
    let mut seen = BTreeSet::new();
    let mut total = 0;
    let mut depths = BTreeMap::new();
    let mut work = 0u64;
    let mut compressed_total = 0u64;
    for _ in 0..count {
        let [kind, encoding] = bytes(&mut input)?;
        if kind > 1
            || encoding > 2
            || (encoding != 0 && (mode == wire::Mode::Full || kind != 0))
            || (encoding == 2 && mode != wire::Mode::Thin)
        {
            bail!("unsupported object kind or encoding");
        }
        let id = String::from_utf8(bytes::<64>(&mut input)?.to_vec())?;
        validate_oid(&id)?;
        if !expected.contains(&id) || !seen.insert(id.clone()) {
            bail!("unexpected or duplicate pack object");
        }
        let raw_len = u64::from_be_bytes(bytes(&mut input)?);
        let packed_len = u64::from_be_bytes(bytes(&mut input)?);
        if raw_len > MAX_OBJECT || packed_len > MAX_OBJECT * 2 + 65536 {
            bail!("pack object byte limit exceeded");
        }
        compressed_total += packed_len;
        if compressed_total > MAX_TOTAL * 2 + 16 * 1024 * 1024 {
            bail!("pack compressed byte budget exceeded");
        }
        total += raw_len;
        if total > MAX_TOTAL {
            bail!("pack total byte limit exceeded");
        }
        if encoding == 0 {
            if kind == 1 && raw_len > 16 * 1024 * 1024 {
                bail!("commit metadata size limit exceeded");
            }
            let decoder = StrictZlib::new((&mut input).take(packed_len), packed_len, raw_len, true);
            // Stream full objects directly into quarantine: no object-sized buffer.
            tx.stage_object(&id, decoder)?;
            if kind == 1 {
                let _: Commit = serde_json::from_slice(&tx.staged_bytes(&id, 16 * 1024 * 1024)?)?;
            }
            depths.insert(id, 0usize);
        } else {
            if raw_len > delta::MAX_BYTES as u64
                || packed_len > (delta::MAX_PROGRAM * 2 + 65536) as u64
            {
                bail!("delta working-set size limit exceeded");
            }
            let base = String::from_utf8(bytes::<64>(&mut input)?.to_vec())?;
            validate_oid(&base)?;
            let depth = if encoding == 1 {
                depths
                    .get(&base)
                    .copied()
                    .context("delta base missing, forward reference or cycle")?
                    + 1
            } else {
                if !pinned.contains(&base) {
                    bail!("delta base is unconfirmed");
                }
                1
            };
            if depth > delta::MAX_DEPTH {
                bail!("delta chain depth limit exceeded");
            }
            // Charge worst-case base plus target before allocation, bounding replay work.
            work += delta::MAX_BYTES as u64 + raw_len;
            if work > 1024 * 1024 * 1024 {
                bail!("delta cumulative work limit exceeded");
            }
            let base_raw = tx.staged_bytes(&base, delta::MAX_BYTES)?;
            let mut program = Vec::new();
            StrictZlib::new(
                (&mut input).take(packed_len),
                packed_len,
                delta::MAX_PROGRAM as u64,
                false,
            )
            .read_to_end(&mut program)?;
            let raw = delta::decode(&base_raw, &program, raw_len as usize)?;
            tx.stage_object(&id, raw.as_slice())?;
            depths.insert(id, depth);
        }
    }
    let digest = input.hash.finalize();
    if bytes::<32>(input.reader)?[..] != digest[..] {
        bail!("pack checksum mismatch");
    }
    Ok(())
}

// A strict, output-bounded zlib reader which checks StreamEnd and exact payload
// consumption before returning EOF. The caller cannot accidentally accept a
// truncated stream or append another stream in the declared payload.
struct StrictZlib<R> {
    reader: BufReader<R>,
    decoder: flate2::Decompress,
    packed: u64,
    limit: u64,
    exact: bool,
    done: bool,
}
impl<R: Read> StrictZlib<R> {
    fn new(reader: R, packed: u64, limit: u64, exact: bool) -> Self {
        Self {
            reader: BufReader::new(reader),
            decoder: flate2::Decompress::new(true),
            packed,
            limit,
            exact,
            done: false,
        }
    }
}
impl<R: Read> Read for StrictZlib<R> {
    fn read(&mut self, out: &mut [u8]) -> std::io::Result<usize> {
        use std::io::{Error, ErrorKind};
        if out.is_empty() || self.done {
            return Ok(0);
        }
        loop {
            let input = self.reader.fill_buf()?;
            let before_in = self.decoder.total_in();
            let before_out = self.decoder.total_out();
            let status = self
                .decoder
                .decompress(input, out, flate2::FlushDecompress::None)?;
            let consumed = (self.decoder.total_in() - before_in) as usize;
            let produced = (self.decoder.total_out() - before_out) as usize;
            self.reader.consume(consumed);
            if self.decoder.total_out() > self.limit {
                return Err(Error::new(
                    ErrorKind::InvalidData,
                    "pack decompression length exceeded",
                ));
            }
            if status == flate2::Status::StreamEnd {
                if self.decoder.total_in() != self.packed
                    || (self.exact && self.decoder.total_out() != self.limit)
                {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        "pack length mismatch or trailing compressed bytes",
                    ));
                }
                self.done = true;
                return Ok(produced);
            }
            if produced > 0 {
                return Ok(produced);
            }
            if consumed == 0 {
                return Err(Error::new(
                    ErrorKind::UnexpectedEof,
                    "truncated pack zlib stream",
                ));
            }
        }
    }
}
