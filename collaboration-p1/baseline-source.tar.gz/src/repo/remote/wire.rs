use super::*;
use serde::{Deserialize, Serialize};

pub(super) const BATCH: usize = 1024;
pub(super) const MAX_FRAME: usize = 1024 * 1024;
pub(super) const MAX_OBJECTS: usize = 100_000;

#[derive(Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) enum Message {
    Hello {
        version: u32,
        object_format: u32,
        hash: String,
        pack: String,
    },
    Refs {
        head: String,
        refs: BTreeMap<String, String>,
    },
    Fetch {
        branch: String,
        tip: Option<String>,
    },
    Push {
        branch: String,
        expected: Option<String>,
        new: String,
    },
    FetchRefs {
        refs: BTreeMap<String, String>,
    },
    PushRefs {
        changes: Vec<RefChange>,
        leases: BTreeMap<String, String>,
    },
    Offer {
        ids: Vec<String>,
    },
    Missing {
        ids: Vec<String>,
    },
    Bases {
        ids: Vec<String>,
    },
    Pinned {
        ids: Vec<String>,
    },
    Pack,
    End,
    Ok,
    Error {
        message: String,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum Mode {
    Full,
    Internal,
    Thin,
}
impl Mode {
    pub fn configured() -> Result<Self> {
        match std::env::var("MYVCS_PACK_MODE")
            .unwrap_or_else(|_| "thin".into())
            .as_str()
        {
            "full" => Ok(Self::Full),
            "internal" => Ok(Self::Internal),
            "thin" => Ok(Self::Thin),
            _ => bail!("MYVCS_PACK_MODE must be full, internal or thin"),
        }
    }
    pub fn capability(self) -> &'static str {
        match self {
            Self::Full => "full-zlib-v1",
            Self::Internal => "delta-zlib-v2",
            Self::Thin => "thin-zlib-v2",
        }
    }
}

pub(super) fn hello(mode: Mode) -> Message {
    hello_version(mode, 1)
}
pub(super) fn hello_version(mode: Mode, version: u32) -> Message {
    Message::Hello {
        version,
        object_format: 1,
        hash: "sha256".into(),
        pack: mode.capability().into(),
    }
}

pub(super) fn check_hello(m: Message) -> Result<Mode> {
    let (version, mode) = check_hello_version(m)?;
    if version != 1 {
        bail!("incompatible protocol version");
    }
    Ok(mode)
}
pub(super) fn check_hello_version(m: Message) -> Result<(u32, Mode)> {
    match m {
        Message::Hello {
            version,
            object_format: 1,
            hash,
            pack,
        } if hash == "sha256" && (version == 1 || version == 2) => match pack.as_str() {
            "full-zlib-v1" => Ok((version, Mode::Full)),
            "delta-zlib-v2" => Ok((version, Mode::Internal)),
            "thin-zlib-v2" => Ok((version, Mode::Thin)),
            _ => bail!("unsupported pack capability"),
        },
        _ => bail!("incompatible protocol, object format, hash or pack capability"),
    }
}

pub(super) fn send(w: &mut impl Write, message: &Message) -> Result<()> {
    let raw = serde_json::to_vec(message)?;
    if raw.len() > MAX_FRAME {
        bail!("control frame limit exceeded");
    }
    w.write_all(&(raw.len() as u32).to_be_bytes())?;
    w.write_all(&raw)?;
    w.flush()?;
    Ok(())
}

pub(super) fn recv(r: &mut impl Read) -> Result<Message> {
    let mut length = [0; 4];
    r.read_exact(&mut length)
        .context("incomplete control frame")?;
    let len = u32::from_be_bytes(length) as usize;
    if len == 0 || len > MAX_FRAME {
        bail!("control frame limit exceeded");
    }
    let mut raw = vec![0; len];
    r.read_exact(&mut raw)?;
    let m = serde_json::from_slice(&raw)?;
    if let Message::Error { message } = m {
        bail!("remote: {message}");
    }
    Ok(m)
}

pub(super) fn expect_ok(r: &mut impl Read) -> Result<()> {
    if !matches!(recv(r)?, Message::Ok) {
        bail!("expected acknowledgement");
    }
    Ok(())
}
