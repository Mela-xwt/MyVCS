use super::*;
use wire::Mode;

struct Lab {
    path: PathBuf,
    repo: Repo,
}
impl Lab {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!("myvcs-pack-{}", unique_suffix()));
        let repo = Repo::init_at(&path, true, true).unwrap();
        Self { path, repo }
    }
    fn object(&self, raw: &[u8]) -> String {
        self.repo.write_object(raw).unwrap()
    }
    fn commit(&self, tree: BTreeMap<String, String>) -> String {
        self.object(
            &serde_json::to_vec(&Commit {
                tree,
                parents: vec![],
                parent: None,
                message: "test".into(),
                author: "test".into(),
                timestamp: 0,
            })
            .unwrap(),
        )
    }
}
impl Drop for Lab {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.path);
    }
}
fn random(size: usize) -> Vec<u8> {
    let mut state = 41519u64;
    (0..size)
        .map(|_| {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            state as u8
        })
        .collect()
}
fn compressed(raw: &[u8]) -> Vec<u8> {
    let mut z = ZlibEncoder::new(Vec::new(), flate2::Compression::default());
    z.write_all(raw).unwrap();
    z.finish().unwrap()
}
fn entry(id: &str, encoding: u8, length: u64, base: &str, raw: &[u8]) -> Vec<u8> {
    let payload = compressed(raw);
    let mut bytes = vec![0, encoding];
    bytes.extend(id.as_bytes());
    bytes.extend(length.to_be_bytes());
    bytes.extend((payload.len() as u64).to_be_bytes());
    if encoding != 0 {
        bytes.extend(base.as_bytes());
    }
    bytes.extend(payload);
    bytes
}
fn finish(entries: &[Vec<u8>]) -> Vec<u8> {
    let mut pack = DELTA_MAGIC.to_vec();
    pack.extend((entries.len() as u32).to_be_bytes());
    for entry in entries {
        pack.extend(entry);
    }
    let hash = Sha256::digest(&pack);
    pack.extend(hash);
    pack
}
fn copy(offset: u64, length: u64) -> Vec<u8> {
    let mut program = 1u32.to_be_bytes().to_vec();
    program.push(0);
    program.extend(offset.to_be_bytes());
    program.extend(length.to_be_bytes());
    program
}

#[test]
fn delta_binary_checks_ranges_counts_lengths_and_opcodes() {
    let base = random(16384);
    let mut target = base.clone();
    target[200..220].fill(3);
    assert_eq!(
        delta::decode(&base, &delta::encode(&base, &target).unwrap(), target.len()).unwrap(),
        target
    );
    for bad in [
        copy(u64::MAX, 8),
        copy(16383, 8),
        copy(0, 16385),
        vec![0, 4, 0, 1],
        vec![0, 0, 0, 1, 8],
        vec![0, 0, 0, 0, 1],
        copy(0, 0),
    ] {
        assert!(delta::decode(&base, &bad, target.len()).is_err(), "{bad:?}");
    }
    let raw = delta::encode(&base, &target).unwrap();
    assert!(delta::decode(&base, &raw[..raw.len() - 1], target.len()).is_err());
    assert!(delta::decode(&base, &raw, delta::MAX_BYTES + 1).is_err());
}

#[test]
fn internal_pack_saves_actual_bytes_and_reconstructs_every_object() {
    let src = Lab::new();
    let dst = Lab::new();
    let a = random(128 * 1024);
    let mut b = a.clone();
    b[3333..3341].fill(9);
    let aid = src.object(&a);
    let bid = src.object(&b);
    let tip = src.commit([("a".into(), aid.clone()), ("b".into(), bid.clone())].into());
    let snapshot = Snapshot::create(&src.repo, &tip).unwrap();
    let ids = snapshot.entries.keys().cloned().collect();
    let mut full = Vec::new();
    let mut delta_pack = Vec::new();
    let full_stats = snapshot
        .write(&mut full, &ids, Mode::Full, &BTreeSet::new())
        .unwrap();
    let stats = snapshot
        .write(&mut delta_pack, &ids, Mode::Internal, &BTreeSet::new())
        .unwrap();
    assert_eq!(stats.internal_deltas, 1);
    assert_eq!(stats.pack_bytes as usize, delta_pack.len());
    assert_eq!(stats.full_equivalent_bytes, full_stats.pack_bytes);
    assert!(delta_pack.len() * 10 < full.len() * 6);
    let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
    read(
        &mut delta_pack.as_slice(),
        &mut tx,
        &ids,
        Mode::Internal,
        &BTreeSet::new(),
    )
    .unwrap();
    tx.commit(RefUpdate {
        name: "refs/heads/main".into(),
        expected: None,
        new: tip,
        allow_non_fast_forward: false,
    })
    .unwrap();
    assert_eq!(dst.repo.read_blob_resolved(&aid).unwrap(), a);
    assert_eq!(dst.repo.read_blob_resolved(&bid).unwrap(), b);
    dst.repo.with_repo_lock(|r| r.gc()).unwrap();
    dst.repo.verify().unwrap();
}

#[test]
fn confirmed_external_base_survives_gc_and_is_reinstalled_if_reachable() {
    let src = Lab::new();
    let dst = Lab::new();
    let a = random(128 * 1024);
    let mut b = a.clone();
    b[42..47].fill(0);
    let aid = src.object(&a);
    let bid = src.object(&b);
    dst.object(&a);
    let tip = src.commit([("base".into(), aid.clone()), ("target".into(), bid.clone())].into());
    let snapshot = Snapshot::create(&src.repo, &tip).unwrap();
    let ids = snapshot
        .entries
        .keys()
        .filter(|id| **id != aid)
        .cloned()
        .collect();
    let pinned = [aid.clone()].into();
    let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
    dst.repo
        .with_repo_lock(|_| {
            assert!(tx.pin_base(&aid, delta::MAX_BYTES)?);
            Ok(())
        })
        .unwrap();
    dst.repo.with_repo_lock(|r| r.gc()).unwrap();
    assert!(dst.repo.read_blob_resolved(&aid).is_err());
    let mut data = Vec::new();
    let stats = snapshot
        .write(&mut data, &ids, Mode::Thin, &pinned)
        .unwrap();
    assert_eq!(stats.external_deltas, 1);
    assert!(stats.pack_bytes < 2000);
    read(&mut data.as_slice(), &mut tx, &ids, Mode::Thin, &pinned).unwrap();
    tx.commit(RefUpdate {
        name: "refs/heads/main".into(),
        expected: None,
        new: tip,
        allow_non_fast_forward: false,
    })
    .unwrap();
    assert_eq!(dst.repo.read_blob_resolved(&aid).unwrap(), a);
    assert_eq!(dst.repo.read_blob_resolved(&bid).unwrap(), b);
    assert_eq!(fs::read_dir(dst.path.join("incoming")).unwrap().count(), 0);
}

#[test]
fn absent_pin_is_not_confirmed_and_full_encoding_remains_available() {
    let src = Lab::new();
    let dst = Lab::new();
    let a = random(5000);
    let mut b = a.clone();
    b[9] ^= 1;
    let aid = src.object(&a);
    let bid = src.object(&b);
    let tip = src.commit([("base".into(), aid.clone()), ("target".into(), bid.clone())].into());
    let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
    assert!(!tx.pin_base(&aid, delta::MAX_BYTES).unwrap());
    let snapshot = Snapshot::create(&src.repo, &tip).unwrap();
    let ids = [bid.clone()].into();
    let mut data = Vec::new();
    let stats = snapshot
        .write(&mut data, &ids, Mode::Thin, &BTreeSet::new())
        .unwrap();
    assert_eq!(stats.full_objects, 1);
    assert_eq!(stats.external_deltas, 0);
    read(
        &mut data.as_slice(),
        &mut tx,
        &ids,
        Mode::Thin,
        &BTreeSet::new(),
    )
    .unwrap();
    assert_eq!(tx.staged_bytes(&bid, delta::MAX_BYTES).unwrap(), b);
}

#[test]
fn delta_pack_rejects_missing_forward_cyclic_unconfirmed_corrupt_and_oversized_data() {
    let base = random(2048);
    let aid = hex_sha256(&base);
    let target = base[..1024].to_vec();
    let bid = hex_sha256(&target);
    let full = entry(&aid, 0, base.len() as u64, "", &base);
    let valid = entry(&bid, 1, 1024, &aid, &copy(0, 1024));
    let cases = vec![
        (vec![valid.clone()], "base missing"),
        (vec![valid.clone(), full.clone()], "forward reference"),
        (vec![entry(&bid, 1, 1024, &bid, &copy(0, 1024))], "cycle"),
        (
            vec![entry(&bid, 2, 1024, &aid, &copy(0, 1024))],
            "unconfirmed",
        ),
        (
            vec![full.clone(), entry(&bid, 1, 1024, &aid, &copy(2047, 1024))],
            "copy range",
        ),
        (
            vec![full.clone(), entry(&bid, 1, 1024, &aid, &copy(0, 1025))],
            "output length",
        ),
        (
            vec![full.clone(), entry(&bid, 1, 1024, &aid, &copy(1, 1024))],
            "hash mismatch",
        ),
        (
            vec![
                full.clone(),
                entry(
                    &bid,
                    1,
                    1024,
                    &aid,
                    &((delta::MAX_OPS as u32 + 1).to_be_bytes()),
                ),
            ],
            "instruction limit",
        ),
        (
            vec![
                full.clone(),
                entry(&bid, 1, delta::MAX_BYTES as u64 + 1, &aid, &copy(0, 1024)),
            ],
            "working-set",
        ),
        (
            vec![
                full.clone(),
                entry(&bid, 1, 1024, &aid, &vec![0; delta::MAX_PROGRAM + 1]),
            ],
            "decompression length",
        ),
    ];
    for (entries, expected_error) in cases {
        let dst = Lab::new();
        let ids = entries
            .iter()
            .map(|e| String::from_utf8(e[2..66].to_vec()).unwrap())
            .collect();
        let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
        let err = read(
            &mut finish(&entries).as_slice(),
            &mut tx,
            &ids,
            Mode::Thin,
            &BTreeSet::new(),
        )
        .unwrap_err();
        assert!(
            format!("{err:#}").contains(expected_error),
            "{expected_error}: {err:#}"
        );
        drop(tx);
        assert_eq!(dst.repo.head_commit_id().unwrap(), None);
        assert_eq!(fs::read_dir(dst.path.join("incoming")).unwrap().count(), 0);
    }
    for mutate in [0, 1] {
        let dst = Lab::new();
        let mut data = finish(&[full.clone(), valid.clone()]);
        let end = data.len();
        if mutate == 0 {
            data[end - 1] ^= 1;
        } else {
            data.truncate(end - 40);
        }
        let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
        assert!(
            read(
                &mut data.as_slice(),
                &mut tx,
                &[aid.clone(), bid.clone()].into(),
                Mode::Internal,
                &BTreeSet::new()
            )
            .is_err()
        );
    }
}

#[test]
fn delta_chain_at_limit_succeeds_and_next_edge_is_rejected() {
    for count in [delta::MAX_DEPTH, delta::MAX_DEPTH + 1] {
        let dst = Lab::new();
        let mut content = b"base".to_vec();
        let mut base = hex_sha256(&content);
        let mut entries = vec![entry(&base, 0, content.len() as u64, "", &content)];
        let mut ids = BTreeSet::from([base.clone()]);
        for i in 0..count {
            let old = content.clone();
            content.push(i as u8);
            let id = hex_sha256(&content);
            entries.push(entry(
                &id,
                1,
                content.len() as u64,
                &base,
                &delta::encode(&old, &content).unwrap(),
            ));
            ids.insert(id.clone());
            base = id;
        }
        let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
        let result = read(
            &mut finish(&entries).as_slice(),
            &mut tx,
            &ids,
            Mode::Internal,
            &BTreeSet::new(),
        );
        if count == delta::MAX_DEPTH {
            result.unwrap();
            assert_eq!(tx.staged_bytes(&base, 1024).unwrap(), content);
        } else {
            assert!(result.unwrap_err().to_string().contains("chain depth"));
        }
    }
}

#[test]
fn work_budget_and_receive_quota_fail_explicitly() {
    let dst = Lab::new();
    let raw = random(512);
    let base = hex_sha256(&raw);
    let mut entries = vec![entry(&base, 0, 512, "", &raw)];
    let mut ids = BTreeSet::from([base.clone()]);
    for i in 1..130 {
        let data = &raw[..i];
        let id = hex_sha256(data);
        ids.insert(id.clone());
        entries.push(entry(&id, 1, i as u64, &base, &copy(0, i as u64)));
    }
    let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
    let err = read(
        &mut finish(&entries).as_slice(),
        &mut tx,
        &ids,
        Mode::Internal,
        &BTreeSet::new(),
    )
    .unwrap_err();
    assert!(err.to_string().contains("cumulative work"));
    let mut tx = dst
        .repo
        .begin_receive(ReceiveLimits {
            max_total_bytes: 100,
            ..ReceiveLimits::default()
        })
        .unwrap();
    let err = read(
        &mut finish(&entries[..1]).as_slice(),
        &mut tx,
        &[base].into(),
        Mode::Internal,
        &BTreeSet::new(),
    )
    .unwrap_err();
    assert!(err.to_string().contains("receive byte limit"));
}

#[test]
fn ineffective_delta_falls_back_and_full_receive_memory_is_bounded() {
    let src = Lab::new();
    let dst = Lab::new();
    let a = vec![b'a'; 1024 * 1024];
    let b = vec![b'b'; 1024 * 1024];
    let aid = src.object(&a);
    let bid = src.object(&b);
    let tip = src.commit([("a".into(), aid), ("b".into(), bid)].into());
    let snapshot = Snapshot::create(&src.repo, &tip).unwrap();
    let ids = snapshot.entries.keys().cloned().collect();
    let mut data = Vec::new();
    let stats = snapshot
        .write(&mut data, &ids, Mode::Internal, &BTreeSet::new())
        .unwrap();
    assert_eq!(stats.internal_deltas, 0);
    assert_eq!(stats.full_objects, 3);
    let large = vec![3u8; 32 * 1024 * 1024];
    let id = hex_sha256(&large);
    let data = finish(&[entry(&id, 0, large.len() as u64, "", &large)]);
    let mut tx = dst.repo.begin_receive(ReceiveLimits::default()).unwrap();
    let (result, peak) = crate::test_alloc::peak_bytes(|| {
        read(
            &mut data.as_slice(),
            &mut tx,
            &[id].into(),
            Mode::Internal,
            &BTreeSet::new(),
        )
    });
    result.unwrap();
    assert!(peak < 4 * 1024 * 1024, "streaming full receive peak {peak}");
    eprintln!("full_receive_32MiB_peak_allocated_bytes={peak}");
}

#[test]
fn maximum_delta_working_set_has_measured_allocation_bound() {
    let base = random(delta::MAX_BYTES);
    let mut target = base.clone();
    target[65536..65600].fill(2);
    let (program, encode_peak) =
        crate::test_alloc::peak_bytes(|| delta::encode(&base, &target).unwrap());
    let (result, decode_peak) =
        crate::test_alloc::peak_bytes(|| delta::decode(&base, &program, target.len()).unwrap());
    assert_eq!(result, target);
    assert!(encode_peak < 64 * 1024 * 1024, "encode peak {encode_peak}");
    assert!(decode_peak <= delta::MAX_BYTES);
    eprintln!(
        "delta_8MiB_encode_aux_peak_bytes={encode_peak} decode_output_peak_bytes={decode_peak}"
    );
}
