//! Bounded binary Copy/Insert wire representation; independent of JSON disk deltas.
use super::*;
use crate::model::DeltaOp;

pub(super) const MAX_BYTES: usize = 8 * 1024 * 1024;
pub(super) const MAX_PROGRAM: usize = 16 * 1024 * 1024;
pub(super) const MAX_OPS: usize = 262_144;
pub(super) const MAX_DEPTH: usize = 8;
pub(super) const MAX_BASES: usize = 16;
pub(super) const CANDIDATES: usize = 4;

// Bounded Vec output prevents a decoder from allocating from untrusted counts.
// u32 op_count, then (0, u64 offset, u64 len) or (1, u64 len, literal bytes).
pub(super) fn encode(base: &[u8], target: &[u8]) -> Result<Vec<u8>> {
    if base.len() > MAX_BYTES || target.len() > MAX_BYTES {
        bail!("delta working-set size limit exceeded");
    }
    let ops = build_delta(base, target);
    if ops.len() > MAX_OPS {
        bail!("delta instruction limit exceeded");
    }
    let mut raw = Vec::new();
    raw.extend_from_slice(&(ops.len() as u32).to_be_bytes());
    for op in ops {
        match op {
            DeltaOp::Copy { offset, len } => {
                raw.push(0);
                raw.extend_from_slice(&(offset as u64).to_be_bytes());
                raw.extend_from_slice(&(len as u64).to_be_bytes());
            }
            DeltaOp::Insert { data } => {
                raw.push(1);
                raw.extend_from_slice(&(data.len() as u64).to_be_bytes());
                raw.extend_from_slice(&data);
            }
        }
        if raw.len() > MAX_PROGRAM {
            bail!("delta program limit exceeded");
        }
    }
    Ok(raw)
}

pub(super) fn decode(base: &[u8], program: &[u8], length: usize) -> Result<Vec<u8>> {
    if base.len() > MAX_BYTES || length > MAX_BYTES || program.len() > MAX_PROGRAM {
        bail!("delta working-set size limit exceeded");
    }
    let mut r = std::io::Cursor::new(program);
    let mut count = [0; 4];
    r.read_exact(&mut count)?;
    let count = u32::from_be_bytes(count) as usize;
    if count > MAX_OPS {
        bail!("delta instruction limit exceeded");
    }
    let mut output = Vec::new();
    output.try_reserve_exact(length)?;
    for _ in 0..count {
        let mut opcode = [0];
        r.read_exact(&mut opcode)?;
        let offset = if opcode[0] == 0 { number(&mut r)? } else { 0 };
        if opcode[0] > 1 {
            bail!("invalid delta opcode");
        }
        let size = number(&mut r)?;
        if size == 0 || size > length.saturating_sub(output.len()) {
            bail!("delta output length exceeded or empty instruction");
        }
        if opcode[0] == 0 {
            let end = offset.checked_add(size).context("delta copy overflow")?;
            let slice = base.get(offset..end).context("invalid delta copy range")?;
            output.extend_from_slice(slice);
        } else {
            let start = output.len();
            output.resize(start + size, 0);
            r.read_exact(&mut output[start..])?;
        }
    }
    if r.position() != program.len() as u64 || output.len() != length {
        bail!("delta length mismatch or trailing instructions");
    }
    Ok(output)
}

fn number(r: &mut impl Read) -> Result<usize> {
    let mut raw = [0; 8];
    r.read_exact(&mut raw)?;
    usize::try_from(u64::from_be_bytes(raw)).context("delta integer exceeds platform size")
}
