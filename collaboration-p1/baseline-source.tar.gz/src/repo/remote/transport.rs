use super::*;
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::sync::mpsc;
use std::time::Duration;

#[derive(Debug)]
pub(super) enum Address {
    Ssh {
        destination: String,
        port: u16,
        repository: String,
    },
    Local(PathBuf),
}

pub(super) fn repository_name(name: &str) -> Result<()> {
    if name.len() > 1024
        || name.split('/').any(|p| {
            p.is_empty()
                || p == "."
                || p == ".."
                || p.starts_with('-')
                || !p
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b"._-".contains(&b))
        })
    {
        bail!("invalid repository identifier");
    }
    Ok(())
}

impl Address {
    pub fn parse(url: &str) -> Result<Self> {
        if let Some(path) = url.strip_prefix("file://") {
            let path = PathBuf::from(path);
            if !path.is_absolute() {
                bail!("file transport requires an absolute repository path");
            }
            return Ok(Self::Local(path));
        }
        let rest = url
            .strip_prefix("ssh://")
            .context("use ssh://[user@]host[:port]/repository or file:///absolute/path")?;
        let (authority, repository) = rest
            .split_once('/')
            .context("missing repository identifier")?;
        repository_name(repository)?;
        let (destination, port) = match authority.split_once(':') {
            Some((host, port)) => (host, port.parse::<u16>().context("invalid SSH port")?),
            None => (authority, 22),
        };
        if port == 0
            || destination.split('@').count() > 2
            || destination.split('@').any(|p| {
                p.is_empty()
                    || p.starts_with('-')
                    || !p
                        .bytes()
                        .all(|b| b.is_ascii_alphanumeric() || b"._-".contains(&b))
            })
        {
            bail!("invalid SSH destination");
        }
        Ok(Self::Ssh {
            destination: destination.into(),
            port,
            repository: repository.into(),
        })
    }
}

pub(super) fn timeout() -> Result<u64> {
    let n = std::env::var("MYVCS_TRANSFER_TIMEOUT")
        .unwrap_or_else(|_| "300".into())
        .parse()?;
    if !(1..=3600).contains(&n) {
        bail!("transfer timeout must be 1..3600 seconds");
    }
    Ok(n)
}

pub(super) struct Connection {
    pub reader: std::io::BufReader<ChildStdout>,
    pub writer: std::io::BufWriter<ChildStdin>,
    child: Arc<Mutex<Child>>,
    cancel: Option<mpsc::Sender<()>>,
    watchdog: Option<std::thread::JoinHandle<()>>,
}

impl Connection {
    pub fn open(url: &str) -> Result<Self> {
        let seconds = timeout()?;
        let mut command = match Address::parse(url)? {
            Address::Local(path) => {
                let path = fs::canonicalize(path)?;
                let parent = path
                    .parent()
                    .context("repository cannot be filesystem root")?;
                let name = path
                    .file_name()
                    .context("invalid repository path")?
                    .to_str()
                    .context("non-UTF8 repository name")?;
                repository_name(name)?;
                let mut c = Command::new(std::env::current_exe()?);
                c.arg("serve")
                    .arg("--root")
                    .arg(parent)
                    .arg("--repository")
                    .arg(name);
                c
            }
            Address::Ssh {
                destination,
                port,
                repository,
            } => {
                let program =
                    std::env::var("MYVCS_REMOTE_PROGRAM").unwrap_or_else(|_| "myvcs".into());
                if program.is_empty()
                    || program.starts_with('-')
                    || !program
                        .bytes()
                        .all(|b| b.is_ascii_alphanumeric() || b"/._-".contains(&b))
                {
                    bail!("invalid remote executable path");
                }
                let mut c =
                    Command::new(std::env::var_os("MYVCS_SSH").unwrap_or_else(|| "ssh".into()));
                c.args([
                    "-T",
                    "-o",
                    "ConnectTimeout=15",
                    "-o",
                    "ServerAliveInterval=15",
                    "-o",
                    "ServerAliveCountMax=3",
                    "-p",
                ])
                .arg(port.to_string())
                .arg("--")
                .arg(destination)
                .arg(format!("{program} serve --repository {repository}"));
                c
            }
        };
        let mut child = command
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::inherit())
            .spawn()
            .context("start remote service")?;
        let writer = std::io::BufWriter::new(child.stdin.take().unwrap());
        let reader = std::io::BufReader::new(child.stdout.take().unwrap());
        let child = Arc::new(Mutex::new(child));
        let (cancel, receiver) = mpsc::channel();
        let watched = child.clone();
        let watchdog = std::thread::spawn(move || {
            if receiver.recv_timeout(Duration::from_secs(seconds)).is_err() {
                if let Ok(mut child) = watched.lock() {
                    let _ = child.kill();
                }
            }
        });
        Ok(Self {
            reader,
            writer,
            child,
            cancel: Some(cancel),
            watchdog: Some(watchdog),
        })
    }
}

impl Drop for Connection {
    fn drop(&mut self) {
        if let Some(cancel) = self.cancel.take() {
            let _ = cancel.send(());
        }
        if let Some(watchdog) = self.watchdog.take() {
            let _ = watchdog.join();
        }
        if let Ok(mut child) = self.child.lock() {
            let _ = child.kill();
            let _ = child.wait();
        }
    }
}

// Also bounds a server whose peer connects but never finishes a frame/pack.
pub(super) struct ServerDeadline(mpsc::Sender<()>);
impl ServerDeadline {
    pub fn start() -> Result<Self> {
        let seconds = timeout()?;
        let (tx, rx) = mpsc::channel();
        std::thread::spawn(move || {
            if matches!(
                rx.recv_timeout(Duration::from_secs(seconds)),
                Err(mpsc::RecvTimeoutError::Timeout)
            ) {
                eprintln!("service session deadline exceeded");
                std::process::exit(124);
            }
        });
        Ok(Self(tx))
    }
}
impl Drop for ServerDeadline {
    fn drop(&mut self) {
        let _ = self.0.send(());
    }
}
