use super::*;
use std::sync::atomic::{AtomicU64, Ordering};

/// Limits apply to legacy decoding as well as newly received objects.
#[derive(Debug, Clone)]
pub struct ReadLimits {
    pub object_bytes: usize,
    pub chain_bytes: usize,
    pub metadata_bytes: usize,
    pub delta_depth: usize,
    pub delta_ops: usize,
    pub graph_objects: usize,
}
impl Default for ReadLimits {
    fn default() -> Self {
        Self {
            object_bytes: 256 * 1024 * 1024,
            chain_bytes: 1024 * 1024 * 1024,
            metadata_bytes: 16 * 1024 * 1024,
            delta_depth: 64,
            delta_ops: 1_000_000,
            graph_objects: 1_000_000,
        }
    }
}

pub fn validate_oid(id: &str) -> Result<()> {
    if id.len() != 64
        || !id
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        bail!("invalid OID: expected 64 lowercase hexadecimal characters");
    }
    Ok(())
}

// A portable namespace: reject aliases on Windows as well as Unix traversal.
fn validate_components(name: &str) -> Result<()> {
    if name.is_empty() || name.len() > 4096 || name.contains('\\') || name.contains(':') {
        bail!("invalid path or reference: {name}");
    }
    for part in name.split('/') {
        let lower = part.to_ascii_lowercase();
        let stem = lower.split('.').next().unwrap_or("");
        let device = matches!(stem, "con" | "prn" | "aux" | "nul")
            || (stem.len() == 4
                && (stem.starts_with("com") || stem.starts_with("lpt"))
                && matches!(stem.as_bytes()[3], b'1'..=b'9'));
        if part.is_empty()
            || part == "."
            || part == ".."
            || part.ends_with(['.', ' '])
            || part
                .chars()
                .any(|c| c.is_control() || "<>\"|?*".contains(c))
            || device
        {
            bail!("invalid path component: {part}");
        }
    }
    Ok(())
}

pub fn validate_ref(name: &str) -> Result<()> {
    validate_components(name)?;
    if !["refs/heads/", "refs/remotes/", "refs/tags/", "refs/pins/"]
        .iter()
        .any(|p| name.starts_with(p))
        || name.contains("..")
        || name.contains("@{")
        || name
            .chars()
            .any(|c| c.is_whitespace() || "~^?[".contains(c))
        || name
            .split('/')
            .any(|p| p.starts_with('.') || p.ends_with(".lock"))
    {
        bail!("invalid reference: {name}");
    }
    Ok(())
}

pub fn validate_tree_path(name: &str) -> Result<()> {
    validate_components(name)?;
    if name
        .split('/')
        .any(|p| p.eq_ignore_ascii_case(META_DIR) || p.eq_ignore_ascii_case(".git"))
    {
        bail!("protected metadata path: {name}");
    }
    Ok(())
}

pub(super) fn no_symlinks(base: &Path, path: &Path) -> Result<()> {
    let relative = path
        .strip_prefix(base)
        .context("path is outside repository")?;
    let mut cur = base.to_path_buf();
    for component in relative.components() {
        if !matches!(component, std::path::Component::Normal(_)) {
            bail!("unsafe path component");
        }
        cur.push(component);
        match fs::symlink_metadata(&cur) {
            Ok(m) => {
                if m.file_type().is_symlink() {
                    bail!("symlink is not allowed: {}", cur.display());
                }
                #[cfg(windows)]
                {
                    use std::os::windows::fs::MetadataExt;
                    if m.file_attributes() & 0x400 != 0 {
                        bail!("reparse point is not allowed");
                    }
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.into()),
        }
    }
    Ok(())
}

pub(super) fn unique_suffix() -> String {
    static NEXT: AtomicU64 = AtomicU64::new(0);
    format!(
        "{}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    )
}

pub(super) fn sync_directory(path: &Path) -> Result<()> {
    #[cfg(unix)]
    File::open(path)?.sync_all()?;
    // Windows does not expose portable directory fsync; file contents are still flushed.
    #[cfg(not(unix))]
    let _ = path;
    Ok(())
}

impl Repo {
    pub fn with_read_limits(mut self, limits: ReadLimits) -> Result<Self> {
        if limits.object_bytes == 0
            || limits.object_bytes > isize::MAX as usize
            || limits.metadata_bytes > isize::MAX as usize
            || limits.chain_bytes < limits.object_bytes
            || limits.metadata_bytes == 0
            || limits.delta_depth == 0
            || limits.delta_depth > 256
            || limits.delta_ops == 0
            || limits.graph_objects == 0
        {
            bail!("invalid read limits");
        }
        self.limits = limits;
        Ok(self)
    }
    pub fn is_bare(&self) -> bool {
        self.bare
    }
    pub fn metadata_dir(&self) -> &Path {
        &self.meta
    }
    pub(super) fn require_worktree(&self) -> Result<()> {
        if self.bare {
            bail!("operation requires a working tree (bare repository)");
        }
        Ok(())
    }
    pub(super) fn work_path(&self, name: &str) -> Result<PathBuf> {
        self.require_worktree()?;
        validate_tree_path(name)?;
        let path = self.root.join(name);
        no_symlinks(&self.root, &path)?;
        Ok(path)
    }
    pub(super) fn input_path(&self, name: &str) -> Result<PathBuf> {
        self.require_worktree()?;
        if name == "." {
            return Ok(self.root.clone());
        }
        self.work_path(
            name.strip_prefix("./")
                .unwrap_or(name)
                .trim_end_matches('/'),
        )
    }
    pub(super) fn check_internal_path(&self, path: &Path) -> Result<()> {
        no_symlinks(&self.root, path)
    }
    pub(super) fn validate_tree(&self, tree: &BTreeMap<String, String>) -> Result<()> {
        let mut names = BTreeSet::new();
        for (path, oid) in tree {
            validate_tree_path(path)?;
            validate_oid(oid)?;
            if !names.insert(path.to_lowercase()) {
                bail!("case-colliding tree paths");
            }
        }
        for path in &names {
            for (i, _) in path.match_indices('/') {
                if names.contains(&path[..i]) {
                    bail!("file/directory collision in tree");
                }
            }
        }
        Ok(())
    }
    pub(super) fn read_metadata(&self, path: &Path) -> Result<String> {
        self.check_internal_path(path)?;
        let mut bytes = Vec::new();
        File::open(path)?
            .take(self.limits.metadata_bytes as u64 + 1)
            .read_to_end(&mut bytes)?;
        if bytes.len() > self.limits.metadata_bytes {
            bail!("metadata size limit exceeded");
        }
        Ok(String::from_utf8(bytes)?)
    }
    pub(super) fn ref_path(&self, name: &str) -> Result<PathBuf> {
        validate_ref(name)?;
        let p = self.meta.join(name);
        self.check_internal_path(&p)?;
        Ok(p)
    }
    pub fn read_ref(&self, name: &str) -> Result<Option<String>> {
        validate_ref(name)?;
        if self.format_version()? == 2 {
            return Ok(self.refs_snapshot()?.refs.get(name).cloned());
        }
        self.read_ref_legacy(name)
    }
    fn read_ref_legacy(&self, name: &str) -> Result<Option<String>> {
        let p = self.ref_path(name)?;
        if !p.exists() {
            return Ok(None);
        }
        let value = self.read_metadata(&p)?.trim().to_owned();
        // Legacy init wrote an empty main ref before its first commit.
        if value.is_empty() {
            return Ok(None);
        }
        validate_oid(&value)?;
        Ok(Some(value))
    }
    pub fn list_refs(&self) -> Result<BTreeMap<String, String>> {
        if self.format_version()? == 2 {
            return Ok(self.refs_snapshot()?.refs);
        }
        self.list_refs_legacy()
    }
    pub(super) fn list_refs_legacy(&self) -> Result<BTreeMap<String, String>> {
        let root = self.meta.join("refs");
        self.check_internal_path(&root)?;
        let mut out = BTreeMap::new();
        let mut bytes = 0usize;
        for entry in WalkDir::new(&root) {
            let entry = entry?;
            self.check_internal_path(entry.path())?;
            if entry.file_type().is_file() {
                if entry
                    .file_name()
                    .to_string_lossy()
                    .starts_with(".myvcs-tmp-")
                {
                    continue;
                }
                let name = entry
                    .path()
                    .strip_prefix(&self.meta)?
                    .components()
                    .map(|part| {
                        part.as_os_str()
                            .to_str()
                            .map(str::to_owned)
                            .context("reference is not UTF-8")
                    })
                    .collect::<Result<Vec<_>>>()?
                    .join("/");
                if let Some(id) = self.read_ref_legacy(&name)? {
                    bytes += name.len() + 72;
                    if bytes > 16 * 1024 * 1024 {
                        bail!("reference metadata size limit exceeded");
                    }
                    out.insert(name, id);
                }
                if out.len() > self.limits.graph_objects {
                    bail!("reference count limit exceeded");
                }
            }
        }
        Ok(out)
    }
    /// Single-ref compare-and-swap. The entire commit closure must already exist.
    /// Acquires the repository lock; do not nest inside with_repo_lock.
    pub fn update_ref(&self, name: &str, expected: Option<&str>, new: &str) -> Result<()> {
        self.with_repo_lock(|repo| repo.update_ref_locked(name, expected, new))
    }
    pub(super) fn update_ref_locked(
        &self,
        name: &str,
        expected: Option<&str>,
        new: &str,
    ) -> Result<()> {
        if self.format_version()? == 2 {
            return self.transact_refs_locked(
                &[RefChange {
                    name: name.into(),
                    expected: expected.map(Into::into),
                    new: Some(new.into()),
                }],
                "update ref",
            );
        }
        let p = self.ref_path(name)?;
        if let Some(old) = expected {
            validate_oid(old)?;
        }
        validate_oid(new)?;
        if self.read_ref(name)?.as_deref() != expected {
            bail!("reference changed concurrently: {name}");
        }
        self.validate_closure(new)?;
        self.atomic_write(&p, format!("{new}\n").as_bytes())?;
        *self.commit_graph.lock().unwrap() = None;
        Ok(())
    }
    pub(super) fn check_graph_size(&self, size: usize) -> Result<()> {
        if size > self.limits.graph_objects {
            bail!("graph object limit exceeded");
        }
        Ok(())
    }
}
