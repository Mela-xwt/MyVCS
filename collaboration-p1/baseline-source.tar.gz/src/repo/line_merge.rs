//! A bounded, byte-preserving line merge. Every edit is expressed in base coordinates.
const MAX_BYTES: usize = 1024 * 1024;
const MAX_LINES: usize = 20_000;
const MAX_CELLS: usize = 4_000_000;

#[derive(Clone, Debug)]
struct Hunk<'a> {
    start: usize,
    end: usize,
    lines: Vec<&'a str>,
}

fn hunks<'a>(base: &[&str], side: &[&'a str]) -> Option<Vec<Hunk<'a>>> {
    let width = side.len() + 1;
    let cells = (base.len() + 1).checked_mul(width)?;
    if cells > MAX_CELLS {
        return None;
    }
    let mut lcs = vec![0u32; cells];
    for i in (0..base.len()).rev() {
        for j in (0..side.len()).rev() {
            lcs[i * width + j] = if base[i] == side[j] {
                1 + lcs[(i + 1) * width + j + 1]
            } else {
                lcs[(i + 1) * width + j].max(lcs[i * width + j + 1])
            };
        }
    }
    let (mut i, mut j) = (0, 0);
    let mut out = Vec::new();
    while i < base.len() || j < side.len() {
        if i < base.len() && j < side.len() && base[i] == side[j] {
            i += 1;
            j += 1;
            continue;
        }
        let start = i;
        let mut lines = Vec::new();
        while i < base.len() || j < side.len() {
            if i < base.len() && j < side.len() && base[i] == side[j] {
                break;
            }
            if j < side.len()
                && (i == base.len() || lcs[i * width + j + 1] > lcs[(i + 1) * width + j])
            {
                lines.push(side[j]);
                j += 1;
            } else {
                i += 1;
            }
        }
        out.push(Hunk {
            start,
            end: i,
            lines,
        });
    }
    Some(out)
}

fn overlap(a: &Hunk<'_>, b: &Hunk<'_>) -> bool {
    if a.start == a.end || b.start == b.end {
        a.start <= b.end && b.start <= a.end
    } else {
        a.start < b.end && b.start < a.end
    }
}

fn render(base: &[&str], start: usize, end: usize, changes: &[&Hunk<'_>]) -> String {
    let mut out = String::new();
    let mut cursor = start;
    for h in changes {
        for line in &base[cursor..h.start] {
            out.push_str(line);
        }
        for line in &h.lines {
            out.push_str(line);
        }
        cursor = h.end;
    }
    for line in &base[cursor..end] {
        out.push_str(line);
    }
    out
}

pub(super) fn is_text(bytes: &[u8]) -> bool {
    !bytes.contains(&0) && std::str::from_utf8(bytes).is_ok()
}

/// None means the deterministic size/complexity budget was exceeded.
pub(super) fn merge(base: &[u8], ours: &[u8], theirs: &[u8]) -> Option<(Vec<u8>, bool)> {
    if [base, ours, theirs]
        .iter()
        .any(|b| b.len() > MAX_BYTES || !is_text(b))
    {
        return None;
    }
    let b: Vec<_> = std::str::from_utf8(base)
        .ok()?
        .split_inclusive('\n')
        .collect();
    let o: Vec<_> = std::str::from_utf8(ours)
        .ok()?
        .split_inclusive('\n')
        .collect();
    let t: Vec<_> = std::str::from_utf8(theirs)
        .ok()?
        .split_inclusive('\n')
        .collect();
    if [b.len(), o.len(), t.len()].iter().any(|n| *n > MAX_LINES) {
        return None;
    }
    let oh = hunks(&b, &o)?;
    let th = hunks(&b, &t)?;
    let mut edits: Vec<_> = oh
        .iter()
        .map(|h| (h, false))
        .chain(th.iter().map(|h| (h, true)))
        .collect();
    edits.sort_by_key(|(h, side)| (h.start, h.end, *side));
    let mut out = String::new();
    let mut cursor = 0;
    let mut pos = 0;
    let mut conflict = false;
    while pos < edits.len() {
        let mut stop = pos + 1;
        while stop < edits.len()
            && edits[pos..stop]
                .iter()
                .any(|(h, _)| overlap(h, edits[stop].0))
        {
            stop += 1;
        }
        let group = &edits[pos..stop];
        let start = group.iter().map(|(h, _)| h.start).min()?;
        let end = group.iter().map(|(h, _)| h.end).max()?;
        for line in &b[cursor..start] {
            out.push_str(line);
        }
        let ours: Vec<_> = group.iter().filter(|(_, s)| !*s).map(|(h, _)| *h).collect();
        let theirs: Vec<_> = group.iter().filter(|(_, s)| *s).map(|(h, _)| *h).collect();
        if ours.is_empty() {
            out.push_str(&render(&b, start, end, &theirs));
        } else if theirs.is_empty() {
            out.push_str(&render(&b, start, end, &ours));
        } else {
            let ov = render(&b, start, end, &ours);
            let tv = render(&b, start, end, &theirs);
            if ov == tv {
                out.push_str(&ov);
            } else {
                conflict = true;
                out.push_str("<<<<<<< OURS\n");
                out.push_str(&ov);
                if !ov.is_empty() && !ov.ends_with('\n') {
                    out.push('\n');
                }
                out.push_str("=======\n");
                out.push_str(&tv);
                if !tv.is_empty() && !tv.ends_with('\n') {
                    out.push('\n');
                }
                out.push_str(">>>>>>> THEIRS\n");
            }
        }
        cursor = end;
        pos = stop;
    }
    for line in &b[cursor..] {
        out.push_str(line);
    }
    Some((out.into_bytes(), conflict))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn independent_insert_delete_and_repeated_line_edits() {
        for (base, ours, theirs, want) in [
            (
                "a\nb\nc\n",
                "first\na\nb\nc\n",
                "a\nb\nc\nlast\n",
                "first\na\nb\nc\nlast\n",
            ),
            ("a\nb\nc\nd\n", "b\nc\nd\n", "a\nb\nc\nD\n", "b\nc\nD\n"),
            (
                "a\nx\na\ny\n",
                "A\nx\na\ny\n",
                "a\nx\na\nY\n",
                "A\nx\na\nY\n",
            ),
            ("", "same\n", "same\n", "same\n"),
            ("a\nb", "a\nB", "a\nB", "a\nB"),
        ] {
            assert_eq!(
                merge(base.as_bytes(), ours.as_bytes(), theirs.as_bytes()),
                Some((want.as_bytes().to_vec(), false))
            );
        }
        for i in 0..8 {
            for j in 0..8 {
                if i == j {
                    continue;
                }
                let base: Vec<_> = (0..8).map(|n| format!("line {n}\n")).collect();
                let mut ours = base.clone();
                ours[i] = "ours\n".into();
                let mut theirs = base.clone();
                theirs[j] = "theirs\n".into();
                let mut want = base.clone();
                want[i] = "ours\n".into();
                want[j] = "theirs\n".into();
                assert_eq!(
                    merge(
                        base.concat().as_bytes(),
                        ours.concat().as_bytes(),
                        theirs.concat().as_bytes()
                    ),
                    Some((want.concat().into_bytes(), false)),
                    "i={i} j={j}"
                );
            }
        }
    }

    #[test]
    fn overlapping_insertions_conflict_and_preserve_suffix_bytes() {
        let (bytes, conflict) = merge(b"a\r\nz", b"one\na\r\nz", b"two\na\r\nz").unwrap();
        assert!(conflict);
        assert!(bytes.starts_with(b"<<<<<<< OURS\none\n=======\ntwo\n>>>>>>> THEIRS\n"));
        assert!(bytes.ends_with(b"a\r\nz"));
    }
}
