use super::*;
use std::ffi::OsStr;
use std::time::UNIX_EPOCH;

impl Repo {
    fn work_name(&self, path: &Path) -> Result<String> {
        path.strip_prefix(&self.root)?
            .components()
            .map(|c| {
                c.as_os_str()
                    .to_str()
                    .map(str::to_owned)
                    .context("path is not UTF-8")
            })
            .collect::<Result<Vec<_>>>()
            .map(|parts| parts.join("/"))
    }

    // 枚举工作区候选文件，跳过元数据与构建目录。
    fn tracked_working_files(&self) -> Result<Vec<String>> {
        let mut files = Vec::new();
        for entry in WalkDir::new(&self.root)
            .into_iter()
            .filter_entry(|e| !Self::should_skip(e.path(), &self.root))
        {
            let entry = entry?;
            let p = entry.path();
            self.check_internal_path(p)?;
            if p.is_file() {
                let rel = self.work_name(p)?;
                files.push(rel);
            }
        }
        files.sort();
        Ok(files)
    }

    fn should_skip(path: &Path, root: &Path) -> bool {
        let Some(rel) = path.strip_prefix(root).ok() else {
            return false;
        };
        let Some(first) = rel.components().next() else {
            return false;
        };

        let name = first.as_os_str();
        name == OsStr::new(META_DIR) || name == OsStr::new("target") || name == OsStr::new(".git")
    }

    // 将文件或目录递归加入暂存区。
    pub fn add_paths(&self, paths: &[String]) -> Result<()> {
        self.require_worktree()?;
        if paths.is_empty() {
            bail!("usage: myvcs add <path> [path ...]")
        }
        crate::debug_log!("add paths count={}", paths.len());

        let mut index = self.read_index()?;
        let mut added = 0usize;

        for raw in paths {
            self.input_path(raw)?;
        }
        for raw in paths {
            let p = self.input_path(raw)?;
            if !p.exists() {
                bail!("path does not exist: {}", raw);
            }

            if p.is_file() {
                self.stage_one(&p, &mut index)?;
                added += 1;
                continue;
            }

            for e in WalkDir::new(&p)
                .into_iter()
                .filter_entry(|e| !Self::should_skip(e.path(), &self.root))
            {
                let e = e?;
                self.check_internal_path(e.path())?;
                if e.path().is_file() {
                    self.stage_one(e.path(), &mut index)?;
                    added += 1;
                }
            }
        }

        self.write_index(&index)?;
        println!("staged {} file(s)", added);
        Ok(())
    }

    // Validate every target before deleting any file.
    pub fn rm_paths(&self, paths: &[String]) -> Result<()> {
        self.require_worktree()?;
        if paths.is_empty() {
            bail!("usage: myvcs rm <path> [path ...]");
        }
        let mut index = self.read_index()?;
        let tree = self.head_tree()?;
        // A binary modify/delete conflict may preserve our deletion, so its
        // path is absent from both HEAD and index but still needs explicit rm.
        let conflicts = self.read_merge_conflicts()?;
        let tracked: BTreeSet<String> = tree
            .keys()
            .chain(index.entries.keys())
            .chain(conflicts.iter())
            .cloned()
            .collect();
        let mut targets = BTreeSet::new();
        for raw in paths {
            let candidate = self.input_path(raw)?;
            let prefix = self.work_name(&candidate)?;
            let matches: Vec<_> = tracked
                .iter()
                .filter(|p| {
                    prefix.is_empty() || **p == prefix || p.starts_with(&format!("{prefix}/"))
                })
                .cloned()
                .collect();
            if matches.is_empty() {
                bail!("path is not tracked: {raw}");
            }
            targets.extend(matches);
        }
        for name in &targets {
            self.work_path(name)?;
        }
        let count = targets.len();
        for name in targets {
            let p = self.work_path(&name)?;
            if p.exists() {
                fs::remove_file(&p)?;
            }
            index.entries.remove(&name);
            index.removed.insert(name);
        }
        self.write_index(&index)?;
        println!("staged removal of {count} file(s)");
        Ok(())
    }

    fn stage_one(&self, path: &Path, index: &mut Index) -> Result<()> {
        if Self::should_skip(path, &self.root) {
            return Ok(());
        }
        let rel = self.work_name(path)?;
        self.work_path(&rel)?;
        let oid = self
            .write_object_from_path(path)
            .with_context(|| format!("failed to write blob for {}", rel))?;
        index.entries.insert(rel.clone(), oid);
        index.removed.remove(&rel);
        Ok(())
    }

    // 展示已暂存、未暂存、未跟踪与冲突状态。
    pub fn status(&self) -> Result<()> {
        self.require_worktree()?;
        let head_tree = self.head_tree()?;
        let index = self.read_index()?;
        let files = self.tracked_working_files()?;
        let status_cache = self.read_status_cache()?;
        let mut new_cache = StatusCache::default();
        let conflicts = self.read_merge_conflicts()?;

        let mut staged = Vec::new();
        for (p, oid) in &index.entries {
            match head_tree.get(p) {
                Some(h) if h == oid => {}
                _ => staged.push(p.clone()),
            }
        }
        for p in &index.removed {
            if head_tree.contains_key(p) {
                staged.push(format!("deleted: {}", p));
            }
        }

        let mut modified = Vec::new();
        let tracked: BTreeSet<_> = head_tree
            .keys()
            .chain(index.entries.keys())
            .chain(index.removed.iter())
            .cloned()
            .collect();
        for p in tracked {
            // 已暂存删除应只出现在待提交列表，不能再次算作工作区删除。
            if index.removed.contains(&p) {
                continue;
            }
            let fp = self.work_path(&p)?;
            if !fp.exists() {
                if head_tree.contains_key(&p) {
                    modified.push(format!("deleted: {}", p));
                }
                continue;
            }
            let md = fs::metadata(&fp)
                .with_context(|| format!("failed to stat working file {}", fp.display()))?;
            let mtime_secs = md
                .modified()
                .ok()
                .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
                .map(|d| d.as_secs())
                .unwrap_or(0);
            let size = md.len();
            let staged_hash = index
                .entries
                .get(&p)
                .cloned()
                .or_else(|| head_tree.get(&p).cloned());

            if let Some(staged_hash) = staged_hash {
                let working_hash = if let Some(prev) = status_cache.entries.get(&p) {
                    if prev.mtime_secs == mtime_secs && prev.size == size {
                        prev.hash.clone()
                    } else {
                        hex_sha256_file(&fp).with_context(|| {
                            format!("failed to hash working file {}", fp.display())
                        })?
                    }
                } else {
                    hex_sha256_file(&fp)
                        .with_context(|| format!("failed to hash working file {}", fp.display()))?
                };

                new_cache.entries.insert(
                    p.clone(),
                    StatusCacheEntry {
                        mtime_secs,
                        size,
                        hash: working_hash.clone(),
                    },
                );

                if staged_hash != working_hash {
                    modified.push(format!("modified: {}", p));
                }
            }
        }

        // 缓存写入采用尽力而为策略；写失败不影响 status 输出。
        if let Err(e) = self.write_status_cache(&new_cache) {
            crate::debug_log!("status cache write skipped: {}", e);
        }

        let tracked_set: BTreeSet<_> = tracked_working_set(&head_tree, &index);
        let mut untracked = Vec::new();
        for p in files {
            if !tracked_set.contains(&p) {
                untracked.push(p);
            }
        }

        println!(
            "On branch {}",
            self.current_branch_name()
                .unwrap_or_else(|| "(detached HEAD)".to_string())
        );

        if staged.is_empty() {
            println!("\nNo staged changes");
        } else {
            println!("\nChanges to be committed:");
            for p in staged {
                println!("  {}", p);
            }
        }

        if modified.is_empty() {
            println!("\nNo unstaged changes");
        } else {
            println!("\nChanges not staged for commit:");
            for p in modified {
                println!("  {}", p);
            }
        }

        if untracked.is_empty() {
            println!("\nNo untracked files");
        } else {
            println!("\nUntracked files:");
            for p in untracked {
                println!("  {}", p);
            }
        }

        if !conflicts.is_empty() {
            println!("\nMerge conflicts:");
            for p in conflicts {
                println!("  {}", p);
            }
        }

        Ok(())
    }

    // 对比工作区与 HEAD 快照差异。
    pub fn diff(&self, path: Option<&str>) -> Result<()> {
        self.require_worktree()?;
        let head_tree = self.head_tree()?;
        let mut targets = Vec::new();
        if let Some(p) = path {
            targets.push(p.to_string());
        } else {
            let set: BTreeSet<String> = head_tree.keys().cloned().collect();
            targets.extend(set);
        }

        if targets.is_empty() {
            println!("nothing to diff");
            return Ok(());
        }

        for p in targets {
            let old = match head_tree.get(&p) {
                Some(oid) => Some(self.read_blob_resolved(oid)?),
                None => None,
            };
            let work_path = self.work_path(&p)?;
            let new = if work_path.exists() {
                Some(fs::read(&work_path).with_context(|| {
                    format!("failed to read working file {}", work_path.display())
                })?)
            } else {
                None
            };

            if old == new {
                continue;
            }

            println!("diff -- {}", p);
            print_text_diff_or_binary(&p, old.as_deref(), new.as_deref());
            println!();
        }

        Ok(())
    }
}
