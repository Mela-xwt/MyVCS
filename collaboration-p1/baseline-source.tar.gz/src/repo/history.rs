use super::*;

impl Repo {
    // 基于暂存新增/修改与暂存删除构建新提交。
    pub fn commit(&self, message: &str) -> Result<()> {
        self.require_worktree()?;
        crate::debug_log!("commit start message={}", message);
        let index = self.read_index()?;
        let merge_head = self.read_merge_head()?;
        self.check_merge_commit_state(&index, merge_head.as_deref())?;
        for path in self.read_merge_conflicts()? {
            if !index.entries.contains_key(&path) && !index.removed.contains(&path) {
                bail!(
                    "unresolved merge conflict: {}; resolve and stage it before committing",
                    path
                );
            }
        }
        if index.entries.is_empty() && index.removed.is_empty() {
            bail!("nothing to commit (index is empty)")
        }

        // 先应用删除，再应用新增/修改。
        let mut tree = self.head_tree()?;
        for p in &index.removed {
            tree.remove(p);
        }
        for (p, oid) in index.entries {
            tree.insert(p, oid);
        }

        let parent = self.head_commit_id()?;
        let mut parents: Vec<String> = parent.into_iter().collect();
        if let Some(merge_head) = merge_head {
            // 在移动 HEAD 前确认第二父提交仍然存在且有效。
            self.read_commit(&merge_head)?;
            parents.push(merge_head);
        }
        let author = self.author_identity()?;
        let timestamp = now_unix() as i64;
        let commit = Commit {
            tree,
            parents,
            parent: None,
            message: message.to_string(),
            author,
            timestamp,
        };

        let raw = serde_json::to_vec(&commit)?;
        // 新建提交对象为 Hot，使用快速压缩
        let id = self.write_object_with_temp(&raw, crate::util::BlobTemperature::Hot)?;
        self.update_head_to_commit(&id)?;
        self.write_index(&Index::default())?;
        self.clear_merge_state()?;
        crate::debug_log!("commit done id={}", id);
        println!("[{}] {}", short_id(&id), message);
        Ok(())
    }

    // 从 HEAD 向后打印提交链。
    pub fn log(&self) -> Result<()> {
        self.log_with_options(false, false)
    }

    // 将工作区恢复到目标提交，并移动 HEAD。
    pub fn reset_hard(&self, commit: &str) -> Result<()> {
        self.require_worktree()?;
        let current = self.head_tree()?;
        let target = self.read_commit(commit)?;
        let prepared = self.prepare_head_commit_locked(commit, "reset hard")?;
        self.restore_tree(&current, &target.tree)?;
        if let Some(p) = prepared {
            self.publish_refs_locked(p)?;
        } else {
            self.update_head_to_commit(commit)?;
        }
        self.write_index(&Index::default())?;
        self.clear_merge_state()?;
        println!("HEAD is now at {}", short_id(commit));
        Ok(())
    }
}
