use super::*;
use serde::{Deserialize, Serialize};

const MAX_ATTEMPTS: usize = 10_000;
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Policy {
    version: u32,
    #[serde(deserialize_with = "unique_users")]
    users: BTreeMap<String, Permissions>,
}
fn unique_users<'de, D: serde::Deserializer<'de>>(
    d: D,
) -> std::result::Result<BTreeMap<String, Permissions>, D::Error> {
    struct Visitor;
    impl<'de> serde::de::Visitor<'de> for Visitor {
        type Value = BTreeMap<String, Permissions>;
        fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
            f.write_str("unique principal keys")
        }
        fn visit_map<A: serde::de::MapAccess<'de>>(
            self,
            mut map: A,
        ) -> std::result::Result<Self::Value, A::Error> {
            let mut users = BTreeMap::new();
            while let Some((key, value)) = map.next_entry::<String, Permissions>()? {
                if users.insert(key, value).is_some() {
                    return Err(serde::de::Error::custom("duplicate policy principal"));
                }
            }
            Ok(users)
        }
    }
    d.deserialize_map(Visitor)
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Permissions {
    read: bool,
    write: Vec<String>,
    force: Vec<String>,
    delete: Vec<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AuditEntry {
    pub actor: String,
    pub op: String,
    pub refs: Vec<RefChange>,
    pub result: String,
    pub time: u64,
}
pub(super) fn principal() -> Result<Option<String>> {
    let value = std::env::var("MYVCS_PRINCIPAL").ok();
    if let Some(v) = &value {
        validate_actor(v)?;
    }
    Ok(value)
}
fn validate_actor(actor: &str) -> Result<()> {
    if actor.is_empty()
        || actor.len() > 128
        || !actor
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b"._@-".contains(&b))
    {
        bail!("denied: invalid operator principal");
    }
    Ok(())
}
fn validate_pattern(pattern: &str) -> Result<()> {
    let full = if let Some(prefix) = pattern.strip_suffix("/*") {
        format!("{prefix}/placeholder")
    } else {
        pattern.into()
    };
    validate_ref(&full)?;
    if !full.starts_with("refs/heads/") && !full.starts_with("refs/tags/") {
        bail!("policy pattern must name heads or tags");
    }
    Ok(())
}
fn matches(patterns: &[String], name: &str) -> bool {
    patterns.iter().any(|p| {
        if let Some(prefix) = p.strip_suffix('*') {
            name.starts_with(prefix)
        } else {
            p == name
        }
    })
}
impl Repo {
    pub(super) fn load_policy(&self) -> Result<Option<Policy>> {
        let path = self.meta.join("policy.json");
        self.check_internal_path(&path)?;
        if !path.exists() {
            return Ok(None);
        }
        let p: Policy =
            serde_json::from_str(&self.read_metadata(&path)?).context("invalid policy schema")?;
        if p.version != 1 || p.users.len() > 256 {
            bail!("invalid policy version or user count");
        }
        for (actor, u) in &p.users {
            validate_actor(actor)?;
            for patterns in [&u.write, &u.force, &u.delete] {
                if patterns.len() > 256 {
                    bail!("too many policy patterns");
                }
                for pattern in patterns {
                    validate_pattern(pattern).context("invalid policy pattern")?;
                }
            }
        }
        Ok(Some(p))
    }
    pub(super) fn authorize_read(&self, actor: Option<&str>) -> Result<()> {
        if let Some(p) = self.load_policy()? {
            let u = actor
                .and_then(|a| p.users.get(a))
                .context("denied: missing or unknown principal")?;
            if !u.read {
                bail!("denied: repository read permission");
            }
        }
        Ok(())
    }
    pub(super) fn authorize_write(
        &self,
        actor: Option<&str>,
        changes: &[RefChange],
        force: &BTreeSet<String>,
    ) -> Result<()> {
        let Some(p) = self.load_policy()? else {
            if !force.is_empty() || changes.iter().any(|c| c.new.is_none()) {
                bail!("denied: force and deletion require explicit policy permission");
            }
            return Ok(());
        };
        if self.format_version()? != 2 {
            bail!(
                "policy-managed writes require format 2; stop old processes and upgrade --quiescent"
            );
        }
        let u = actor
            .and_then(|a| p.users.get(a))
            .context("denied: missing or unknown principal")?;
        if !u.read {
            bail!("denied: repository read permission");
        }
        for c in changes {
            if !matches(&u.write, &c.name) {
                bail!("denied: write permission for {}", c.name);
            }
            if c.new.is_none() && !matches(&u.delete, &c.name) {
                bail!("denied: delete permission for {}", c.name);
            }
            if force.contains(&c.name) && !matches(&u.force, &c.name) {
                bail!("denied: force permission for {}", c.name);
            }
        }
        Ok(())
    }
    fn audit_attempts(&self) -> Result<Vec<AuditEntry>> {
        let path = self.meta.join("audit-attempts.json");
        self.check_internal_path(&path)?;
        if !path.exists() {
            return Ok(Vec::new());
        }
        let events: Vec<AuditEntry> = serde_json::from_str(&self.read_metadata(&path)?)?;
        if events.len() > MAX_ATTEMPTS {
            bail!("audit journal exceeds limit");
        }
        for e in &events {
            if e.actor != "anonymous" {
                validate_actor(&e.actor)?;
            }
            if !matches!(e.op.as_str(), "read" | "push" | "session")
                || !matches!(e.result.as_str(), "allowed" | "denied" | "failed")
                || e.refs.len() > 256
            {
                bail!("invalid audit record");
            }
            for c in &e.refs {
                validate_ref(&c.name)?;
                if let Some(id) = &c.expected {
                    validate_oid(id)?;
                }
                if let Some(id) = &c.new {
                    validate_oid(id)?;
                }
            }
        }
        Ok(events)
    }
    pub(super) fn audit_attempt_locked(
        &self,
        actor: Option<&str>,
        op: &str,
        refs: &[RefChange],
        result: &str,
    ) -> Result<()> {
        // Single-account repositories also retain read/failed attempts, bounded explicitly.
        let mut events = self.audit_attempts()?;
        if events.len() >= MAX_ATTEMPTS {
            bail!("audit journal full; operator must export then audit expire --keep N");
        }
        events.push(AuditEntry {
            actor: actor.unwrap_or("anonymous").into(),
            op: op.into(),
            refs: refs.to_vec(),
            result: result.into(),
            time: now_unix(),
        });
        let raw = serde_json::to_vec(&events)?;
        if raw.len() > self.limits.metadata_bytes {
            bail!("audit metadata limit exceeded; export then audit expire --keep N");
        }
        self.atomic_write(&self.meta.join("audit-attempts.json"), &raw)
    }
    pub fn audit_list(&self, limit: usize) -> Result<Vec<AuditEntry>> {
        if limit > MAX_ATTEMPTS {
            bail!("audit list limit must be <=10000");
        }
        self.with_repo_lock(|r| {
            let mut events = r.audit_attempts()?;
            let success = if r.format_version()? == 2 {
                r.reflog(None)?
            } else {
                Vec::new()
            };
            for e in success {
                if e.reason == "remote push" && e.name != "HEAD" {
                    events.push(AuditEntry {
                        actor: e.actor,
                        op: "push".into(),
                        refs: vec![RefChange {
                            name: e.name,
                            expected: e.old,
                            new: e.new,
                        }],
                        result: "success".into(),
                        time: e.timestamp.max(0) as u64,
                    });
                }
            }
            events.sort_by_key(|e| e.time);
            let start = events.len().saturating_sub(limit);
            Ok(events.into_iter().skip(start).collect())
        })
    }
    pub fn audit_expire(&self, keep: usize) -> Result<()> {
        self.with_repo_lock(|r| {
            let mut events = r.audit_attempts()?;
            if keep < events.len() {
                events.drain(..events.len() - keep);
            }
            r.atomic_write(
                &r.meta.join("audit-attempts.json"),
                &serde_json::to_vec(&events)?,
            )
        })
    }
}
