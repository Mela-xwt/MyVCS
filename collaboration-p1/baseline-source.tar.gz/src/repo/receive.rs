use super::*;
use sha2::{Digest, Sha256};

/// Stage 0 accepts full logical object bytes, not a network packfile.
#[derive(Debug, Clone)]
pub struct ReceiveLimits {
    pub max_object_bytes: usize,
    pub max_total_bytes: usize,
    pub max_objects: usize,
}
impl Default for ReceiveLimits {
    fn default() -> Self {
        Self {
            max_object_bytes: 256 * 1024 * 1024,
            max_total_bytes: 512 * 1024 * 1024,
            max_objects: 100_000,
        }
    }
}

#[derive(Debug, Clone)]
pub struct RefUpdate {
    pub name: String,
    pub expected: Option<String>,
    pub new: String,
    pub allow_non_fast_forward: bool,
}

pub struct ReceiveTransaction {
    repo: Repo,
    directory: PathBuf,
    limits: ReceiveLimits,
    staged: BTreeSet<String>,
    total: usize,
    failed: bool,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
enum PublishPoint {
    Validated,
    ObjectInstalled(usize),
    BeforeRef,
    AfterRef,
}

impl Repo {
    pub fn begin_receive(&self, limits: ReceiveLimits) -> Result<ReceiveTransaction> {
        if limits.max_object_bytes == 0
            || limits.max_object_bytes > self.limits.object_bytes
            || limits.max_total_bytes == 0
            || limits.max_objects == 0
            || limits.max_objects > self.limits.graph_objects
        {
            bail!("invalid receive limits");
        }
        let directory = self.meta.join("incoming").join(unique_suffix());
        self.create_dirs_durable(&directory)?;
        Ok(ReceiveTransaction {
            repo: self.clone(),
            directory,
            limits,
            staged: BTreeSet::new(),
            total: 0,
            failed: false,
        })
    }
}

impl ReceiveTransaction {
    /// Copies an explicitly negotiated small base into this session while the
    /// caller holds the repository lock. GC never touches incoming directories.
    pub(super) fn pin_base(&mut self, oid: &str, limit: usize) -> Result<bool> {
        validate_oid(oid)?;
        if !self.repo.object_path(oid)?.exists() {
            return Ok(false);
        }
        let mut view = self.repo.clone();
        view.limits.object_bytes = limit;
        view.limits.chain_bytes = limit * 4;
        let raw = view.read_blob_resolved(oid)?;
        self.stage_object(oid, raw.as_slice())?;
        Ok(true)
    }

    /// Only session-owned, fully expanded objects may serve as network bases.
    /// In particular, never fall back to an unpinned main-store object.
    pub(super) fn staged_bytes(&self, oid: &str, limit: usize) -> Result<Vec<u8>> {
        validate_oid(oid)?;
        if !self.staged.contains(oid) {
            bail!("delta base is missing or unconfirmed");
        }
        let f = File::open(self.directory.join(oid))?;
        let mut raw = Vec::new();
        flate2::read::ZlibDecoder::new(f)
            .take(limit as u64 + 1)
            .read_to_end(&mut raw)?;
        if raw.len() > limit {
            bail!("delta base size limit exceeded");
        }
        if hex_sha256(&raw) != oid {
            bail!("delta base hash mismatch");
        }
        Ok(raw)
    }

    /// A failed stage poisons the session. No refs are modified by staging.
    pub fn stage_object(&mut self, oid: &str, mut reader: impl Read) -> Result<()> {
        if self.failed {
            bail!("receive transaction already failed");
        }
        let result = (|| -> Result<()> {
            validate_oid(oid)?;
            if self.staged.len() >= self.limits.max_objects {
                bail!("receive object count limit exceeded");
            }
            if self.staged.contains(oid) {
                bail!("duplicate received object");
            }
            let path = self.directory.join(oid);
            self.repo.check_internal_path(&path)?;
            let f = OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(&path)?;
            let mut encoder = ZlibEncoder::new(f, flate2::Compression::default());
            let mut hash = Sha256::new();
            let mut buffer = [0u8; 64 * 1024];
            let mut bytes = 0usize;
            loop {
                // Read at most one byte beyond the remaining quota.
                let remaining = self
                    .limits
                    .max_object_bytes
                    .saturating_sub(bytes)
                    .min(self.limits.max_total_bytes.saturating_sub(self.total));
                let n = reader.read(&mut buffer[..remaining.saturating_add(1).min(64 * 1024)])?;
                if n == 0 {
                    break;
                }
                if n > remaining {
                    bail!("receive byte limit exceeded");
                }
                bytes += n;
                self.total += n;
                hash.update(&buffer[..n]);
                encoder.write_all(&buffer[..n])?;
            }
            if crate::util::digest_to_hex(&hash.finalize()) != oid {
                bail!("received object hash mismatch");
            }
            let f = encoder.finish()?;
            f.sync_all()?;
            drop(f);
            sync_directory(&self.directory)?;
            self.staged.insert(oid.to_owned());
            Ok(())
        })();
        if result.is_err() {
            self.failed = true;
        }
        result
    }

    /// Publish one ref using CAS. Ref rename is the commit point. After it, an
    /// error/connection loss can mean success; callers must re-read the ref.
    pub fn commit(self, update: RefUpdate) -> Result<()> {
        self.publish(update, |_| Ok(()))
    }

    /// Atomic format-2 receive. `authorize` runs under the repository lock,
    /// after complete CAS/closure/candidate validation and before installation.
    /// Its Repo is the validated incoming overlay; do not reacquire its lock.
    pub fn commit_many(
        self,
        changes: &[RefChange],
        allow_non_fast_forward: &BTreeSet<String>,
        actor: &str,
        reason: &str,
        authorize: impl FnOnce(&Repo, &RefSnapshot, &[RefChange]) -> Result<()>,
    ) -> Result<()> {
        self.publish_many(
            changes,
            allow_non_fast_forward,
            actor,
            reason,
            authorize,
            |_| Ok(()),
        )
    }

    fn publish_many(
        self,
        changes: &[RefChange],
        allowed: &BTreeSet<String>,
        actor: &str,
        reason: &str,
        authorize: impl FnOnce(&Repo, &RefSnapshot, &[RefChange]) -> Result<()>,
        mut checkpoint: impl FnMut(PublishPoint) -> Result<()>,
    ) -> Result<()> {
        if self.failed {
            bail!("receive transaction already failed");
        }
        self.repo.with_repo_lock(|repo| {
            if repo.format_version()? != 2 {
                bail!("atomic receive requires format 2; run `myvcs upgrade --quiescent`");
            }
            let snapshot = repo.refs_snapshot()?;
            let mut view = repo.clone();
            view.overlay = Some(self.directory.clone());
            view.commit_graph = Arc::new(Mutex::new(None));
            // Preparation validates every CAS, name and complete new closure,
            // and serializes within the metadata cap before object installation.
            let prepared = view.prepare_refs_locked(changes, None, actor, reason)?;
            for n in allowed {
                validate_ref(n)?;
                if !changes.iter().any(|c| &c.name == n) {
                    bail!("force allowance names an absent command");
                }
            }
            let mut closure = BTreeSet::new();
            for c in changes {
                if snapshot.current_ref() == Some(c.name.as_str())
                    && (!repo.bare || c.new.is_none())
                {
                    bail!("receive cannot update checked-out branch or delete HEAD branch");
                }
                if let Some(new) = &c.new {
                    closure.extend(view.validate_closure(new)?);
                    if closure.len() > self.limits.max_objects
                        || closure.len() > repo.limits.graph_objects
                    {
                        bail!("receive union object count limit exceeded");
                    }
                    if !allowed.contains(&c.name) {
                        if let Some(old) = &c.expected {
                            if !view.is_ancestor(old, new)? {
                                bail!("non-fast-forward update rejected");
                            }
                        }
                    }
                } else if !allowed.contains(&c.name) {
                    bail!("reference deletion requires explicit allowance");
                }
            }
            let mut bytes = 0usize;
            for oid in &closure {
                bytes = bytes
                    .checked_add(view.read_blob_resolved(oid)?.len())
                    .context("receive union byte overflow")?;
                if bytes > self.limits.max_total_bytes {
                    bail!("receive union byte limit exceeded");
                }
            }
            authorize(&view, &snapshot, changes)?;
            checkpoint(PublishPoint::Validated)?;
            let mut installed = 0;
            for oid in self.staged.intersection(&closure) {
                let source = self.directory.join(oid);
                let dest = repo.object_path(oid)?;
                if dest.exists() {
                    repo.read_blob_resolved(oid)?;
                } else {
                    repo.create_dirs_durable(dest.parent().unwrap())?;
                    fs::rename(&source, &dest)?;
                    sync_directory(dest.parent().unwrap())?;
                    sync_directory(&self.directory)?;
                }
                installed += 1;
                checkpoint(PublishPoint::ObjectInstalled(installed))?;
            }
            checkpoint(PublishPoint::BeforeRef)?;
            repo.publish_refs_locked(prepared)?;
            checkpoint(PublishPoint::AfterRef)
        })
    }

    // Keep FETCH_HEAD publication in the same lock interval as its tracking ref.
    // Otherwise a concurrent fetch + GC could remove the older fetched tip before
    // this session records it as an additional root.
    pub(super) fn commit_fetch(self, update: RefUpdate) -> Result<()> {
        let repo = self.repo.clone();
        let record = format!("{}\t{}\n", update.new, update.name);
        self.publish(update, |point| {
            if point == PublishPoint::AfterRef {
                repo.atomic_write(&repo.meta.join("FETCH_HEAD"), record.as_bytes())?;
            }
            Ok(())
        })
    }

    fn publish(
        self,
        update: RefUpdate,
        checkpoint: impl FnMut(PublishPoint) -> Result<()>,
    ) -> Result<()> {
        self.publish_with_authorization(update, checkpoint, |_| Ok(()))
    }

    pub(super) fn publish_authorized(
        self,
        update: RefUpdate,
        authorize: impl FnOnce(&Repo) -> Result<()>,
    ) -> Result<()> {
        self.publish_with_authorization(update, |_| Ok(()), authorize)
    }
    fn publish_with_authorization(
        self,
        update: RefUpdate,
        mut checkpoint: impl FnMut(PublishPoint) -> Result<()>,
        authorize: impl FnOnce(&Repo) -> Result<()>,
    ) -> Result<()> {
        if self.repo.format_version()? == 2 {
            let allowed = if update.allow_non_fast_forward {
                [update.name.clone()].into_iter().collect()
            } else {
                BTreeSet::new()
            };
            return self.publish_many(
                &[RefChange {
                    name: update.name,
                    expected: update.expected,
                    new: Some(update.new),
                }],
                &allowed,
                &std::env::var("USER")
                    .or_else(|_| std::env::var("USERNAME"))
                    .unwrap_or_else(|_| "unknown".into()),
                "receive",
                |repo, _, _| authorize(repo),
                checkpoint,
            );
        }
        if self.failed {
            bail!("receive transaction already failed");
        }
        self.repo.with_repo_lock(|repo| {
            validate_ref(&update.name)?;
            if repo.format_version()? == 1 {
                repo.ref_path(&update.name)?;
            }
            validate_oid(&update.new)?;
            if let Some(id) = &update.expected {
                validate_oid(id)?;
            }
            if !repo.bare && repo.current_ref()?.as_deref() == Some(&update.name) {
                bail!("receive cannot update the checked-out branch; use a bare repository");
            }
            if repo.read_ref(&update.name)? != update.expected {
                bail!("reference changed concurrently");
            }
            let mut view = repo.clone();
            view.overlay = Some(self.directory.clone());
            view.commit_graph = Arc::new(Mutex::new(None));
            let closure = view.validate_closure(&update.new)?;
            if !update.allow_non_fast_forward {
                if let Some(old) = &update.expected {
                    if !view.is_ancestor(old, &update.new)? {
                        bail!("non-fast-forward update rejected");
                    }
                }
            }
            // A handle opened while format 1 may wait behind an upgrade.
            // Prepare format-2 metadata under this same lock before installing.
            let prepared = if repo.format_version()? == 2 {
                Some(
                    view.prepare_refs_locked(
                        &[RefChange {
                            name: update.name.clone(),
                            expected: update.expected.clone(),
                            new: Some(update.new.clone()),
                        }],
                        None,
                        &std::env::var("USER")
                            .or_else(|_| std::env::var("USERNAME"))
                            .unwrap_or_else(|_| "unknown".into()),
                        "receive",
                    )?,
                )
            } else {
                None
            };
            authorize(&view)?;
            checkpoint(PublishPoint::Validated)?;
            let mut installed = 0;
            // Only install objects reachable from the proposed tip. Orphans from a
            // failed publication are safe and can be collected by the next GC.
            for oid in self.staged.intersection(&closure) {
                let source = self.directory.join(oid);
                let dest = repo.object_path(oid)?;
                if dest.exists() {
                    repo.read_blob_resolved(oid)?;
                } else {
                    repo.create_dirs_durable(dest.parent().unwrap())?;
                    fs::rename(&source, &dest)?;
                    sync_directory(dest.parent().unwrap())?;
                    sync_directory(&self.directory)?;
                }
                installed += 1;
                checkpoint(PublishPoint::ObjectInstalled(installed))?;
            }
            checkpoint(PublishPoint::BeforeRef)?;
            if let Some(p) = prepared {
                repo.publish_refs_locked(p)?;
            } else {
                repo.update_ref_locked(&update.name, update.expected.as_deref(), &update.new)?;
            }
            checkpoint(PublishPoint::AfterRef)?;
            Ok(())
        })
    }
}

impl Drop for ReceiveTransaction {
    fn drop(&mut self) {
        // Only our generated child under incoming is eligible for cleanup.
        if self.directory.parent() == Some(self.repo.meta.join("incoming").as_path())
            && self.repo.check_internal_path(&self.directory).is_ok()
        {
            let _ = fs::remove_dir_all(&self.directory);
            let _ = sync_directory(&self.repo.meta.join("incoming"));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Launched only by the parent test. process::exit skips all Drop cleanup.
    #[test]
    fn crash_worker() {
        let Ok(dir) = std::env::var("MYVCS_TEST_CRASH_REPO") else {
            return;
        };
        let point: usize = std::env::var("MYVCS_TEST_CRASH_POINT")
            .unwrap()
            .parse()
            .unwrap();
        let repo = Repo::open(&dir).unwrap();
        let old = repo.head_commit_id().unwrap();
        let blob = b"crash content";
        let bid = hex_sha256(blob);
        let c = Commit {
            tree: [("file.txt".into(), bid.clone())].into(),
            parents: old.clone().into_iter().collect(),
            parent: None,
            message: "crash".into(),
            author: "test".into(),
            timestamp: 1,
        };
        let raw = serde_json::to_vec(&c).unwrap();
        let cid = hex_sha256(&raw);
        let mut tx = repo.begin_receive(ReceiveLimits::default()).unwrap();
        tx.stage_object(&bid, &blob[..]).unwrap();
        tx.stage_object(&cid, &raw[..]).unwrap();
        let mut n = 0;
        tx.publish(
            RefUpdate {
                name: "refs/heads/main".into(),
                expected: old,
                new: cid,
                allow_non_fast_forward: false,
            },
            |_| {
                if n == point {
                    std::process::exit(73);
                }
                n += 1;
                Ok(())
            },
        )
        .unwrap();
        panic!("requested crash point was not reached");
    }

    #[test]
    fn abrupt_process_exit_preserves_old_or_complete_new_ref() {
        for point in 0..5 {
            let dir = std::env::temp_dir().join(format!("myvcs-crash-{}", unique_suffix()));
            let repo = Repo::init_at(&dir, true, true).unwrap();
            let c = Commit {
                tree: BTreeMap::new(),
                parents: vec![],
                parent: None,
                message: "old".into(),
                author: "test".into(),
                timestamp: 0,
            };
            let old = repo.write_object(&serde_json::to_vec(&c).unwrap()).unwrap();
            repo.update_ref("refs/heads/main", None, &old).unwrap();
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--exact", "repo::receive::tests::crash_worker"])
                .env("MYVCS_TEST_CRASH_REPO", &dir)
                .env("MYVCS_TEST_CRASH_POINT", point.to_string())
                .stdout(std::process::Stdio::null())
                .status()
                .unwrap();
            assert_eq!(status.code(), Some(73));
            let reopened = Repo::open(&dir).unwrap();
            let tip = reopened.head_commit_id().unwrap().unwrap();
            if point < 4 {
                assert_eq!(tip, old);
            } else {
                assert_ne!(tip, old);
            }
            reopened.verify().unwrap();
            reopened.with_repo_lock(|r| r.gc()).unwrap();
            reopened.verify().unwrap();
            fs::remove_dir_all(dir).unwrap();
        }
    }

    #[test]
    fn crash_many_worker() {
        let Ok(dir) = std::env::var("MYVCS_TEST_MANY_REPO") else {
            return;
        };
        let point: usize = std::env::var("MYVCS_TEST_MANY_POINT")
            .unwrap()
            .parse()
            .unwrap();
        let repo = Repo::open(dir).unwrap();
        let blob = b"multi receive crash";
        let bid = hex_sha256(blob);
        let raw = serde_json::to_vec(&Commit {
            tree: [("file.txt".into(), bid.clone())].into(),
            parents: vec![],
            parent: None,
            message: "received".into(),
            author: "test".into(),
            timestamp: 0,
        })
        .unwrap();
        let id = hex_sha256(&raw);
        let mut tx = repo.begin_receive(ReceiveLimits::default()).unwrap();
        tx.stage_object(&bid, &blob[..]).unwrap();
        tx.stage_object(&id, raw.as_slice()).unwrap();
        let changes = [
            RefChange {
                name: "refs/heads/main".into(),
                expected: None,
                new: Some(id.clone()),
            },
            RefChange {
                name: "refs/heads/second".into(),
                expected: None,
                new: Some(id),
            },
        ];
        let mut n = 0;
        tx.publish_many(
            &changes,
            &BTreeSet::new(),
            "alice",
            "batch",
            |_, _, _| Ok(()),
            |_| {
                if n == point {
                    std::process::exit(75);
                }
                n += 1;
                Ok(())
            },
        )
        .unwrap();
        panic!("missing crash point");
    }
    #[test]
    fn actual_process_loss_during_multi_receive_installs_or_publication() {
        for point in 0..5 {
            let dir = std::env::temp_dir().join(format!("myvcs-many-crash-{}", unique_suffix()));
            let r = Repo::init_at(&dir, true, true).unwrap();
            r.upgrade().unwrap();
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--exact", "repo::receive::tests::crash_many_worker"])
                .env("MYVCS_TEST_MANY_REPO", &dir)
                .env("MYVCS_TEST_MANY_POINT", point.to_string())
                .stdout(std::process::Stdio::null())
                .status()
                .unwrap();
            assert_eq!(status.code(), Some(75));
            let r = Repo::open(&dir).unwrap();
            let s = r.refs_snapshot().unwrap();
            if point < 4 {
                assert!(s.refs.is_empty());
                assert!(s.reflog.is_empty());
                assert_eq!(s.generation, 0);
            } else {
                assert_eq!(s.refs.len(), 2);
                assert_eq!(s.refs["refs/heads/main"], s.refs["refs/heads/second"]);
                assert_eq!(s.reflog.len(), 3);
                assert_eq!(s.generation, 1);
            }
            r.verify().unwrap();
            r.with_repo_lock(|r| r.gc()).unwrap();
            r.verify().unwrap();
            fs::remove_dir_all(dir).unwrap();
        }
    }

    #[test]
    fn failures_never_publish_a_dangling_ref() {
        for fail_at in [
            PublishPoint::Validated,
            PublishPoint::ObjectInstalled(1),
            PublishPoint::ObjectInstalled(2),
            PublishPoint::BeforeRef,
            PublishPoint::AfterRef,
        ] {
            let dir = std::env::temp_dir().join(format!("myvcs-failure-{}", unique_suffix()));
            let repo = Repo::init_at(&dir, true, true).unwrap();
            let blob = b"received content";
            let bid = hex_sha256(blob);
            let c = Commit {
                tree: [("file.txt".into(), bid.clone())].into(),
                parents: vec![],
                parent: None,
                message: "test".into(),
                author: "test".into(),
                timestamp: 1,
            };
            let raw = serde_json::to_vec(&c).unwrap();
            let cid = hex_sha256(&raw);
            let mut tx = repo.begin_receive(ReceiveLimits::default()).unwrap();
            tx.stage_object(&bid, &blob[..]).unwrap();
            tx.stage_object(&cid, &raw[..]).unwrap();
            let update = RefUpdate {
                name: "refs/heads/main".into(),
                expected: None,
                new: cid.clone(),
                allow_non_fast_forward: false,
            };
            assert!(
                tx.publish(update, |point| {
                    if point == fail_at {
                        bail!("injected failure: {point:?}");
                    }
                    Ok(())
                })
                .is_err()
            );
            let reopened = Repo::open(&dir).unwrap();
            assert_eq!(
                reopened.head_commit_id().unwrap(),
                if fail_at == PublishPoint::AfterRef {
                    Some(cid)
                } else {
                    None
                }
            );
            reopened.verify().unwrap();
            reopened.with_repo_lock(|r| r.gc()).unwrap();
            reopened.verify().unwrap();
            fs::remove_dir_all(dir).unwrap();
        }
    }
}
