use super::*;
use serde::{Deserialize, Deserializer};

const STATE_LIMIT: usize = 16 * 1024 * 1024;
const MAX_CHANGES: usize = 256;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RefChange {
    pub name: String,
    pub expected: Option<String>,
    pub new: Option<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReflogEntry {
    pub seq: u64,
    pub transaction: u64,
    pub name: String,
    pub old: Option<String>,
    pub new: Option<String>,
    pub reason: String,
    pub actor: String,
    pub timestamp: i64,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RefSnapshot {
    pub version: u32,
    pub generation: u64,
    pub head: String,
    #[serde(deserialize_with = "unique_refs")]
    pub refs: BTreeMap<String, String>,
    pub next_seq: u64,
    pub reflog: Vec<ReflogEntry>,
}
fn unique_refs<'de, D: Deserializer<'de>>(
    d: D,
) -> std::result::Result<BTreeMap<String, String>, D::Error> {
    struct Visitor;
    impl<'de> serde::de::Visitor<'de> for Visitor {
        type Value = BTreeMap<String, String>;
        fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
            f.write_str("unique reference names")
        }
        fn visit_map<M: serde::de::MapAccess<'de>>(
            self,
            mut m: M,
        ) -> std::result::Result<Self::Value, M::Error> {
            let mut out = BTreeMap::new();
            while let Some((k, v)) = m.next_entry::<String, String>()? {
                if out.insert(k, v).is_some() {
                    return Err(serde::de::Error::custom("duplicate reference key"));
                }
            }
            Ok(out)
        }
    }
    d.deserialize_map(Visitor)
}
impl RefSnapshot {
    pub fn current_ref(&self) -> Option<&str> {
        self.head.strip_prefix("ref:").map(str::trim)
    }
    pub fn head_commit_id(&self) -> Option<String> {
        match self.current_ref() {
            Some(r) => self.refs.get(r).cloned(),
            None => Some(self.head.clone()),
        }
    }
}
pub(super) struct PreparedRefs {
    bytes: Vec<u8>,
}
fn actor() -> String {
    std::env::var("USER")
        .or_else(|_| std::env::var("USERNAME"))
        .unwrap_or_else(|_| "unknown".into())
}
fn context_text(s: &str) -> Result<()> {
    if s.is_empty() || s.len() > 4096 || s.chars().any(char::is_control) {
        bail!("invalid reflog actor/reason (1..4096 bytes, no control characters)");
    }
    Ok(())
}
fn head_valid(raw: &str) -> Result<()> {
    if let Some(r) = raw.strip_prefix("ref: ") {
        validate_ref(r)?;
        if !r.starts_with("refs/heads/") {
            bail!("HEAD must point to a local branch");
        }
    } else {
        validate_oid(raw)?;
    }
    Ok(())
}
fn namespace(refs: &BTreeMap<String, String>) -> Result<()> {
    let mut names = BTreeSet::new();
    for (n, id) in refs {
        validate_ref(n)?;
        validate_oid(id)?;
        if !names.insert(n.to_lowercase()) {
            bail!("case-colliding references");
        }
    }
    for n in &names {
        for (i, _) in n.match_indices('/') {
            if names.contains(&n[..i]) {
                bail!("file/directory reference collision");
            }
        }
    }
    Ok(())
}
impl Repo {
    /// Rechecked on every snapshot and after acquiring a mutation lock.
    pub fn format_version(&self) -> Result<u32> {
        let p = self.meta.join("format.json");
        self.check_internal_path(&p)?;
        if !p.exists() {
            return Ok(1);
        }
        let v: serde_json::Value = serde_json::from_str(&self.read_metadata(&p)?)?;
        let n = v["version"].as_u64().context("invalid repository format")?;
        if n != 1 && n != 2 {
            bail!("unsupported repository format");
        }
        if v["bare"].as_bool() != Some(self.bare) {
            bail!("repository kind differs");
        }
        Ok(n as u32)
    }
    fn team_required(&self) -> Result<()> {
        if self.format_version()? != 2 {
            bail!(
                "team references require format 2; stop all old myvcs processes, then run `myvcs upgrade --quiescent`"
            );
        }
        Ok(())
    }
    pub fn refs_snapshot(&self) -> Result<RefSnapshot> {
        if self.format_version()? == 1 {
            return Ok(RefSnapshot {
                version: 1,
                generation: 0,
                head: self.head_raw_legacy()?,
                refs: self.list_refs_legacy()?,
                next_seq: 1,
                reflog: vec![],
            });
        }
        let p = self.meta.join("refs-state.json");
        let raw = self
            .read_metadata(&p)
            .context("format 2 requires valid refs-state.json; refusing legacy fallback")?;
        if raw.len() > STATE_LIMIT {
            bail!("refs-state size limit exceeded");
        }
        let state: RefSnapshot = serde_json::from_str(&raw).context("invalid refs-state.json")?;
        self.validate_ref_state(&state)?;
        Ok(state)
    }
    fn validate_ref_state(&self, s: &RefSnapshot) -> Result<()> {
        if s.version != 2 || s.next_seq == 0 {
            bail!("invalid refs-state schema/counter");
        }
        head_valid(&s.head)?;
        namespace(&s.refs)?;
        self.check_graph_size(s.refs.len())?;
        let mut previous = 0;
        let mut group = 0;
        let mut count = 0;
        for e in &s.reflog {
            if e.seq <= previous
                || e.seq >= s.next_seq
                || e.transaction == 0
                || e.transaction > s.generation
                || e.transaction < group
            {
                bail!("invalid reflog sequence/transaction");
            }
            if e.transaction == group {
                count += 1;
            } else {
                count = 1;
                group = e.transaction;
            }
            if count > MAX_CHANGES + 1 {
                bail!("invalid reflog transaction size");
            }
            previous = e.seq;
            if e.name != "HEAD" {
                validate_ref(&e.name)?;
            }
            for id in [&e.old, &e.new].into_iter().flatten() {
                validate_oid(id)?;
            }
            context_text(&e.actor)?;
            context_text(&e.reason)?;
        }
        Ok(())
    }
    fn encode_ref_state(&self, s: &RefSnapshot) -> Result<Vec<u8>> {
        self.validate_ref_state(s)?;
        struct Bounded {
            bytes: Vec<u8>,
            limit: usize,
        }
        impl Write for Bounded {
            fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
                if b.len() > self.limit.saturating_sub(self.bytes.len()) {
                    return Err(std::io::Error::other(
                        "refs-state metadata limit reached; run `myvcs reflog expire --keep N`",
                    ));
                }
                self.bytes.extend_from_slice(b);
                Ok(b.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let mut w = Bounded {
            bytes: vec![],
            limit: STATE_LIMIT.min(self.limits.metadata_bytes),
        };
        serde_json::to_writer(&mut w, s)?;
        Ok(w.bytes)
    }
    /// Caller must stop ALL old-version processes for the maintenance window.
    pub fn upgrade(&self) -> Result<()> {
        self.with_repo_lock(|r| {
            if r.format_version()? == 2 {
                r.refs_snapshot()?;
                return Ok(());
            }
            if r.meta.join("MERGE_HEAD").exists() || r.meta.join("merge-state.json").exists() {
                bail!("finish or abort merge before upgrade");
            }
            let mut s = r.refs_snapshot()?;
            head_valid(&s.head)?;
            s.version = 2;
            namespace(&s.refs)?;
            let mut closure = BTreeSet::new();
            for id in s.refs.values().cloned().chain(s.head_commit_id()) {
                closure.extend(r.validate_closure(&id)?);
                r.check_graph_size(closure.len())?;
            }
            let bytes = r.encode_ref_state(&s)?;
            r.atomic_write(&r.meta.join("refs-state.json"), &bytes)?;
            r.atomic_write(
                &r.meta.join("format.json"),
                format!("{{\"version\":2,\"bare\":{}}}\n", r.bare).as_bytes(),
            )
        })
    }
    pub fn transact_refs(&self, changes: &[RefChange], reason: &str) -> Result<()> {
        self.with_repo_lock(|r| r.transact_refs_locked(changes, reason))
    }
    pub(super) fn transact_refs_locked(&self, changes: &[RefChange], reason: &str) -> Result<()> {
        let p = self.prepare_refs_locked(changes, None, &actor(), reason)?;
        self.publish_refs_locked(p)
    }
    pub(super) fn prepare_refs_locked(
        &self,
        changes: &[RefChange],
        head: Option<&str>,
        actor: &str,
        reason: &str,
    ) -> Result<PreparedRefs> {
        self.team_required()?;
        let mut s = self.refs_snapshot()?;
        if (changes.is_empty() && head.is_none()) || changes.len() > MAX_CHANGES {
            bail!("reference transaction must contain 1..256 changes");
        }
        context_text(actor)?;
        context_text(reason)?;
        let old_head = s.head_commit_id();
        let mut seen = BTreeSet::new();
        let mut closure = BTreeSet::new();
        for c in changes {
            validate_ref(&c.name)?;
            if !seen.insert(c.name.to_lowercase()) {
                bail!("duplicate reference command");
            }
            if c.expected.is_none() && c.new.is_none() {
                bail!("cannot delete missing reference");
            }
            if let Some(id) = &c.expected {
                validate_oid(id)?;
            }
            if s.refs.get(&c.name) != c.expected.as_ref() {
                bail!("reference changed concurrently: {}", c.name);
            }
            if let Some(id) = &c.new {
                closure.extend(self.validate_closure(id)?);
                self.check_graph_size(closure.len())?;
                s.refs.insert(c.name.clone(), id.clone());
            } else {
                s.refs.remove(&c.name);
            }
        }
        if let Some(h) = head {
            head_valid(h)?;
            if !h.starts_with("ref: ") {
                self.validate_closure(h)?;
            }
            s.head = h.into();
        }
        namespace(&s.refs)?;
        s.generation = s
            .generation
            .checked_add(1)
            .context("reference generation exhausted")?;
        let mut endpoints: Vec<_> = changes
            .iter()
            .map(|c| (c.name.clone(), c.expected.clone(), c.new.clone()))
            .collect();
        let new_head = s.head_commit_id();
        if head.is_some() || old_head != new_head {
            endpoints.push(("HEAD".into(), old_head, new_head));
        }
        for (name, old, new) in endpoints {
            let seq = s.next_seq;
            s.next_seq = seq.checked_add(1).context("reflog sequence exhausted")?;
            s.reflog.push(ReflogEntry {
                seq,
                transaction: s.generation,
                name,
                old,
                new,
                reason: reason.into(),
                actor: actor.into(),
                timestamp: now_unix() as i64,
            });
        }
        Ok(PreparedRefs {
            bytes: self.encode_ref_state(&s)?,
        })
    }
    pub(super) fn publish_refs_locked(&self, p: PreparedRefs) -> Result<()> {
        self.atomic_write(&self.meta.join("refs-state.json"), &p.bytes)
            .context(
                "reference publication failed; reread refs to determine whether rename committed",
            )?;
        *self.commit_graph.lock().unwrap() = None;
        Ok(())
    }
    pub(super) fn prepare_head_locked(
        &self,
        raw: &str,
        reason: &str,
    ) -> Result<Option<PreparedRefs>> {
        if self.format_version()? == 2 {
            Ok(Some(self.prepare_refs_locked(
                &[],
                Some(raw),
                &actor(),
                reason,
            )?))
        } else {
            head_valid(raw)?;
            if !raw.starts_with("ref: ") {
                self.validate_closure(raw)?;
            }
            Ok(None)
        }
    }
    /// Caller must hold with_repo_lock; records HEAD endpoints in one state.
    pub fn set_head_locked(&self, raw: &str, reason: &str) -> Result<()> {
        let p = self.prepare_head_locked(raw, reason)?;
        self.publish_head_locked(raw, p)
    }
    pub(super) fn publish_head_locked(&self, raw: &str, p: Option<PreparedRefs>) -> Result<()> {
        if let Some(p) = p {
            self.publish_refs_locked(p)
        } else {
            self.atomic_write(&self.meta.join("HEAD"), format!("{raw}\n").as_bytes())
        }
    }
    pub(super) fn prepare_head_commit_locked(
        &self,
        id: &str,
        reason: &str,
    ) -> Result<Option<PreparedRefs>> {
        if self.format_version()? != 2 {
            self.validate_closure(id)?;
            return Ok(None);
        }
        let s = self.refs_snapshot()?;
        let edits: Vec<_> = s
            .current_ref()
            .map(|n| RefChange {
                name: n.into(),
                expected: s.refs.get(n).cloned(),
                new: Some(id.into()),
            })
            .into_iter()
            .collect();
        Ok(Some(self.prepare_refs_locked(
            &edits,
            if edits.is_empty() { Some(id) } else { None },
            &actor(),
            reason,
        )?))
    }
    pub fn reflog(&self, filter: Option<&str>) -> Result<Vec<ReflogEntry>> {
        self.team_required()?;
        if let Some(n) = filter {
            if n != "HEAD" {
                validate_ref(n)?;
            }
        }
        Ok(self
            .refs_snapshot()?
            .reflog
            .into_iter()
            .filter(|e| filter.is_none_or(|n| n == e.name))
            .collect())
    }
    pub fn reflog_expire(&self, keep: usize) -> Result<()> {
        if keep > STATE_LIMIT {
            bail!("invalid reflog keep limit");
        }
        self.with_repo_lock(|r| {
            r.team_required()?;
            let mut s = r.refs_snapshot()?;
            let remove = s.reflog.len().saturating_sub(keep);
            s.reflog.drain(..remove);
            s.generation = s
                .generation
                .checked_add(1)
                .context("reference generation exhausted")?;
            r.publish_refs_locked(PreparedRefs {
                bytes: r.encode_ref_state(&s)?,
            })
        })
    }
    pub fn recover(&self, oid: &str, branch: &str) -> Result<()> {
        validate_oid(oid)?;
        let n = format!("refs/heads/{branch}");
        validate_ref(&n)?;
        self.with_repo_lock(|r| {
            r.team_required()?;
            let s = r.refs_snapshot()?;
            if !s
                .reflog
                .iter()
                .any(|e| e.old.as_deref() == Some(oid) || e.new.as_deref() == Some(oid))
            {
                bail!("OID is not retained in reflog");
            }
            r.transact_refs_locked(
                &[RefChange {
                    name: n,
                    expected: None,
                    new: Some(oid.into()),
                }],
                "recover",
            )
        })
    }
}

// Test binaries only: terminate exactly around the atomic rename. Never present
// in production builds and intentionally skip destructors to model process loss.
#[cfg(test)]
pub(super) fn test_crash_checkpoint(path: &Path, phase: &str) {
    if std::env::var("MYVCS_STATE_CRASH_FILE").ok().as_deref()
        == path.file_name().and_then(|n| n.to_str())
        && std::env::var("MYVCS_STATE_CRASH_PHASE").ok().as_deref() == Some(phase)
    {
        std::process::exit(74);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn commit(repo: &Repo, message: &str) -> String {
        repo.write_object(
            &serde_json::to_vec(&Commit {
                tree: Default::default(),
                parents: vec![],
                parent: None,
                message: message.into(),
                author: "test".into(),
                timestamp: 0,
            })
            .unwrap(),
        )
        .unwrap()
    }
    fn lab() -> PathBuf {
        std::env::temp_dir().join(format!("state-crash-{}", unique_suffix()))
    }
    #[test]
    fn atomic_state_crash_worker() {
        let Ok(dir) = std::env::var("MYVCS_STATE_CRASH_REPO") else {
            return;
        };
        let repo = Repo::open(dir).unwrap();
        if std::env::var("MYVCS_STATE_CRASH_MODE").unwrap() == "upgrade" {
            repo.upgrade().unwrap();
        } else {
            let a = repo.read_ref("refs/heads/main").unwrap().unwrap();
            let b = commit(&repo, "new");
            repo.transact_refs(
                &[
                    RefChange {
                        name: "refs/heads/main".into(),
                        expected: Some(a),
                        new: Some(b.clone()),
                    },
                    RefChange {
                        name: "refs/heads/second".into(),
                        expected: None,
                        new: Some(b),
                    },
                ],
                "crash batch",
            )
            .unwrap();
        }
        panic!("crash checkpoint not reached");
    }
    fn crash(dir: &Path, file: &str, phase: &str, mode: &str) {
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "repo::ref_state::tests::atomic_state_crash_worker",
            ])
            .env("MYVCS_STATE_CRASH_REPO", dir)
            .env("MYVCS_STATE_CRASH_FILE", file)
            .env("MYVCS_STATE_CRASH_PHASE", phase)
            .env("MYVCS_STATE_CRASH_MODE", mode)
            .stdout(std::process::Stdio::null())
            .status()
            .unwrap();
        assert_eq!(status.code(), Some(74));
    }
    #[test]
    fn process_exit_at_state_rename_is_all_old_or_all_new_with_reflog() {
        for phase in ["before", "after"] {
            let dir = lab();
            let r = Repo::init_at(&dir, true, true).unwrap();
            let a = commit(&r, "old");
            r.update_ref("refs/heads/main", None, &a).unwrap();
            r.upgrade().unwrap();
            crash(&dir, "refs-state.json", phase, "transaction");
            let r = Repo::open(&dir).unwrap();
            let s = r.refs_snapshot().unwrap();
            if phase == "before" {
                assert_eq!(s.refs.len(), 1);
                assert_eq!(s.refs["refs/heads/main"], a);
                assert_eq!(s.generation, 0);
                assert!(s.reflog.is_empty());
            } else {
                assert_eq!(s.refs.len(), 2);
                assert_eq!(s.refs["refs/heads/main"], s.refs["refs/heads/second"]);
                assert_eq!(s.generation, 1);
                assert_eq!(s.reflog.len(), 3);
            }
            r.verify().unwrap();
            r.with_repo_lock(|r| r.gc()).unwrap();
            r.verify().unwrap();
            fs::remove_dir_all(dir).unwrap();
        }
    }
    #[test]
    fn upgrade_crash_boundaries_and_retry_use_legacy_until_marker() {
        for file in ["refs-state.json", "format.json"] {
            for phase in ["before", "after"] {
                let dir = lab();
                let r = Repo::init_at(&dir, true, true).unwrap();
                let a = commit(&r, "old");
                r.update_ref("refs/heads/main", None, &a).unwrap();
                crash(&dir, file, phase, "upgrade");
                let r = Repo::open(&dir).unwrap();
                let finished = file == "format.json" && phase == "after";
                assert_eq!(r.format_version().unwrap(), if finished { 2 } else { 1 });
                if !finished {
                    let b = commit(&r, "legacy changed after failed upgrade");
                    r.update_ref("refs/heads/main", Some(&a), &b).unwrap();
                    r.upgrade().unwrap();
                    assert_eq!(r.head_commit_id().unwrap(), Some(b));
                }
                assert!(r.refs_snapshot().unwrap().reflog.is_empty());
                r.verify().unwrap();
                fs::remove_dir_all(dir).unwrap();
            }
        }
    }
}
