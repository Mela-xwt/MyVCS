//! Per-thread allocation measurements for algorithm memory regression tests.
//! Input buffers are allocated before measurement; no production allocator changes.
use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::Cell;

#[derive(Clone, Copy, Default)]
struct Usage {
    live: usize,
    peak: usize,
}

thread_local! {
    static USAGE: Cell<Option<Usage>> = const { Cell::new(None) };
}

fn record(added: usize, removed: usize) {
    let _ = USAGE.try_with(|cell| {
        if let Some(mut usage) = cell.get() {
            usage.live = usage.live.saturating_sub(removed).saturating_add(added);
            usage.peak = usage.peak.max(usage.live);
            cell.set(Some(usage));
        }
    });
}

struct MeasuredAllocator;

#[global_allocator]
static ALLOCATOR: MeasuredAllocator = MeasuredAllocator;

unsafe impl GlobalAlloc for MeasuredAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() {
            record(layout.size(), 0);
        }
        ptr
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() {
            record(layout.size(), 0);
        }
        ptr
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        record(0, layout.size());
        unsafe { System.dealloc(ptr, layout) };
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let next = unsafe { System.realloc(ptr, layout, size) };
        if !next.is_null() {
            record(size, layout.size());
        }
        next
    }
}

pub fn peak_bytes<T>(operation: impl FnOnce() -> T) -> (T, usize) {
    struct Reset;
    impl Drop for Reset {
        fn drop(&mut self) {
            USAGE.with(|cell| cell.set(None));
        }
    }
    USAGE.with(|cell| {
        assert!(cell.get().is_none(), "nested allocation measurement");
        cell.set(Some(Usage::default()));
    });
    let _reset = Reset;
    let result = operation();
    let peak = USAGE.with(|cell| cell.get().unwrap().peak);
    (result, peak)
}
