use std::collections::HashMap;
use std::env;
use std::fs::{self, File};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::Path;
use std::sync::OnceLock;
use std::time::{SystemTime, UNIX_EPOCH};

use anyhow::{Context, Result, bail};
use flate2::Compression;
use flate2::write::ZlibEncoder;
use memmap2::{Advice, MmapOptions};
use sha2::{Digest, Sha256};

use crate::model::{DELTA_MAGIC, DeltaBlob, DeltaOp};

pub const LARGE_FILE_THRESHOLD: u64 = 10 * 1024 * 1024;
static OPENEULER_IO_HINTS: OnceLock<bool> = OnceLock::new();
static ETMEM_TIERING: OnceLock<bool> = OnceLock::new();
static IO_CHUNK_SIZE_BYTES: OnceLock<usize> = OnceLock::new();

// 当 MYVCS_DEBUG 为真值时启用详细调试日志。
pub fn is_debug_enabled() -> bool {
    match env::var("MYVCS_DEBUG") {
        Ok(v) => matches!(v.as_str(), "1" | "true" | "TRUE" | "yes" | "on"),
        Err(_) => false,
    }
}

#[macro_export]
macro_rules! debug_log {
    ($($arg:tt)*) => {{
        if $crate::util::is_debug_enabled() {
            eprintln!("[myvcs:debug] {}", format_args!($($arg)*));
        }
    }};
}

pub fn now_unix() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

// 用于命令行输出的短提交 ID。
pub fn short_id(id: &str) -> String {
    id.chars().take(8).collect()
}

// 计算对象 ID 使用的标准 SHA-256 十六进制编码。
pub fn hex_sha256(bytes: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    digest_to_hex(&hasher.finalize())
}

// 计算文件内容的 SHA-256；大文件优先 mmap，失败时回退流式读取。
pub fn hex_sha256_file(path: &Path) -> Result<String> {
    let meta = fs::metadata(path)?;
    if meta.len() < LARGE_FILE_THRESHOLD {
        return Ok(hex_sha256(&fs::read(path)?));
    }

    let mut f = File::open(path)?;
    advise_file_sequential(&f);
    if should_use_mmap_for_large_files() {
        let mapped = unsafe { MmapOptions::new().map(&f) };
        if let Ok(m) = mapped {
            advise_mmap_sequential(&m);
            let out = hex_sha256(m.as_ref());
            advise_file_dontneed(&f);
            return Ok(out);
        }
    }

    let mut hasher = Sha256::new();
    let mut buf = vec![0u8; io_chunk_size_bytes()];
    loop {
        let n = f.read(&mut buf[..])?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }

    let out = digest_to_hex(&hasher.finalize());
    advise_file_dontneed(&f);
    Ok(out)
}

// 调用方明确指定最终落盘使用的 zlib 压缩级别。
pub fn compress_bytes(bytes: &[u8], level: Compression) -> Result<Vec<u8>> {
    let mut encoder = ZlibEncoder::new(Vec::new(), level);
    encoder.write_all(bytes)?;
    Ok(encoder.finish()?)
}

// Large add keeps zlib framing and content IDs unchanged. Sampling only decides
// the compression level; it is not a bound on the final object's size ratio.
pub fn large_file_compression(file: &mut File, len: u64) -> Result<Compression> {
    let policy = match env::var("MYVCS_LARGE_FILE_COMPRESSION") {
        Ok(value) => value,
        Err(env::VarError::NotPresent) => "auto".to_owned(),
        Err(error) => return Err(error).context("invalid MYVCS_LARGE_FILE_COMPRESSION"),
    };
    let level = select_large_file_compression(file, len, &policy)?;
    crate::debug_log!(
        "large file compression: policy={}, level={}",
        policy,
        level.level()
    );
    Ok(level)
}

fn select_large_file_compression<R: Read + Seek>(
    reader: &mut R,
    len: u64,
    policy: &str,
) -> Result<Compression> {
    match policy {
        "fast" => return Ok(Compression::fast()),
        "default" => return Ok(Compression::default()),
        "auto" => {}
        _ => bail!("MYVCS_LARGE_FILE_COMPRESSION must be auto, fast or default"),
    }
    // Probe at most 96 KiB, spread across the file. Require every sample to
    // stay within 5% of default compression; repetitive inputs fall back early.
    let sample_len = len.min(32 * 1024) as usize;
    let last = len - sample_len as u64;
    let mut sample = vec![0u8; sample_len];
    let mut level = Compression::fast();
    for offset in [0, last / 2, last] {
        reader.seek(SeekFrom::Start(offset))?;
        reader.read_exact(&mut sample)?;
        let fast_len = compress_bytes(&sample, Compression::fast())?.len();
        let default_len = compress_bytes(&sample, Compression::default())?.len();
        if fast_len * 100 > default_len * 105 {
            level = Compression::default();
            break;
        }
    }
    // Streaming hashing and compression must include the complete file.
    reader.seek(SeekFrom::Start(0))?;
    Ok(level)
}

// 增量对象编码格式：魔数头 + JSON 负载。
pub fn encode_delta_blob(delta: &DeltaBlob) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    out.extend_from_slice(DELTA_MAGIC);
    out.extend_from_slice(&serde_json::to_vec(delta)?);
    Ok(out)
}

pub fn decode_delta_blob(raw: &[u8]) -> Result<Option<DeltaBlob>> {
    if !raw.starts_with(DELTA_MAGIC) {
        return Ok(None);
    }
    let body = &raw[DELTA_MAGIC.len()..];
    let delta: DeltaBlob = serde_json::from_slice(body).context("invalid delta blob")?;
    Ok(Some(delta))
}

const DELTA_CHUNK: usize = 32;

// 候选哈希相同不保证字节相同；确认首块后再扩展匹配。
fn find_delta_match(
    base: &[u8],
    target: &[u8],
    candidates: impl Iterator<Item = usize>,
) -> Option<(usize, usize)> {
    let mut best = None;
    let mut best_len = 0;
    for off in candidates {
        if base[off..off + DELTA_CHUNK] != target[..DELTA_CHUNK] {
            continue;
        }
        let mut len = DELTA_CHUNK;
        while off + len < base.len() && len < target.len() && base[off + len] == target[len] {
            len += 1;
        }
        if len > best_len {
            best_len = len;
            best = Some((off, len));
        }
    }
    best
}

// 从 base 到 target 构建基于固定块的增量指令。
pub fn build_delta(base: &[u8], target: &[u8]) -> Vec<DeltaOp> {
    const CHUNK: usize = DELTA_CHUNK;
    const MAX_CANDIDATES: usize = 8;
    if base.is_empty() || target.is_empty() {
        return vec![DeltaOp::Insert {
            data: target.to_vec(),
        }];
    }

    // 常见的唯一哈希只保存一个位置，不为每个块分配 Vec。
    // 重复哈希的后续位置按原顺序单独保存，仍最多考察 8 个候选。
    let mut index: HashMap<u64, usize> = HashMap::new();
    let mut extra_candidates: HashMap<u64, Vec<usize>> = HashMap::new();
    // 高度重复的数据常连续命中同一哈希。已收齐 8 个候选后无需再查两张表。
    let mut saturated_key = None;
    if base.len() >= CHUNK {
        let mut i = 0usize;
        while i + CHUNK <= base.len() {
            let key = chunk_hash(&base[i..i + CHUNK]);
            if saturated_key == Some(key) {
                i += CHUNK;
                continue;
            }
            match index.entry(key) {
                std::collections::hash_map::Entry::Vacant(entry) => {
                    entry.insert(i);
                }
                std::collections::hash_map::Entry::Occupied(_) => {
                    let extra = extra_candidates.entry(key).or_default();
                    if extra.len() < MAX_CANDIDATES - 1 {
                        extra.push(i);
                    }
                    if extra.len() == MAX_CANDIDATES - 1 {
                        saturated_key = Some(key);
                    }
                }
            }
            i += CHUNK;
        }
    }

    let mut ops = Vec::new();
    let mut insert_buf = Vec::new();
    let mut i = 0usize;
    while i < target.len() {
        if i + CHUNK <= target.len() && !index.is_empty() {
            let key = chunk_hash(&target[i..i + CHUNK]);
            if let Some(&first) = index.get(&key)
                && let Some((best_off, best_len)) = find_delta_match(
                    base,
                    &target[i..],
                    std::iter::once(first)
                        .chain(extra_candidates.get(&key).into_iter().flatten().copied()),
                )
            {
                if !insert_buf.is_empty() {
                    ops.push(DeltaOp::Insert {
                        data: std::mem::take(&mut insert_buf),
                    });
                }
                ops.push(DeltaOp::Copy {
                    offset: best_off,
                    len: best_len,
                });
                i += best_len;
                continue;
            }
        }

        insert_buf.push(target[i]);
        i += 1;
    }

    if !insert_buf.is_empty() {
        ops.push(DeltaOp::Insert { data: insert_buf });
    }
    ops
}

// 根据基础对象与增量指令重建目标字节流。
pub fn apply_delta(base: &[u8], ops: &[DeltaOp]) -> Result<Vec<u8>> {
    apply_delta_limited(base, ops, 256 * 1024 * 1024)
}

pub fn apply_delta_limited(base: &[u8], ops: &[DeltaOp], limit: usize) -> Result<Vec<u8>> {
    let mut size = 0usize;
    for op in ops {
        let n = match op {
            DeltaOp::Copy { offset, len } => {
                let end = offset.checked_add(*len).context("delta copy overflow")?;
                if end > base.len() {
                    bail!("invalid delta copy range");
                }
                *len
            }
            DeltaOp::Insert { data } => data.len(),
        };
        size = size.checked_add(n).context("delta output overflow")?;
        if size > limit {
            bail!("delta output limit exceeded");
        }
    }
    let mut out = Vec::new();
    out.try_reserve_exact(size)
        .context("delta allocation failed")?;
    for op in ops {
        match op {
            DeltaOp::Copy { offset, len } => out.extend_from_slice(&base[*offset..offset + len]),
            DeltaOp::Insert { data } => out.extend_from_slice(data),
        }
    }
    Ok(out)
}

fn chunk_hash(chunk: &[u8]) -> u64 {
    let mut h: u64 = 0xcbf29ce484222325;
    for &b in chunk {
        h ^= u64::from(b);
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

// 读取文件字节；大文件优先内存映射，降低峰值内存波动。
pub fn read_file_for_blob(path: &Path) -> Result<Vec<u8>> {
    let meta = fs::metadata(path)?;
    if meta.len() < LARGE_FILE_THRESHOLD {
        return Ok(fs::read(path)?);
    }

    let mut f = File::open(path)?;
    advise_file_sequential(&f);
    if should_use_mmap_for_large_files() {
        let mapped = unsafe { MmapOptions::new().map(&f) };
        if let Ok(m) = mapped {
            advise_mmap_sequential(&m);
            let out = m.as_ref().to_vec();
            advise_file_dontneed(&f);
            return Ok(out);
        }
    }

    let file_len = capacity_from_u64(meta.len());
    let mut out = Vec::with_capacity(file_len);
    let mut buf = vec![0u8; io_chunk_size_bytes()];
    loop {
        let n = f.read(&mut buf[..])?;
        if n == 0 {
            break;
        }
        out.extend_from_slice(&buf[..n]);
    }

    advise_file_dontneed(&f);
    Ok(out)
}

pub fn digest_to_hex(digest: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(digest.len() * 2);
    for &b in digest {
        out.push(HEX[(b >> 4) as usize] as char);
        out.push(HEX[(b & 0x0f) as usize] as char);
    }
    out
}

fn advise_mmap_sequential(m: &memmap2::Mmap) {
    #[cfg(target_os = "linux")]
    {
        let _ = m.advise(Advice::Sequential);
        if should_enable_openeuler_io_hints() {
            let _ = m.advise(Advice::WillNeed);
        }
    }
}

pub fn advise_file_sequential(file: &File) {
    #[cfg(target_os = "linux")]
    {
        use std::os::fd::AsRawFd;

        if should_enable_openeuler_io_hints() {
            let _ =
                unsafe { libc::posix_fadvise(file.as_raw_fd(), 0, 0, libc::POSIX_FADV_SEQUENTIAL) };
        }
    }
}

pub fn advise_file_dontneed(file: &File) {
    #[cfg(target_os = "linux")]
    {
        use std::os::fd::AsRawFd;

        if should_enable_openeuler_io_hints() {
            let _ =
                unsafe { libc::posix_fadvise(file.as_raw_fd(), 0, 0, libc::POSIX_FADV_DONTNEED) };
        }
    }
}

pub fn maybe_set_background_nice() {
    #[cfg(target_os = "linux")]
    {
        if !should_enable_openeuler_io_hints() || env_truthy("MYVCS_DISABLE_BG_NICE") {
            return;
        }

        let nice = env::var("MYVCS_BG_NICE")
            .ok()
            .and_then(|v| v.parse::<i32>().ok())
            .unwrap_or(10)
            .clamp(0, 19);

        let _ = unsafe { libc::setpriority(libc::PRIO_PROCESS, 0, nice as libc::c_int) };
    }
}

pub fn should_run_deep_delta_gc() -> bool {
    if env_truthy("MYVCS_FORCE_DEEP_DELTA") {
        return true;
    }
    if env_truthy("MYVCS_DISABLE_DEEP_DELTA") {
        return false;
    }
    if !should_enable_openeuler_io_hints() {
        return true;
    }

    let Some(load1) = current_loadavg_1() else {
        return true;
    };

    let cpus = std::thread::available_parallelism()
        .map(|n| n.get() as f64)
        .unwrap_or(1.0)
        .max(1.0);

    let threshold = env::var("MYVCS_DEEP_DELTA_LOAD_RATIO")
        .ok()
        .and_then(|v| v.parse::<f64>().ok())
        .filter(|v| *v > 0.0)
        .unwrap_or(0.8);

    (load1 / cpus) < threshold
}

pub(crate) fn should_enable_openeuler_io_hints() -> bool {
    *OPENEULER_IO_HINTS.get_or_init(|| {
        let raw = fs::read_to_string("/etc/os-release").unwrap_or_default();
        parse_os_release_id(&raw)
            .map(|id| id == "openeuler")
            .unwrap_or(false)
    })
}

pub(crate) fn should_enable_etmem_tiering() -> bool {
    *ETMEM_TIERING.get_or_init(|| {
        if env_truthy("MYVCS_DISABLE_ETMEM") {
            return false;
        }
        if env_truthy("MYVCS_ENABLE_ETMEM") {
            return true;
        }
        if !should_enable_openeuler_io_hints() {
            return false;
        }
        detect_etmem_support()
    })
}

fn detect_etmem_support() -> bool {
    Path::new("/sys/kernel/mm/etmem").exists()
        || Path::new("/sys/kernel/mm/memory_tiering").exists()
        || Path::new("/etc/etmemd/etmemd.conf").exists()
}

fn should_use_mmap_for_large_files() -> bool {
    if env_truthy("MYVCS_DISABLE_MMAP") {
        return false;
    }

    // 在 openEuler 低内存边缘环境下默认关闭 mmap，优先稳定性。
    if should_enable_openeuler_io_hints()
        && let Some(total_kb) = detect_total_mem_kb()
    {
        return total_kb > 1024 * 1024;
    }

    true
}

fn detect_total_mem_kb() -> Option<u64> {
    let raw = fs::read_to_string("/proc/meminfo").ok()?;
    parse_memtotal_kb(&raw)
}

fn parse_memtotal_kb(raw: &str) -> Option<u64> {
    for line in raw.lines() {
        let Some(rest) = line.strip_prefix("MemTotal:") else {
            continue;
        };
        let val = rest.split_whitespace().next()?.parse::<u64>().ok()?;
        return Some(val);
    }
    None
}

fn current_loadavg_1() -> Option<f64> {
    let raw = fs::read_to_string("/proc/loadavg").ok()?;
    parse_loadavg_1(&raw)
}

fn parse_loadavg_1(raw: &str) -> Option<f64> {
    raw.split_whitespace().next()?.parse::<f64>().ok()
}

fn env_truthy(key: &str) -> bool {
    match env::var(key) {
        Ok(v) => matches!(v.as_str(), "1" | "true" | "TRUE" | "yes" | "on"),
        Err(_) => false,
    }
}

fn env_kb(key: &str) -> Option<u64> {
    env::var(key).ok()?.parse::<u64>().ok()
}

fn capacity_from_u64(len: u64) -> usize {
    if len > usize::MAX as u64 {
        0
    } else {
        len as usize
    }
}

fn parse_os_release_id(raw: &str) -> Option<String> {
    for line in raw.lines() {
        let Some(v) = line.strip_prefix("ID=") else {
            continue;
        };
        let id = v
            .trim()
            .trim_matches('"')
            .trim_matches('\'')
            .to_ascii_lowercase();
        if !id.is_empty() {
            return Some(id);
        }
    }
    None
}

// ---------------------------------------------------------------------------
// openEuler 深度优化 — 文件系统感知层
// ---------------------------------------------------------------------------

/// 文件系统类型枚举，用于自适应 I/O 策略。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsType {
    Ext4,
    Xfs,
    Btrfs,
    EulerFs,
    Other,
}

impl FsType {
    /// 返回该文件系统的最优写缓冲区大小（字节）。
    /// 对齐到文件系统 extent/stripe 边界可减少 RMW（Read-Modify-Write）。
    pub fn optimal_write_buffer(&self) -> usize {
        match self {
            // ext4 默认 extent 大小 128KB，4KB 块 × 32 = 128KB 对齐
            FsType::Ext4 => 128 * 1024,
            // XFS 默认 stripe 宽度通常为 64KB-256KB，取 256KB
            FsType::Xfs => 256 * 1024,
            // Btrfs 节点大小 16KB，取 64KB 对齐
            FsType::Btrfs => 64 * 1024,
            // EulerFS 大块分配器优化 64KB-256KB，取 256KB
            FsType::EulerFs => 256 * 1024,
            FsType::Other => 64 * 1024,
        }
    }

    /// 是否属于 openEuler 生态文件系统。
    #[allow(dead_code)]
    pub fn is_openeuler_native(&self) -> bool {
        matches!(self, FsType::EulerFs | FsType::Ext4)
    }
}

/// 检测指定路径所在文件系统类型。
/// 读取 `/proc/mounts` 按最长挂载点前缀匹配。
pub fn detect_fs_type(path: &Path) -> FsType {
    static CACHED_FS_TYPE: OnceLock<FsType> = OnceLock::new();
    *CACHED_FS_TYPE.get_or_init(|| {
        let canonical = path.canonicalize().unwrap_or_else(|_| path.to_path_buf());
        let target = canonical.to_string_lossy();

        let mounts = fs::read_to_string("/proc/mounts").unwrap_or_default();
        let mut best_match: Option<(String, usize)> = None;

        for line in mounts.lines() {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() < 3 {
                continue;
            }
            let mount_point = parts[1];
            if target.starts_with(mount_point)
                && mount_point.len() > best_match.as_ref().map_or(0, |(_, l)| *l)
            {
                best_match = Some((parts[2].to_string(), mount_point.len()));
            }
        }

        match best_match.as_ref().map(|(fs, _)| fs.as_str()) {
            Some("ext4") => FsType::Ext4,
            Some("xfs") => FsType::Xfs,
            Some("btrfs") => FsType::Btrfs,
            Some("eulerfs") => FsType::EulerFs,
            _ => FsType::Other,
        }
    })
}

const EULERFS_PREALLOC_MIN_BYTES: u64 = 256 * 1024;

pub fn eulerfs_prealloc_len(path: &Path, data_len: u64) -> Option<u64> {
    if data_len < EULERFS_PREALLOC_MIN_BYTES {
        return None;
    }
    if env_truthy("MYVCS_DISABLE_EULERFS_PREALLOC") {
        return None;
    }
    if !should_enable_openeuler_io_hints() {
        return None;
    }
    if detect_fs_type(path) != FsType::EulerFs {
        return None;
    }
    let align = FsType::EulerFs.optimal_write_buffer() as u64;
    let aligned = ((data_len + align - 1) / align) * align;
    Some(aligned.max(align))
}

#[cfg(target_os = "linux")]
pub fn preallocate_file(file: &File, len: u64) {
    if len == 0 {
        return;
    }
    use std::os::fd::AsRawFd;
    let rc = unsafe { libc::posix_fallocate(file.as_raw_fd(), 0, len as libc::off_t) };
    if rc != 0 {
        crate::debug_log!("posix_fallocate failed rc={} len={}", rc, len);
    }
}

#[cfg(not(target_os = "linux"))]
pub fn preallocate_file(_file: &File, _len: u64) {}

#[derive(Debug, Clone)]
pub struct NumaTopology {
    pub node_count: usize,
    #[allow(dead_code)]
    pub cpu_to_node: Vec<usize>,
}

pub fn detect_numa_topology() -> NumaTopology {
    static CACHED_NUMA: OnceLock<NumaTopology> = OnceLock::new();
    CACHED_NUMA
        .get_or_init(|| {
            let node_dir = Path::new("/sys/devices/system/node");
            let mut node_count = 0usize;
            if let Ok(entries) = fs::read_dir(node_dir) {
                for e in entries.flatten() {
                    let name = e.file_name().to_string_lossy().to_string();
                    if name.starts_with("node") && name[4..].parse::<u64>().is_ok() {
                        node_count += 1;
                    }
                }
            }
            if node_count == 0 {
                node_count = 1;
            }

            let mut cpu_to_node = Vec::new();
            let cpu_dir = Path::new("/sys/devices/system/cpu");
            if let Ok(entries) = fs::read_dir(cpu_dir) {
                for e in entries.flatten() {
                    let name = e.file_name().to_string_lossy().to_string();
                    if let Some(suffix) = name.strip_prefix("cpu") {
                        if suffix.parse::<u64>().is_ok() {
                            let node_path = e.path().join("topology").join("physical_package_id");
                            if let Ok(raw) = fs::read_to_string(&node_path) {
                                if let Ok(n) = raw.trim().parse::<usize>() {
                                    if cpu_to_node.len() <= n {
                                        cpu_to_node.resize(n + 1, 0);
                                    }
                                    cpu_to_node[n] = n;
                                }
                            }
                        }
                    }
                }
            }
            if cpu_to_node.is_empty() {
                cpu_to_node.push(0);
            }

            NumaTopology {
                node_count,
                cpu_to_node,
            }
        })
        .clone()
}

/// 获取最优 I/O 块大小：综合考虑 FS 类型、内存容量、NUMA 拓扑。
/// openEuler 场景下自动使用 FS 对齐值。
pub fn io_chunk_size_bytes() -> usize {
    *IO_CHUNK_SIZE_BYTES.get_or_init(|| {
        if let Some(kb) = env_kb("MYVCS_IO_CHUNK_KB") {
            return (kb.clamp(64, 4096) * 1024) as usize;
        }

        // openEuler 优化：优先使用 FS 对齐值
        if should_enable_openeuler_io_hints() {
            // 以 objects 目录所在 FS 为准
            let fs_type = detect_fs_type(Path::new("."));
            let fs_opt = fs_type.optimal_write_buffer();

            // 若内存紧张，折半以降低单次 I/O 压力
            if let Some(total_kb) = detect_total_mem_kb() {
                if total_kb <= 1024 * 1024 {
                    return (fs_opt / 2).max(64 * 1024);
                }
                if total_kb <= 2 * 1024 * 1024 {
                    return (fs_opt * 2 / 3).max(128 * 1024);
                }
            }
            return fs_opt;
        }

        1024 * 1024
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BlobTemperature {
    Hot,
    Warm,
    Cold,
}

pub fn categorize_blob_temperature(commit_timestamp: i64) -> BlobTemperature {
    let now = now_unix() as i64;
    let age_secs = (now - commit_timestamp).max(0) as u64;

    if age_secs < 3600 {
        BlobTemperature::Hot
    } else if age_secs < 604800 {
        BlobTemperature::Warm
    } else {
        BlobTemperature::Cold
    }
}

#[cfg(target_os = "linux")]
const DEFAULT_MADVISE_LIMIT_BYTES: u64 = 32 * 1024 * 1024;

#[cfg(target_os = "linux")]
const ETMEM_MADVISE_LIMIT_BYTES: u64 = 256 * 1024 * 1024;

#[cfg(target_os = "linux")]
fn etmem_madvise_limit_bytes() -> u64 {
    if let Ok(raw) = env::var("MYVCS_ETMEM_MADVISE_LIMIT_MB") {
        if let Ok(mb) = raw.parse::<u64>() {
            return mb.max(1) * 1024 * 1024;
        }
    }
    if should_enable_etmem_tiering() {
        return ETMEM_MADVISE_LIMIT_BYTES;
    }
    DEFAULT_MADVISE_LIMIT_BYTES
}

#[cfg(target_os = "linux")]
fn try_madvise_file(file: &File, advice: libc::c_int) {
    let len = match file.metadata() {
        Ok(m) => m.len(),
        Err(_) => return,
    };
    let limit = etmem_madvise_limit_bytes();
    if len == 0 || len > limit {
        return;
    }

    let mapped = unsafe { MmapOptions::new().map(file) };
    if let Ok(m) = mapped {
        let _ = unsafe { libc::madvise(m.as_ptr() as *mut libc::c_void, m.len(), advice) };
    }
}

pub fn advise_hot_blob(file: &File) {
    #[cfg(target_os = "linux")]
    {
        if !should_enable_openeuler_io_hints() {
            return;
        }
        use std::os::fd::AsRawFd;
        let _ = unsafe { libc::posix_fadvise(file.as_raw_fd(), 0, 0, libc::POSIX_FADV_WILLNEED) };
        try_madvise_file(file, libc::MADV_WILLNEED);
    }
}

pub fn advise_cold_blob(file: &File) {
    #[cfg(target_os = "linux")]
    {
        if !should_enable_openeuler_io_hints() {
            return;
        }
        use std::os::fd::AsRawFd;
        let _ = unsafe { libc::posix_fadvise(file.as_raw_fd(), 0, 0, libc::POSIX_FADV_DONTNEED) };
        let _ = unsafe { libc::posix_fadvise(file.as_raw_fd(), 0, 0, libc::POSIX_FADV_NOREUSE) };
        try_madvise_file(file, libc::MADV_COLD);
    }
}

impl std::fmt::Display for FsType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            FsType::Ext4 => write!(f, "ext4"),
            FsType::Xfs => write!(f, "xfs"),
            FsType::Btrfs => write!(f, "btrfs"),
            FsType::EulerFs => write!(f, "eulerfs"),
            FsType::Other => write!(f, "other"),
        }
    }
}

pub fn adaptive_compression(temp: BlobTemperature) -> Compression {
    match temp {
        BlobTemperature::Hot => Compression::fast(),
        BlobTemperature::Warm => Compression::default(),
        BlobTemperature::Cold => Compression::best(),
    }
}

// ---------------------------------------------------------------------------
// 单元测试
// ---------------------------------------------------------------------------
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn large_compression_auto_checks_distributed_samples_and_rewinds() {
        use std::io::Cursor;
        let random = delta_fixture(256 * 1024);
        let mut reader = Cursor::new(random.clone());
        assert_eq!(
            select_large_file_compression(&mut reader, random.len() as u64, "auto").unwrap(),
            Compression::fast()
        );
        assert_eq!(reader.position(), 0);
        // The head remains random; each later probe must detect repetition.
        for offset in [(random.len() - 32768) / 2, random.len() - 32768] {
            let mut mixed = random.clone();
            mixed[offset..offset + 32768].fill(b'A');
            let mut reader = Cursor::new(mixed);
            assert_eq!(
                select_large_file_compression(&mut reader, random.len() as u64, "auto").unwrap(),
                Compression::default()
            );
            assert_eq!(reader.position(), 0);
        }
    }

    #[test]
    fn large_compression_short_read_is_an_error() {
        let mut reader = std::io::Cursor::new(vec![0; 100]);
        assert!(select_large_file_compression(&mut reader, 10 * 1024 * 1024, "auto").is_err());
    }

    fn delta_fixture(size: usize) -> Vec<u8> {
        let mut state = 0x8e792a3d9b4c6105u64;
        (0..size)
            .map(|_| {
                state ^= state << 13;
                state ^= state >> 7;
                state ^= state << 17;
                state as u8
            })
            .collect()
    }

    #[test]
    fn delta_unique_blocks_use_bounded_index_memory() {
        let base = delta_fixture(4 * 1024 * 1024);
        let (ops, peak) = crate::test_alloc::peak_bytes(|| build_delta(&base, &base));
        eprintln!("unique-block delta allocation peak: {peak} bytes");
        assert_eq!(apply_delta(&base, &ops).unwrap(), base);
        // Budget includes index growth and result operations, but not input
        // storage or allocator bookkeeping. RSS is measured separately.
        assert!(
            peak <= 2 * base.len(),
            "index allocation peak {peak} exceeds {} bytes",
            2 * base.len()
        );
    }

    #[test]
    fn delta_repeated_blocks_do_not_allocate_per_block() {
        let base = vec![b'A'; 4 * 1024 * 1024];
        let (ops, peak) = crate::test_alloc::peak_bytes(|| build_delta(&base, &base));
        eprintln!("repeated-block delta allocation peak: {peak} bytes");
        assert_eq!(apply_delta(&base, &ops).unwrap(), base);
        assert!(
            peak <= 64 * 1024,
            "repeated-data index allocated {peak} bytes"
        );
    }

    #[test]
    fn delta_retains_eighth_matching_candidate() {
        let mut base = Vec::new();
        for n in 0..8 {
            base.extend_from_slice(&[b'A'; 32]);
            base.extend_from_slice(&[b'0' + n; 32]);
        }
        let target = [&[b'A'; 32][..], &[b'7'; 32][..]].concat();
        let ops = build_delta(&base, &target);
        assert!(matches!(
            &ops[..],
            [DeltaOp::Copy {
                offset: 448,
                len: 64
            }]
        ));
        assert_eq!(apply_delta(&base, &ops).unwrap(), target);
    }

    #[test]
    fn delta_rejects_hash_candidates_with_different_first_blocks() {
        let base = [
            vec![b'A'; 32],
            vec![b'C'; 64],
            vec![b'B'; 32],
            vec![b'C'; 64],
        ]
        .concat();
        let target = [vec![b'B'; 32], vec![b'C'; 64]].concat();
        // Simulate a hash collision: both candidates have identical tails,
        // but only the second candidate has the requested initial block.
        assert_eq!(
            find_delta_match(&base, &target, [0, 96].into_iter()),
            Some((96, 96))
        );
        assert_eq!(find_delta_match(&base, &target, [0].into_iter()), None);
    }

    #[test]
    fn delta_reconstructs_insertions_deletions_overwrites_and_empty_files() {
        for size in [0, 1, 31, 32, 33, 63, 64, 65, 1024, 4096] {
            let base = delta_fixture(size);
            for offset in [0, size / 2, size] {
                let mut inserted = base.clone();
                inserted.splice(offset..offset, [0, 255, 19, 73, 8]);
                let mut deleted = base.clone();
                deleted.drain(offset..(offset + 37).min(size));
                let mut overwritten = base.clone();
                overwritten[offset..(offset + 41).min(size)].fill(42);
                for target in [inserted, deleted, overwritten, Vec::new(), base.clone()] {
                    let ops = build_delta(&base, &target);
                    assert_eq!(
                        apply_delta(&base, &ops).unwrap(),
                        target,
                        "size={size} offset={offset}"
                    );
                }
            }
        }
        let base = delta_fixture(8192);
        let mut target = b"unaligned insertion".to_vec();
        target.extend_from_slice(&base);
        let ops = build_delta(&base, &target);
        assert!(
            ops.iter()
                .any(|op| matches!(op, DeltaOp::Copy { len: 8192, .. }))
        );
        assert_eq!(apply_delta(&base, &ops).unwrap(), target);
    }

    #[test]
    fn apply_delta_reconstructs_target() {
        let base = b"hello-AAAA-world";
        let target = b"hello-BBBB-world!!!";
        let ops = build_delta(base, target);
        let rebuilt = apply_delta(base, &ops).expect("apply delta should succeed");
        assert_eq!(rebuilt, target);
    }

    #[test]
    fn delta_encode_decode_roundtrip() {
        let delta = DeltaBlob {
            base: "abcd".to_string(),
            ops: vec![DeltaOp::Insert {
                data: b"payload".to_vec(),
            }],
            size: 7,
        };
        let encoded = encode_delta_blob(&delta).expect("encode should succeed");
        let decoded = decode_delta_blob(&encoded)
            .expect("decode should succeed")
            .expect("must be delta");
        assert_eq!(decoded.base, delta.base);
        assert_eq!(decoded.size, delta.size);
        assert_eq!(decoded.ops.len(), delta.ops.len());
    }

    #[test]
    fn hash_output_is_64_hex_chars() {
        let out = hex_sha256(b"abc");
        assert_eq!(out.len(), 64);
        assert!(out.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn parse_os_release_id_handles_quotes_and_case() {
        let raw = "NAME=openEuler\nID=\"openEuler\"\nVERSION=22.03\n";
        assert_eq!(parse_os_release_id(raw).as_deref(), Some("openeuler"));
    }

    #[test]
    fn parse_memtotal_kb_works() {
        let raw = "MemTotal:       2048000 kB\nMemFree:         512000 kB\n";
        assert_eq!(parse_memtotal_kb(raw), Some(2_048_000));
    }

    #[test]
    fn parse_loadavg_1_works() {
        let raw = "0.75 0.42 0.30 1/500 12345\n";
        assert_eq!(parse_loadavg_1(raw), Some(0.75));
    }
    #[test]
    fn fs_type_optimal_buffer_sizes() {
        assert_eq!(FsType::Ext4.optimal_write_buffer(), 128 * 1024);
        assert_eq!(FsType::Xfs.optimal_write_buffer(), 256 * 1024);
        assert_eq!(FsType::EulerFs.optimal_write_buffer(), 256 * 1024);
        assert_eq!(FsType::Btrfs.optimal_write_buffer(), 64 * 1024);
        assert!(FsType::Other.optimal_write_buffer() > 0);
    }

    #[test]
    fn fs_type_openeuler_native() {
        assert!(FsType::EulerFs.is_openeuler_native());
        assert!(FsType::Ext4.is_openeuler_native());
        assert!(!FsType::Xfs.is_openeuler_native());
        assert!(!FsType::Btrfs.is_openeuler_native());
    }

    #[test]
    fn blob_temperature_categorization() {
        let now = now_unix() as i64;
        assert_eq!(categorize_blob_temperature(now), BlobTemperature::Hot);
        assert_eq!(
            categorize_blob_temperature(now - 1800),
            BlobTemperature::Hot
        );
        assert_eq!(
            categorize_blob_temperature(now - 7200),
            BlobTemperature::Warm
        );
        assert_eq!(
            categorize_blob_temperature(now - 691200),
            BlobTemperature::Cold
        );
    }

    #[test]
    fn numa_topology_has_at_least_one_node() {
        let topo = detect_numa_topology();
        assert!(topo.node_count >= 1);
        assert!(!topo.cpu_to_node.is_empty());
    }

    #[test]
    fn fs_detect_returns_valid_type() {
        let fs = detect_fs_type(Path::new("."));
        let _ = fs.to_string();
        assert!(fs.optimal_write_buffer() > 0);
    }

    #[test]
    fn chunk_size_is_reasonable() {
        let sz = io_chunk_size_bytes();
        assert!(sz >= 64 * 1024);
        assert!(sz <= 4 * 1024 * 1024);
    }

    #[test]
    fn adaptive_compression_hot_is_fast() {
        // Compression::fast() 的 level 低于 default
        let hot = adaptive_compression(BlobTemperature::Hot);
        let default = adaptive_compression(BlobTemperature::Warm);
        assert!(hot.level() <= default.level());
    }

    #[test]
    fn adaptive_compression_cold_is_best() {
        let cold = adaptive_compression(BlobTemperature::Cold);
        let default = adaptive_compression(BlobTemperature::Warm);
        assert!(cold.level() >= default.level());
    }
}
