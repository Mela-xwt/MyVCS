use myvcs::repo::Repo;
use serde_json::json;
use std::{
    fs,
    io::{Read, Write},
    path::PathBuf,
    process::{Child, Command, Output, Stdio},
    sync::atomic::{AtomicU64, Ordering},
};
static NEXT: AtomicU64 = AtomicU64::new(0);
struct Lab(PathBuf);
impl Lab {
    fn new() -> Self {
        let p = std::env::temp_dir().join(format!(
            "myvcs-team-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&p).unwrap();
        Self(p)
    }
    fn output(&self, args: &[&str], actor: Option<&str>) -> Output {
        let mut c = Command::new(env!("CARGO_BIN_EXE_myvcs"));
        c.current_dir(&self.0)
            .args(args)
            .env_remove("MYVCS_PRINCIPAL")
            .env("MYVCS_TRANSFER_TIMEOUT", "20");
        if let Some(a) = actor {
            c.env("MYVCS_PRINCIPAL", a);
        }
        c.output().unwrap()
    }
    fn run(&self, args: &[&str], actor: Option<&str>) -> String {
        let o = self.output(args, actor);
        assert!(
            o.status.success(),
            "{args:?}: {}",
            String::from_utf8_lossy(&o.stderr)
        );
        String::from_utf8(o.stdout).unwrap()
    }
    fn fail(&self, args: &[&str], actor: Option<&str>, message: &str) {
        let o = self.output(args, actor);
        assert!(!o.status.success(), "{args:?} succeeded");
        assert!(
            String::from_utf8_lossy(&o.stderr).contains(message),
            "{}",
            String::from_utf8_lossy(&o.stderr)
        );
    }
    fn repo(&self, n: &str) -> Repo {
        Repo::open(self.0.join(n)).unwrap()
    }
    fn tip(&self, n: &str) -> String {
        self.repo(n).head_commit_id().unwrap().unwrap()
    }
    fn commit(&self, n: &str, text: &str) {
        fs::write(self.0.join(n).join("f"), text).unwrap();
        self.run(&["--repo", n, "add", "f"], None);
        self.run(&["--repo", n, "commit", "-m", text], None);
    }
    fn setup(&self, policy: bool) {
        self.run(&["init", "--bare", "--team", "server"], None);
        if policy {
            fs::write(self.0.join("server/policy.json"),json!({"version":1,"users":{"alice":{"read":true,"write":["refs/heads/*","refs/tags/*"],"force":["refs/heads/*"],"delete":["refs/heads/*","refs/tags/*"]},"reader":{"read":true,"write":[],"force":[],"delete":[]},"bob":{"read":true,"write":["refs/heads/bob/*"],"force":[],"delete":[]}}}).to_string()).unwrap();
        }
        let url = format!("file://{}", self.0.join("server").display());
        self.run(&["clone", &url, "a"], Some("alice"));
        self.run(&["--repo", "a", "upgrade", "--quiescent"], None);
        self.commit("a", "one");
        self.run(&["--repo", "a", "push"], Some("alice"));
    }
}

fn frame(w: &mut impl Write, value: serde_json::Value) {
    let b = serde_json::to_vec(&value).unwrap();
    w.write_all(&(b.len() as u32).to_be_bytes()).unwrap();
    w.write_all(&b).unwrap();
    w.flush().unwrap();
}
fn read_frame(r: &mut impl Read) -> serde_json::Value {
    let mut n = [0; 4];
    r.read_exact(&mut n).unwrap();
    let n = u32::from_be_bytes(n) as usize;
    assert!(n <= 1024 * 1024);
    let mut b = vec![0; n];
    r.read_exact(&mut b).unwrap();
    serde_json::from_slice(&b).unwrap()
}
fn service(l: &Lab, actor: Option<&str>, version: u32) -> Child {
    let mut c = Command::new(env!("CARGO_BIN_EXE_myvcs"));
    c.args(["serve", "--root"])
        .arg(&l.0)
        .args(["--repository", "server"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .env_remove("MYVCS_PRINCIPAL")
        .env("MYVCS_TRANSFER_TIMEOUT", "20");
    if let Some(a) = actor {
        c.env("MYVCS_PRINCIPAL", a);
    }
    let mut child = c.spawn().unwrap();
    frame(
        child.stdin.as_mut().unwrap(),
        json!({"Hello":{"version":version,"object_format":1,"hash":"sha256","pack":"full-zlib-v1"}}),
    );
    child
}
fn advertised_service(l: &Lab, actor: &str, version: u32) -> Child {
    let mut child = service(l, Some(actor), version);
    assert!(
        read_frame(child.stdout.as_mut().unwrap())
            .get("Hello")
            .is_some()
    );
    assert!(
        read_frame(child.stdout.as_mut().unwrap())
            .get("Refs")
            .is_some()
    );
    child
}
fn empty_pack(child: &mut Child) {
    use sha2::{Digest, Sha256};
    frame(child.stdin.as_mut().unwrap(), json!("Pack"));
    let mut b = b"MYVCSPK1".to_vec();
    b.extend_from_slice(&0u32.to_be_bytes());
    b.extend_from_slice(&Sha256::digest(&b.clone()));
    child.stdin.as_mut().unwrap().write_all(&b).unwrap();
    frame(child.stdin.as_mut().unwrap(), json!("End"));
}

#[test]
fn v1_and_v2_recheck_policy_revocation_under_final_lock() {
    for version in [1, 2] {
        let l = Lab::new();
        l.setup(true);
        let old = l.tip("server");
        let mut child = advertised_service(&l, "alice", version);
        let change = json!({"name":"refs/heads/main","expected":old,"new":old});
        let request = if version == 1 {
            json!({"Push":{"branch":"main","expected":old,"new":old}})
        } else {
            json!({"PushRefs":{"changes":[change],"leases":{}}})
        };
        frame(child.stdin.as_mut().unwrap(), request);
        assert_eq!(read_frame(child.stdout.as_mut().unwrap()), json!("Ok"));
        let path = l.0.join("server/policy.json");
        let mut p: serde_json::Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        p["users"]["alice"]["write"] = json!([]);
        fs::write(&path, p.to_string()).unwrap();
        empty_pack(&mut child);
        let response = read_frame(child.stdout.as_mut().unwrap());
        assert!(
            response["Error"]["message"]
                .as_str()
                .unwrap()
                .contains("denied")
        );
        assert!(!child.wait().unwrap().success());
        assert_eq!(l.tip("server"), old);
        assert!(
            l.run(&["--repo", "server", "audit"], None)
                .contains("denied")
        );
    }
}

#[test]
fn concurrent_atomic_network_sessions_publish_no_partial_batch() {
    let l = Lab::new();
    l.setup(true);
    let old = l.tip("server");
    let mut first = advertised_service(&l, "alice", 2);
    let mut second = advertised_service(&l, "alice", 2);
    for (index, child) in [&mut first, &mut second].into_iter().enumerate() {
        let other = if index == 0 {
            "refs/heads/y"
        } else {
            "refs/heads/z"
        };
        let changes = json!([{"name":"refs/heads/x","expected":null,"new":old},{"name":other,"expected":null,"new":old}]);
        frame(
            child.stdin.as_mut().unwrap(),
            json!({"PushRefs":{"changes":changes,"leases":{}}}),
        );
        assert_eq!(read_frame(child.stdout.as_mut().unwrap()), json!("Ok"));
    }
    for (i, child) in [&mut first, &mut second].into_iter().enumerate() {
        empty_pack(child);
        let response = read_frame(child.stdout.as_mut().unwrap());
        if i == 0 {
            assert_eq!(response, json!("Ok"));
            assert!(child.wait().unwrap().success());
        } else {
            assert!(
                response["Error"]["message"]
                    .as_str()
                    .unwrap()
                    .contains("changed concurrently")
            );
            assert!(!child.wait().unwrap().success());
        }
    }
    let state = l.repo("server").refs_snapshot().unwrap();
    assert_eq!(state.refs.get("refs/heads/x"), Some(&old));
    assert_eq!(state.refs.get("refs/heads/y"), Some(&old));
    assert!(!state.refs.contains_key("refs/heads/z"));
    let x = state
        .reflog
        .iter()
        .find(|e| e.name == "refs/heads/x")
        .unwrap();
    let y = state
        .reflog
        .iter()
        .find(|e| e.name == "refs/heads/y")
        .unwrap();
    assert_eq!(x.transaction, y.transaction);
    assert_eq!(x.actor, "alice");
}

#[test]
fn no_advertisement_without_read_and_no_wire_principal_spoofing() {
    let l = Lab::new();
    l.setup(true);
    for actor in [None, Some("outsider"), Some("bad\nactor")] {
        let mut child = service(&l, actor, 2);
        let response = read_frame(child.stdout.as_mut().unwrap());
        assert!(
            response["Error"]["message"]
                .as_str()
                .unwrap()
                .contains("denied")
        );
        assert!(!child.wait().unwrap().success());
    }
    let mut child = advertised_service(&l, "reader", 1);
    frame(
        child.stdin.as_mut().unwrap(),
        json!({"Push":{"branch":"main","expected":l.tip("server"),"new":l.tip("server"),"principal":"alice"}}),
    );
    assert!(
        read_frame(child.stdout.as_mut().unwrap())
            .get("Error")
            .is_some()
    );
    assert!(!child.wait().unwrap().success());
    l.run(&["--repo", "a", "config", "user.name", "alice"], None);
    l.run(
        &["--repo", "a", "config", "user.email", "alice@example.test"],
        None,
    );
    l.commit("a", "forged author");
    l.fail(&["--repo", "a", "push"], Some("reader"), "denied");
}

#[test]
fn complete_advertisement_prunes_deleted_upstream_only() {
    let l = Lab::new();
    l.setup(true);
    l.run(&["--repo", "a", "branch", "release"], None);
    l.run(&["--repo", "a", "push", "origin", "release"], Some("alice"));
    l.run(
        &["--repo", "a", "fetch", "origin", "release"],
        Some("alice"),
    );
    let oid = l.tip("a");
    l.repo("a")
        .transact_refs(
            &[
                myvcs::repo::RefChange {
                    name: "refs/remotes/other/release".into(),
                    expected: None,
                    new: Some(oid.clone()),
                },
                myvcs::repo::RefChange {
                    name: "refs/remotes/origin/extra".into(),
                    expected: None,
                    new: Some(oid.clone()),
                },
            ],
            "test roots",
        )
        .unwrap();
    l.run(&["--repo", "a", "tag", "keep"], None);
    l.run(
        &[
            "--repo",
            "a",
            "branch",
            "--set-upstream-to",
            "origin/release",
        ],
        None,
    );
    l.run(
        &["--repo", "a", "push", "origin", ":release"],
        Some("alice"),
    );
    l.run(&["--repo", "a", "fetch", "--prune"], Some("alice"));
    let refs = l.repo("a").list_refs().unwrap();
    assert!(!refs.contains_key("refs/remotes/origin/release"));
    assert!(!refs.contains_key("refs/remotes/origin/extra"));
    for n in [
        "refs/remotes/other/release",
        "refs/heads/release",
        "refs/tags/keep",
        "refs/remotes/origin/main",
    ] {
        assert!(refs.contains_key(n), "{n}");
    }
    l.run(&["--repo", "a", "fetch", "origin", "main"], Some("alice"));
    l.run(&["--repo", "a", "branch", "--unset-upstream"], None);
    assert!(!l.run(&["--repo", "a", "branch"], None).contains("upstream"));
    l.fail(
        &["--repo", "a", "branch", "--set-upstream-to", "unknown/main"],
        None,
        "configured",
    );
}

#[test]
fn explicit_tag_fetch_conflict_has_no_partial_tracking_update() {
    let l = Lab::new();
    l.setup(true);
    let old = l.tip("a");
    l.run(&["--repo", "a", "tag", "v1"], None);
    l.run(&["--repo", "a", "push", "--tags"], Some("alice"));
    let url = format!("file://{}", l.0.join("server").display());
    l.run(&["clone", &url, "b"], Some("alice"));
    l.run(&["--repo", "b", "upgrade", "--quiescent"], None);
    assert!(l.repo("b").read_ref("refs/tags/v1").unwrap().is_none());
    l.commit("a", "new");
    l.run(&["--repo", "a", "push"], Some("alice"));
    l.commit("b", "different");
    l.run(&["--repo", "b", "tag", "v1"], None);
    l.fail(
        &["--repo", "b", "fetch", "--tags"],
        Some("alice"),
        "tag conflict",
    );
    assert_eq!(
        l.repo("b").read_ref("refs/remotes/origin/main").unwrap(),
        Some(old)
    );
    l.run(&["--repo", "b", "tag", "-d", "v1"], None);
    l.run(&["--repo", "b", "fetch", "--tags"], Some("alice"));
    l.run(&["--repo", "b", "gc"], None);
    l.run(&["--repo", "b", "verify"], None);
    assert!(l.repo("b").resolve_commit("v1").is_ok());
    l.run(&["--repo", "b", "tag", "-d", "v1"], None);
    l.run(&["--repo", "b", "tag", "v1"], None);
    l.fail(
        &["--repo", "b", "push", "--tags"],
        Some("alice"),
        "immutable",
    );
}

#[test]
fn dag_log_is_topological_and_includes_second_parent_and_detached_roots() {
    let l = Lab::new();
    l.setup(false);
    let base = l.tip("a");
    l.run(&["--repo", "a", "branch", "side"], None);
    l.commit("a", "main changed");
    let main = l.tip("a");
    l.run(&["--repo", "a", "checkout", "side"], None);
    fs::write(l.0.join("a/g"), "side file").unwrap();
    l.run(&["--repo", "a", "add", "g"], None);
    l.run(&["--repo", "a", "commit", "-m", "side"], None);
    let side = l.tip("a");
    l.run(&["--repo", "a", "config", "user.name", "Merger"], None);
    l.run(
        &["--repo", "a", "config", "user.email", "merge@example.test"],
        None,
    );
    l.run(&["--repo", "a", "merge", "main"], None);
    let merge = l.tip("a");
    assert_eq!(
        l.repo("a").read_commit(&merge).unwrap().author,
        "Merger <merge@example.test>"
    );
    for options in [
        vec!["--repo", "a", "log"],
        vec!["--repo", "a", "log", "--graph", "--all"],
    ] {
        let output = l.run(&options, None);
        let rows: Vec<_> = output
            .lines()
            .filter(|line| line.contains("commit "))
            .collect();
        for id in [&base, &main, &side, &merge] {
            assert_eq!(rows.iter().filter(|r| r.contains(id.as_str())).count(), 1);
        }
        let index = |id: &str| rows.iter().position(|r| r.contains(id)).unwrap();
        assert!(
            index(&merge) < index(&side)
                && index(&merge) < index(&main)
                && index(&main) < index(&base)
                && index(&side) < index(&base)
        );
        assert!(output.contains(&format!("Parents: {side} {main}")));
    }
    l.run(&["--repo", "a", "checkout", &base], None);
    l.commit("a", "detached");
    let detached = l.tip("a");
    l.run(&["--repo", "a", "checkout", "main"], None);
    assert!(
        !l.run(&["--repo", "a", "log", "--graph", "--all"], None)
            .contains(&detached)
    );
    l.run(&["--repo", "a", "checkout", &detached], None);
    assert!(
        l.run(&["--repo", "a", "log", "--graph", "--all"], None)
            .contains(&detached)
    );
}

#[test]
fn strict_policy_and_audit_maintenance_fail_closed() {
    let l = Lab::new();
    l.setup(true);
    let p = l.0.join("server/policy.json");
    let old = fs::read(&p).unwrap();
    for broken in [
        json!({"version":2,"users":{}}),
        json!({"version":1,"users":{},"unknown":true}),
        json!({"version":1,"users":{"alice":{"read":true,"write":["refs/pins/*"],"force":[],"delete":[]}}}),
        json!({"version":1,"users":{"alice":{"read":true,"write":["refs/heads/m*"],"force":[],"delete":[]}}}),
    ] {
        fs::write(&p, broken.to_string()).unwrap();
        l.fail(&["--repo", "a", "fetch"], Some("alice"), "policy");
    }
    fs::write(&p, old).unwrap();
    let journal = l.0.join("server/audit-attempts.json");
    fs::write(&journal, "broken").unwrap();
    let mut child = service(&l, Some("alice"), 2);
    assert!(
        read_frame(child.stdout.as_mut().unwrap())
            .get("Error")
            .is_some()
    );
    assert!(!child.wait().unwrap().success());
    fs::write(&journal, "[]").unwrap();
    l.run(&["--repo", "a", "fetch"], Some("alice"));
    l.fail(&["--repo", "a", "push"], Some("reader"), "denied");
    l.run(
        &["--repo", "server", "audit", "expire", "--keep", "0"],
        None,
    );
    assert_eq!(fs::read_to_string(journal).unwrap(), "[]");
    assert!(
        l.run(&["--repo", "server", "audit"], None)
            .contains("success")
    );
    l.run(
        &["--repo", "server", "reflog", "expire", "--keep", "0"],
        None,
    );
    assert!(l.run(&["--repo", "server", "audit"], None).is_empty());
    let journal = l.0.join("server/audit-attempts.json");
    let record = json!({"actor":"alice","op":"read","refs":[],"result":"allowed","time":1});
    fs::write(&journal, serde_json::to_vec(&vec![record; 10000]).unwrap()).unwrap();
    let mut child = service(&l, Some("alice"), 2);
    assert!(
        read_frame(child.stdout.as_mut().unwrap())["Error"]["message"]
            .as_str()
            .unwrap()
            .contains("journal full")
    );
    assert!(!child.wait().unwrap().success());
    l.run(
        &["--repo", "server", "audit", "expire", "--keep", "2"],
        None,
    );
    l.run(&["--repo", "a", "fetch"], Some("alice"));
}

#[test]
fn full_pack_downgrade_and_format1_extended_receive_error() {
    let l = Lab::new();
    l.setup(true);
    l.run(&["--repo", "a", "branch", "full"], None);
    let out = Command::new(env!("CARGO_BIN_EXE_myvcs"))
        .current_dir(&l.0)
        .args(["--repo", "a", "push", "--atomic", "origin", "main", "full"])
        .env("MYVCS_PRINCIPAL", "alice")
        .env("MYVCS_PACK_MODE", "full")
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "{}",
        String::from_utf8_lossy(&out.stderr)
    );
    l.run(&["init", "--bare", "legacy"], None);
    let url = format!("file://{}", l.0.join("legacy").display());
    l.run(&["--repo", "a", "remote", "add", "old", &url], None);
    l.run(&["--repo", "a", "push", "old", "main"], None);
    l.fail(
        &["--repo", "a", "push", "--atomic", "old", "main", "full"],
        None,
        "format 2",
    );
    l.run(&["clone", &url, "legacy-client"], None);
    l.fail(
        &["--repo", "legacy-client", "fetch", "--tags"],
        None,
        "local format 2",
    );
}

#[test]
fn tag_only_history_is_transferred_and_survives_gc_without_reflog() {
    let l = Lab::new();
    l.setup(true);
    l.run(&["--repo", "a", "branch", "side"], None);
    l.run(&["--repo", "a", "checkout", "side"], None);
    l.commit("a", "tag-only-content");
    let tag_tip = l.tip("a");
    l.run(&["--repo", "a", "tag", "archived"], None);
    l.run(&["--repo", "a", "checkout", "main"], None);
    l.run(&["--repo", "a", "branch", "-d", "side"], None);
    l.run(&["--repo", "a", "push", "--tags"], Some("alice"));
    let url = format!("file://{}", l.0.join("server").display());
    l.run(&["clone", &url, "b"], Some("alice"));
    l.run(&["--repo", "b", "upgrade", "--quiescent"], None);
    l.run(&["--repo", "b", "fetch", "--tags"], Some("alice"));
    for name in ["b", "server"] {
        l.run(&["--repo", name, "reflog", "expire", "--keep", "0"], None);
        l.run(&["--repo", name, "gc"], None);
        l.run(&["--repo", name, "verify"], None);
        assert_eq!(l.repo(name).resolve_commit("archived").unwrap(), tag_tip);
        assert!(l.repo(name).read_commit(&tag_tip).is_ok());
    }
    l.run(&["--repo", "b", "tag", "-d", "archived"], None);
    l.run(&["--repo", "b", "reflog", "expire", "--keep", "0"], None);
    l.run(&["--repo", "b", "gc"], None);
    assert!(l.repo("b").read_commit(&tag_tip).is_err());
}

#[test]
fn separate_force_and_delete_permissions_and_unused_leases_fail() {
    let l = Lab::new();
    l.setup(true);
    let old = l.tip("a");
    l.commit("a", "next");
    l.run(&["--repo", "a", "push"], Some("alice"));
    let fresh = l.tip("server");
    l.run(&["--repo", "a", "reset", "--hard", &old], None);
    let path = l.0.join("server/policy.json");
    let mut policy: serde_json::Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    policy["users"]["limited"] =
        json!({"read":true,"write":["refs/heads/*","refs/tags/*"],"force":[],"delete":[]});
    fs::write(&path, policy.to_string()).unwrap();
    l.fail(
        &[
            "--repo",
            "a",
            "push",
            "--force-with-lease",
            &format!("refs/heads/main:{fresh}"),
        ],
        Some("limited"),
        "force permission",
    );
    assert_eq!(l.tip("server"), fresh);
    l.fail(
        &[
            "--repo",
            "a",
            "push",
            "--force-with-lease",
            &format!("refs/heads/unused:{fresh}"),
        ],
        Some("alice"),
        "unused",
    );
    l.run(&["--repo", "a", "branch", "release"], None);
    l.run(
        &["--repo", "a", "push", "origin", "release"],
        Some("limited"),
    );
    l.fail(
        &["--repo", "a", "push", "origin", ":release"],
        Some("limited"),
        "delete permission",
    );
    l.fail(
        &["--repo", "a", "push", "--force"],
        Some("alice"),
        "unexpected argument",
    );
    fs::remove_file(path).unwrap();
    l.fail(
        &["--repo", "a", "push", "origin", ":release"],
        None,
        "explicit policy",
    );
    l.fail(
        &[
            "--repo",
            "a",
            "push",
            "--force-with-lease",
            &format!("refs/heads/main:{fresh}"),
        ],
        None,
        "explicit policy",
    );
}

#[test]
fn managed_legacy_writes_require_upgrade_and_read_false_denies_advertisement() {
    let l = Lab::new();
    l.setup(false);
    let path = l.0.join("server/policy.json");
    fs::write(&path,json!({"version":1,"users":{"blocked":{"read":false,"write":["refs/heads/*"],"force":[],"delete":[]}}}).to_string()).unwrap();
    let mut child = service(&l, Some("blocked"), 1);
    let first = read_frame(child.stdout.as_mut().unwrap());
    assert!(
        first["Error"]["message"]
            .as_str()
            .unwrap()
            .contains("read permission")
    );
    assert!(!child.wait().unwrap().success());
    l.run(&["init", "--bare", "legacy"], None);
    let url = format!("file://{}", l.0.join("legacy").display());
    l.run(&["--repo", "a", "remote", "add", "legacy", &url], None);
    fs::write(l.0.join("legacy/policy.json"),json!({"version":1,"users":{"alice":{"read":true,"write":["refs/heads/*"],"force":[],"delete":[]}}}).to_string()).unwrap();
    l.fail(
        &["--repo", "a", "push", "legacy", "main"],
        Some("alice"),
        "format 2",
    );
}

#[test]
fn format1_attempt_audit_lists_exports_and_expires_without_upgrade() {
    let l = Lab::new();
    l.run(&["init", "--bare", "server"], None);
    let url = format!("file://{}", l.0.join("server").display());
    l.run(&["clone", &url, "client"], Some("alice"));
    let mut failed = advertised_service(&l, "alice", 1);
    frame(failed.stdin.as_mut().unwrap(), json!({"InvalidRequest":{}}));
    assert!(
        read_frame(failed.stdout.as_mut().unwrap())
            .get("Error")
            .is_some()
    );
    assert!(!failed.wait().unwrap().success());
    fs::write(
        l.0.join("server/policy.json"),
        json!({"version":1,"users":{"blocked":{"read":false,"write":[],"force":[],"delete":[]}}})
            .to_string(),
    )
    .unwrap();
    let mut denied = service(&l, Some("blocked"), 1);
    assert!(
        read_frame(denied.stdout.as_mut().unwrap())["Error"]["message"]
            .as_str()
            .unwrap()
            .contains("denied")
    );
    assert!(!denied.wait().unwrap().success());
    let repo = l.repo("server");
    assert_eq!(repo.format_version().unwrap(), 1);
    let journal = l.0.join("server/audit-attempts.json");
    let original = fs::read(&journal).unwrap();
    let expected: Vec<serde_json::Value> = serde_json::from_slice(&original).unwrap();
    assert!(
        expected
            .iter()
            .any(|e| e["actor"] == "alice" && e["op"] == "read" && e["result"] == "allowed")
    );
    assert!(
        expected
            .iter()
            .any(|e| e["actor"] == "alice" && e["result"] == "failed")
    );
    assert!(
        expected
            .iter()
            .any(|e| e["actor"] == "blocked" && e["result"] == "denied")
    );
    let export = l.run(&["--repo", "server", "audit", "--limit", "10000"], None);
    let exported: Vec<serde_json::Value> = export
        .lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect();
    assert_eq!(exported, expected);
    assert!(exported.iter().all(|e| e["result"] != "success"));
    assert_eq!(repo.audit_list(2).unwrap().len(), 2);
    l.run(
        &["--repo", "server", "audit", "expire", "--keep", "2"],
        None,
    );
    let remaining: Vec<serde_json::Value> = l
        .run(&["--repo", "server", "audit"], None)
        .lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect();
    assert_eq!(remaining, expected[expected.len() - 2..]);
    assert_eq!(repo.format_version().unwrap(), 1);
    assert!(!l.0.join("server/refs-state.json").exists());
    fs::write(&journal, "broken").unwrap();
    assert!(repo.audit_list(100).is_err());
    fs::write(&journal, &original).unwrap();
    let bounded = repo
        .clone()
        .with_read_limits(myvcs::repo::ReadLimits {
            metadata_bytes: 100,
            ..Default::default()
        })
        .unwrap();
    assert!(bounded.audit_list(100).is_err());
    l.run(
        &["--repo", "server", "audit", "expire", "--keep", "0"],
        None,
    );
    assert!(l.run(&["--repo", "server", "audit"], None).is_empty());
    assert_eq!(repo.format_version().unwrap(), 1);
}
impl Drop for Lab {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

#[test]
fn identity_tags_and_upstream_routes() {
    let l = Lab::new();
    l.setup(false);
    l.run(&["--repo", "a", "config", "user.name", "Alice"], None);
    l.run(
        &["--repo", "a", "config", "user.email", "a@example.test"],
        None,
    );
    l.commit("a", "two");
    let id = l.tip("a");
    assert_eq!(
        l.repo("a").read_commit(&id).unwrap().author,
        "Alice <a@example.test>"
    );
    l.run(
        &["--repo", "a", "push", "-u", "origin", "main:custom"],
        None,
    );
    l.commit("a", "three");
    l.run(&["--repo", "a", "push"], None);
    assert_eq!(
        l.repo("server").read_ref("refs/heads/custom").unwrap(),
        Some(l.tip("a"))
    );
    l.run(&["--repo", "a", "tag", "v1"], None);
    l.fail(&["--repo", "a", "tag", "v1", &id], None, "exists");
    l.run(
        &["--repo", "a", "push", "origin", "refs/tags/v1:refs/tags/v1"],
        None,
    );
    l.run(&["--repo", "a", "fetch", "--tags"], None);
    assert!(
        l.run(&["--repo", "a", "branch"], None)
            .contains("origin/custom")
    );
}

#[test]
fn managed_policy_and_atomic_failure() {
    let l = Lab::new();
    l.setup(true);
    l.fail(&["--repo", "a", "fetch"], None, "denied");
    l.commit("a", "new");
    l.fail(&["--repo", "a", "push"], Some("reader"), "denied");
    let old = l.tip("server");
    l.run(&["--repo", "a", "branch", "bob/ok"], None);
    l.run(&["--repo", "a", "branch", "bad"], None);
    l.fail(
        &["--repo", "a", "push", "--atomic", "origin", "bob/ok", "bad"],
        Some("bob"),
        "denied",
    );
    assert_eq!(l.tip("server"), old);
    assert_eq!(
        l.repo("server").read_ref("refs/heads/bob/ok").unwrap(),
        None
    );
    l.run(&["--repo", "a", "push"], Some("alice"));
    let audit = l.run(&["--repo", "server", "audit"], None);
    assert!(audit.contains("alice") && audit.contains("reader") && audit.contains("denied"));
}

#[test]
fn pruning_and_force_lease_are_scoped() {
    let l = Lab::new();
    l.setup(true);
    l.run(&["--repo", "a", "branch", "release"], None);
    l.run(&["--repo", "a", "push", "origin", "release"], Some("alice"));
    l.run(
        &["--repo", "a", "fetch", "origin", "release"],
        Some("alice"),
    );
    let old = l.tip("a");
    l.commit("a", "next");
    l.run(&["--repo", "a", "push"], Some("alice"));
    l.run(&["--repo", "a", "reset", "--hard", &old], None);
    l.fail(
        &[
            "--repo",
            "a",
            "push",
            "--force-with-lease",
            &format!("refs/heads/main:{old}"),
        ],
        Some("alice"),
        "lease",
    );
    let fresh = l.tip("server");
    l.run(
        &[
            "--repo",
            "a",
            "push",
            "--force-with-lease",
            &format!("refs/heads/main:{fresh}"),
        ],
        Some("alice"),
    );
    l.fail(
        &["--repo", "a", "push", "origin", ":main"],
        Some("alice"),
        "HEAD",
    );
    l.run(
        &["--repo", "a", "push", "origin", ":release"],
        Some("alice"),
    );
    l.run(&["--repo", "a", "fetch", "--prune"], Some("alice"));
    assert!(
        l.repo("a")
            .read_ref("refs/remotes/origin/release")
            .unwrap()
            .is_none()
    );
    assert!(
        l.repo("a")
            .read_ref("refs/heads/release")
            .unwrap()
            .is_some()
    );
}
