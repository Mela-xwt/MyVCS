use myvcs::{
    model::Commit,
    repo::{RefChange, Repo},
    util::{compress_bytes, hex_sha256},
};
use std::{fs, path::PathBuf};
struct Lab(PathBuf);
impl Lab {
    fn new() -> Self {
        let p = std::env::temp_dir().join(format!(
            "team-recovery-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&p).unwrap();
        Self(p)
    }
}
impl Drop for Lab {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn object(r: &Repo, message: &str) -> String {
    let raw = serde_json::to_vec(&Commit {
        tree: Default::default(),
        parents: vec![],
        parent: None,
        message: message.into(),
        author: "test".into(),
        timestamp: 0,
    })
    .unwrap();
    let id = hex_sha256(&raw);
    let p = r
        .metadata_dir()
        .join("objects")
        .join(&id[..2])
        .join(&id[2..]);
    fs::create_dir_all(p.parent().unwrap()).unwrap();
    fs::write(
        p,
        compress_bytes(&raw, flate2::Compression::default()).unwrap(),
    )
    .unwrap();
    id
}
fn change(name: &str, old: Option<&str>, new: Option<&str>) -> RefChange {
    RefChange {
        name: format!("refs/heads/{name}"),
        expected: old.map(Into::into),
        new: new.map(Into::into),
    }
}
#[test]
fn upgrade_snapshot_atomic_cas_alias_and_closed_parser() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    let a = object(&r, "a");
    r.update_ref("refs/heads/main", None, &a).unwrap();
    r.upgrade().unwrap();
    assert_eq!(r.head_commit_id().unwrap(), Some(a.clone()));
    fs::write(r.metadata_dir().join("refs/heads/main"), "garbage").unwrap();
    fs::write(r.metadata_dir().join("HEAD"), "garbage").unwrap();
    assert_eq!(r.head_commit_id().unwrap(), Some(a.clone()));
    r.transact_refs(
        &[change("x", None, Some(&a)), change("y", None, Some(&a))],
        "batch",
    )
    .unwrap();
    let before = r.refs_snapshot().unwrap();
    assert!(
        r.transact_refs(
            &[change("x", Some(&a), None), change("y", None, None)],
            "bad"
        )
        .is_err()
    );
    assert_eq!(r.refs_snapshot().unwrap().generation, before.generation);
    assert!(
        r.transact_refs(&[change("X", None, Some(&a))], "alias")
            .is_err()
    );
    assert!(
        r.transact_refs(&[change("x/sub", None, Some(&a))], "alias")
            .is_err()
    );
    r.upgrade().unwrap();
    assert_eq!(r.refs_snapshot().unwrap().generation, before.generation);
    fs::write(r.metadata_dir().join("refs-state.json"), "{}").unwrap();
    assert!(r.list_refs().is_err());
    assert!(Repo::open(&l.0).is_err());
}
#[test]
fn reflog_gc_recovery_expiry_and_sequence() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    r.upgrade().unwrap();
    let a = object(&r, "orphan");
    r.transact_refs(&[change("lost", None, Some(&a))], "create")
        .unwrap();
    r.transact_refs(&[change("lost", Some(&a), None)], "delete")
        .unwrap();
    r.with_repo_lock(|r| r.gc()).unwrap();
    r.recover(&a, "saved").unwrap();
    assert_eq!(r.read_ref("refs/heads/saved").unwrap(), Some(a.clone()));
    r.transact_refs(&[change("saved", Some(&a), None)], "delete")
        .unwrap();
    let seq = r.refs_snapshot().unwrap().next_seq;
    r.reflog_expire(0).unwrap();
    r.with_repo_lock(|r| r.gc()).unwrap();
    assert!(r.recover(&a, "missing").is_err());
    let b = object(&r, "next");
    r.transact_refs(&[change("next", None, Some(&b))], "next")
        .unwrap();
    assert!(r.reflog(None).unwrap()[0].seq >= seq);
}
#[test]
fn cas_process_worker() {
    let Ok(path) = std::env::var("MYVCS_CAS_REPO") else {
        return;
    };
    let old = std::env::var("MYVCS_CAS_OLD").unwrap();
    let new = std::env::var("MYVCS_CAS_NEW").unwrap();
    let r = Repo::open(path).unwrap();
    let changes = [
        change("main", Some(&old), Some(&new)),
        change("winner", None, Some(&new)),
    ];
    std::process::exit(if r.transact_refs(&changes, "process CAS").is_ok() {
        0
    } else {
        19
    });
}
#[test]
fn competing_real_processes_have_one_atomic_cas_winner() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    let a = object(&r, "base");
    let b = object(&r, "b");
    let c = object(&r, "c");
    r.update_ref("refs/heads/main", None, &a).unwrap();
    r.upgrade().unwrap();
    let spawn = |new: &str| {
        std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", "cas_process_worker"])
            .env("MYVCS_CAS_REPO", &l.0)
            .env("MYVCS_CAS_OLD", &a)
            .env("MYVCS_CAS_NEW", new)
            .stdout(std::process::Stdio::null())
            .spawn()
            .unwrap()
    };
    let mut x = spawn(&b);
    let mut y = spawn(&c);
    let mut codes = [
        x.wait().unwrap().code().unwrap(),
        y.wait().unwrap().code().unwrap(),
    ];
    codes.sort();
    assert_eq!(codes, [0, 19]);
    let s = r.refs_snapshot().unwrap();
    assert_eq!(s.refs["refs/heads/main"], s.refs["refs/heads/winner"]);
    assert_eq!(s.generation, 1);
    assert_eq!(s.reflog.len(), 3);
}
#[test]
fn receive_many_callback_union_and_last_cas_deny_before_install() {
    use myvcs::repo::ReceiveLimits;
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    r.upgrade().unwrap();
    let raw = serde_json::to_vec(&Commit {
        tree: Default::default(),
        parents: vec![],
        parent: None,
        message: "incoming".into(),
        author: "test".into(),
        timestamp: 0,
    })
    .unwrap();
    let id = hex_sha256(&raw);
    let changes = [change("a", None, Some(&id)), change("b", None, Some(&id))];
    let mut tx = r.begin_receive(ReceiveLimits::default()).unwrap();
    tx.stage_object(&id, raw.as_slice()).unwrap();
    assert!(
        tx.commit_many(
            &changes,
            &Default::default(),
            "alice",
            "denied",
            |view, s, c| {
                assert_eq!(view.read_commit(&id)?.message, "incoming");
                assert!(s.refs.is_empty());
                assert_eq!(c.len(), 2);
                anyhow::bail!("policy denied")
            }
        )
        .is_err()
    );
    let path = r
        .metadata_dir()
        .join("objects")
        .join(&id[..2])
        .join(&id[2..]);
    assert!(!path.exists());
    assert!(r.list_refs().unwrap().is_empty());
    let mut tx = r.begin_receive(ReceiveLimits::default()).unwrap();
    tx.stage_object(&id, raw.as_slice()).unwrap();
    let bad = [changes[0].clone(), change("b", Some(&id), Some(&id))];
    assert!(
        tx.commit_many(
            &bad,
            &Default::default(),
            "alice",
            "stale",
            |_, _, _| Ok(())
        )
        .is_err()
    );
    assert!(!path.exists());
    let mut tx = r.begin_receive(ReceiveLimits::default()).unwrap();
    tx.stage_object(&id, raw.as_slice()).unwrap();
    tx.commit_many(
        &changes,
        &Default::default(),
        "alice",
        "accepted",
        |_, _, _| Ok(()),
    )
    .unwrap();
    let s = r.refs_snapshot().unwrap();
    assert_eq!(s.generation, 1);
    assert_eq!(s.reflog.len(), 2);
    assert!(
        s.reflog
            .iter()
            .all(|e| e.actor == "alice" && e.reason == "accepted" && e.transaction == 1)
    );
    r.verify().unwrap();
}
fn file_commit(r: &Repo, text: &str) -> String {
    let bid = hex_sha256(text.as_bytes());
    let p = r
        .metadata_dir()
        .join("objects")
        .join(&bid[..2])
        .join(&bid[2..]);
    fs::create_dir_all(p.parent().unwrap()).unwrap();
    fs::write(
        p,
        compress_bytes(text.as_bytes(), flate2::Compression::default()).unwrap(),
    )
    .unwrap();
    let raw = serde_json::to_vec(&Commit {
        tree: [("file.txt".into(), bid)].into(),
        parents: vec![],
        parent: None,
        message: text.into(),
        author: "test".into(),
        timestamp: 0,
    })
    .unwrap();
    let id = hex_sha256(&raw);
    let p = r
        .metadata_dir()
        .join("objects")
        .join(&id[..2])
        .join(&id[2..]);
    fs::create_dir_all(p.parent().unwrap()).unwrap();
    fs::write(
        p,
        compress_bytes(&raw, flate2::Compression::default()).unwrap(),
    )
    .unwrap();
    id
}
#[test]
fn detached_and_reset_reflog_recover_files_despite_stale_legacy() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, false, true).unwrap();
    r.upgrade().unwrap();
    let a = file_commit(&r, "A");
    let b = file_commit(&r, "B");
    r.update_ref("refs/heads/main", None, &a).unwrap();
    r.with_repo_lock(|r| r.checkout("main")).unwrap();
    r.with_repo_lock(|r| r.checkout(&b)).unwrap();
    r.with_repo_lock(|r| r.checkout("main")).unwrap();
    fs::write(r.metadata_dir().join("HEAD"), "bad").unwrap();
    fs::write(r.metadata_dir().join("refs/heads/main"), "bad").unwrap();
    r.with_repo_lock(|r| r.reset_hard(&b)).unwrap();
    assert_eq!(fs::read_to_string(l.0.join("file.txt")).unwrap(), "B");
    r.with_repo_lock(|r| r.gc()).unwrap();
    r.recover(&a, "saved").unwrap();
    r.with_repo_lock(|r| r.checkout("saved")).unwrap();
    assert_eq!(fs::read_to_string(l.0.join("file.txt")).unwrap(), "A");
    r.with_repo_lock(|r| r.branch(None, Some("main"))).unwrap();
    assert!(r.read_ref("refs/heads/main").unwrap().is_none());
    assert_eq!(
        fs::read_to_string(r.metadata_dir().join("refs/heads/main")).unwrap(),
        "bad"
    );
    assert!(
        r.reflog(Some("HEAD"))
            .unwrap()
            .iter()
            .any(|e| e.old.as_deref() == Some(&b) && e.new.as_deref() == Some(&a))
    );
}
#[test]
fn metadata_capacity_fails_before_checkout_or_reset_materialization() {
    use myvcs::repo::ReadLimits;
    let l = Lab::new();
    let r = Repo::init_at(&l.0, false, true).unwrap();
    r.upgrade().unwrap();
    let a = file_commit(&r, "A");
    let b = file_commit(&r, "B");
    r.update_ref("refs/heads/main", None, &a).unwrap();
    r.with_repo_lock(|r| r.checkout("main")).unwrap();
    let len = fs::metadata(r.metadata_dir().join("refs-state.json"))
        .unwrap()
        .len() as usize;
    let small = r
        .clone()
        .with_read_limits(ReadLimits {
            metadata_bytes: len + 30,
            ..Default::default()
        })
        .unwrap();
    assert!(small.with_repo_lock(|r| r.reset_hard(&b)).is_err());
    assert_eq!(fs::read_to_string(l.0.join("file.txt")).unwrap(), "A");
    assert_eq!(r.head_commit_id().unwrap(), Some(a.clone()));
    assert!(small.with_repo_lock(|r| r.checkout(&b)).is_err());
    assert_eq!(fs::read_to_string(l.0.join("file.txt")).unwrap(), "A");
    r.reflog_expire(0).unwrap();
    assert!(small.with_repo_lock(|r| r.reset_hard(&b)).is_ok());
}
#[test]
fn legacy_handle_switches_and_future_format_is_rejected() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    let handle = Repo::open(&l.0).unwrap();
    let a = object(&r, "a");
    r.upgrade().unwrap();
    handle.update_ref("refs/heads/main", None, &a).unwrap();
    assert_eq!(r.head_commit_id().unwrap(), Some(a));
    assert_eq!(r.refs_snapshot().unwrap().generation, 1);
    fs::write(
        r.metadata_dir().join("format.json"),
        "{\"version\":99,\"bare\":true}",
    )
    .unwrap();
    assert!(handle.list_refs().is_err());
    assert!(handle.with_repo_lock(|_| Ok(())).is_err());
}
#[test]
fn state_parser_rejects_duplicate_refs_and_sequence_corruption() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    r.upgrade().unwrap();
    let a = object(&r, "a");
    r.update_ref("refs/heads/main", None, &a).unwrap();
    let p = r.metadata_dir().join("refs-state.json");
    let original = fs::read_to_string(&p).unwrap();
    let corrupt = original.replacen(
        &format!("\"refs\":{{\"refs/heads/main\":\"{a}\"}}"),
        &format!("\"refs\":{{\"refs/heads/main\":\"{a}\",\"refs/heads/main\":\"{a}\"}}"),
        1,
    );
    assert_ne!(corrupt, original);
    fs::write(&p, corrupt).unwrap();
    assert!(r.refs_snapshot().is_err());
    fs::write(&p, &original).unwrap();
    let mut value: serde_json::Value = serde_json::from_str(&original).unwrap();
    value["next_seq"] = serde_json::json!(1);
    fs::write(&p, serde_json::to_vec(&value).unwrap()).unwrap();
    assert!(r.list_refs().is_err());
    fs::write(&p, &original).unwrap();
    value = serde_json::from_str(&original).unwrap();
    value["next_seq"] = serde_json::json!(u64::MAX);
    fs::write(&p, serde_json::to_vec(&value).unwrap()).unwrap();
    let before = fs::read(&p).unwrap();
    assert!(
        r.transact_refs(&[change("new", None, Some(&a))], "overflow")
            .is_err()
    );
    assert_eq!(fs::read(&p).unwrap(), before);
}
#[test]
fn vector_limits_and_atomic_update_delete_create() {
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    r.upgrade().unwrap();
    let a = object(&r, "a");
    let b = object(&r, "b");
    r.transact_refs(
        &[change("a", None, Some(&a)), change("b", None, Some(&a))],
        "initial",
    )
    .unwrap();
    r.transact_refs(
        &[
            change("a", Some(&a), Some(&b)),
            change("b", Some(&a), None),
            change("c", None, Some(&b)),
        ],
        "atomic",
    )
    .unwrap();
    let s = r.refs_snapshot().unwrap();
    assert_eq!(s.refs.len(), 2);
    assert_eq!(s.refs["refs/heads/a"], b);
    assert_eq!(s.refs["refs/heads/c"], b);
    assert_eq!(s.generation, 2);
    assert!(s.reflog.iter().rev().take(3).all(|e| e.transaction == 2));
    assert!(r.transact_refs(&[], "empty").is_err());
    let changes: Vec<_> = (0..257)
        .map(|i| change(&format!("n{i}"), None, Some(&a)))
        .collect();
    assert!(r.transact_refs(&changes, "too many").is_err());
    assert!(
        r.transact_refs(
            &[change("c", Some(&b), None), change("C", None, Some(&a))],
            "duplicate case"
        )
        .is_err()
    );
    assert_eq!(r.refs_snapshot().unwrap().generation, 2);
}
#[test]
fn receive_union_caps_and_explicit_force_deletion() {
    use myvcs::repo::ReceiveLimits;
    let l = Lab::new();
    let r = Repo::init_at(&l.0, true, true).unwrap();
    r.upgrade().unwrap();
    let a = object(&r, "a");
    let b = object(&r, "b");
    let c = [change("a", None, Some(&a)), change("b", None, Some(&b))];
    let tx = r
        .begin_receive(ReceiveLimits {
            max_objects: 1,
            ..Default::default()
        })
        .unwrap();
    assert!(
        tx.commit_many(
            &c,
            &Default::default(),
            "alice",
            "union count",
            |_, _, _| Ok(())
        )
        .is_err()
    );
    assert!(r.list_refs().unwrap().is_empty());
    let tx = r
        .begin_receive(ReceiveLimits {
            max_total_bytes: 1,
            ..Default::default()
        })
        .unwrap();
    assert!(
        tx.commit_many(
            &c,
            &Default::default(),
            "alice",
            "union bytes",
            |_, _, _| Ok(())
        )
        .is_err()
    );
    assert!(r.list_refs().unwrap().is_empty());
    r.begin_receive(ReceiveLimits::default())
        .unwrap()
        .commit_many(&c, &Default::default(), "alice", "create", |_, _, _| Ok(()))
        .unwrap();
    let deletion = [change("a", Some(&a), None)];
    assert!(
        r.begin_receive(ReceiveLimits::default())
            .unwrap()
            .commit_many(
                &deletion,
                &Default::default(),
                "alice",
                "no allowance",
                |_, _, _| Ok(())
            )
            .is_err()
    );
    r.begin_receive(ReceiveLimits::default())
        .unwrap()
        .commit_many(
            &deletion,
            &["refs/heads/a".into()].into(),
            "alice",
            "delete",
            |_, _, _| Ok(()),
        )
        .unwrap();
    assert!(r.read_ref("refs/heads/a").unwrap().is_none());
    r.update_ref("refs/heads/main", None, &a).unwrap();
    assert!(
        r.begin_receive(ReceiveLimits::default())
            .unwrap()
            .commit_many(
                &[change("main", Some(&a), None)],
                &["refs/heads/main".into()].into(),
                "alice",
                "delete HEAD",
                |_, _, _| Ok(())
            )
            .is_err()
    );
}
#[test]
fn cli_team_requires_explicit_existing_repository_upgrade() {
    let l = Lab::new();
    let bin = env!("CARGO_BIN_EXE_myvcs");
    let p = l.0.join("repo");
    assert!(
        std::process::Command::new(bin)
            .args(["init", "--team", "--empty"])
            .arg(&p)
            .output()
            .unwrap()
            .status
            .success()
    );
    assert_eq!(Repo::open(&p).unwrap().format_version().unwrap(), 2);
    assert!(
        !std::process::Command::new(bin)
            .args(["init", "--team"])
            .arg(&p)
            .output()
            .unwrap()
            .status
            .success()
    );
    let q = l.0.join("legacy");
    Repo::init_at(&q, true, true).unwrap();
    assert!(
        !std::process::Command::new(bin)
            .arg("--repo")
            .arg(&q)
            .arg("upgrade")
            .output()
            .unwrap()
            .status
            .success()
    );
    assert_eq!(Repo::open(&q).unwrap().format_version().unwrap(), 1);
    assert!(
        std::process::Command::new(bin)
            .arg("--repo")
            .arg(&q)
            .args(["upgrade", "--quiescent"])
            .output()
            .unwrap()
            .status
            .success()
    );
}
