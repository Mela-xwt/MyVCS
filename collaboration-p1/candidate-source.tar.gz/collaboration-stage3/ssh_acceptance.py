"""Real SSH team acceptance using temporary restricted identity keys on loopback."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import zlib
from isolated_sshd import IsolatedSshd

p = argparse.ArgumentParser()
p.add_argument("--bin", required=True)
args = p.parse_args()
binary = Path(args.bin).resolve()
gate = Path(__file__).with_name("ssh-gate.py").resolve()
root = Path(tempfile.mkdtemp(prefix="myvcs-stage3-ssh-"))
repos = root / "repositories"
repos.mkdir()
environment = dict(os.environ, MYVCS_PACK_MODE="thin", MYVCS_FORCE_DEEP_DELTA="1")


def run(*command, actor=None, fail=None):
    env = dict(environment)
    if actor:
        env["MYVCS_SSH"] = ssh.wrapper(actor)
    result = subprocess.run([str(binary), *map(str, command)], cwd=root, env=env,
                            capture_output=True, text=True, timeout=90)
    if fail is None:
        assert result.returncode == 0, (command, result.stdout, result.stderr)
    else:
        assert result.returncode != 0, ("unexpected success", command)
        assert fail in result.stderr, (fail, result.stderr)
    print("$", " ".join(map(str, command)), "actor="+str(actor), "exit="+str(result.returncode), flush=True)
    if result.stdout:
        print(result.stdout.strip(), flush=True)
    if fail is not None:
        print("EXPECTED:", result.stderr.strip(), flush=True)
    return result


def metadata(name):
    path = root / name
    return path if (path / "format.json").exists() else path / ".myvcs"


def refs(name):
    return json.loads((metadata(name) / "refs-state.json").read_text())["refs"]


def tip(name, branch="main"):
    return refs(name)["refs/heads/"+branch]


def commit(name, text, message):
    (root / name / "shared.txt").write_text(text)
    run("--repo", name, "add", "shared.txt")
    run("--repo", name, "commit", "-m", message)
    return tip(name)


def raw_commit(name, oid):
    return json.loads(zlib.decompress((metadata(name) / "objects" / oid[:2] / oid[2:]).read_bytes()))


run("init", "--bare", "--team", repos / "team")
policy = {"version": 1, "users": {
    "alice": {"read": True, "write": ["refs/heads/*", "refs/tags/*"], "force": ["refs/heads/*"], "delete": ["refs/heads/*", "refs/tags/*"]},
    "bob": {"read": True, "write": ["refs/heads/main", "refs/heads/bob/*"], "force": [], "delete": []},
    "reader": {"read": True, "write": [], "force": [], "delete": []},
}}
(repos / "team/policy.json").write_text(json.dumps(policy))
# Exact gate argument names are checked against the implementation before running.
commands = {name: " ".join(shlex.quote(str(x)) for x in ("/usr/bin/python3", "-I", gate, "--root", repos,
            "--program", binary, "--principal", name)) for name in ("alice", "bob", "reader", "outsider")}
with IsolatedSshd(root / "ssh", commands) as ssh:
    url = f"ssh://{os.environ['USER']}@127.0.0.1:{ssh.port}/team"
    run("clone", url, "a", actor="alice")
    run("--repo", "a", "upgrade", "--quiescent")
    run("--repo", "a", "config", "user.name", "Alice")
    run("--repo", "a", "config", "user.email", "alice@example.test")
    base = commit("a", "one\ntwo\nthree\n", "base")
    run("--repo", "a", "push", actor="alice")
    assert raw_commit("a", base)["author"] == "Alice <alice@example.test>"
    for name, actor in (("b", "bob"), ("r", "reader")):
        run("clone", url, name, actor=actor)
        run("--repo", name, "upgrade", "--quiescent")
    run("clone", url, "denied", actor="outsider", fail="denied")
    run("--repo", "r", "config", "user.name", "alice")
    run("--repo", "r", "config", "user.email", "alice@example.test")
    forged = commit("r", "forged\n", "reader author cannot grant write")
    assert raw_commit("r", forged)["author"] == "alice <alice@example.test>"
    run("--repo", "r", "push", actor="reader", fail="denied")
    assert tip("repositories/team") == base
    a1 = commit("a", "ONE\ntwo\nthree\n", "Alice first line")
    run("--repo", "a", "push", actor="alice")
    b1 = commit("b", "one\ntwo\nTHREE\n", "Bob last line")
    run("--repo", "b", "push", actor="bob", fail="non-fast-forward")
    run("--repo", "b", "pull", actor="bob")
    merged = tip("b")
    assert set(raw_commit("b", merged)["parents"]) == {a1, b1}
    assert (root / "b/shared.txt").read_text() == "ONE\ntwo\nTHREE\n"
    run("--repo", "b", "push", actor="bob")
    run("--repo", "a", "pull", actor="alice")
    run("--repo", "a", "tag", "v1")
    run("--repo", "a", "branch", "release")
    run("--repo", "a", "push", "--atomic", "origin", "main", "release", "refs/tags/v1", actor="alice")
    assert refs("repositories/team")["refs/tags/v1"] == merged
    run("--repo", "b", "fetch", "--tags", actor="bob")
    assert refs("b")["refs/tags/v1"] == merged
    graph = run("--repo", "b", "log", "--graph", "--all").stdout
    assert all(oid in graph for oid in (base, a1, b1, merged))
    run("--repo", "b", "gc")
    run("--repo", "b", "verify")
    run("--repo", "b", "branch", "forbidden")
    run("--repo", "b", "branch", "bob/allowed")
    before = refs("repositories/team")
    run("--repo", "b", "push", "--atomic", "origin", "bob/allowed", "forbidden", actor="bob", fail="denied")
    assert refs("repositories/team") == before
    run("--repo", "b", "fetch", "origin", "release", actor="bob")
    run("--repo", "a", "push", "--atomic", "origin", ":release", actor="alice")
    run("--repo", "b", "fetch", "--prune", actor="bob")
    assert "refs/remotes/origin/release" not in refs("b")
    assert "refs/heads/forbidden" in refs("b") and "refs/tags/v1" in refs("b")
    run("--repo", "a", "reset", "--hard", base)
    rewritten = commit("a", "replacement\n", "controlled rewrite")
    run("--repo", "a", "push", "--force-with-lease", "refs/heads/main:"+base, actor="alice", fail="lease")
    assert tip("repositories/team") == merged
    run("--repo", "a", "push", "--force-with-lease", "refs/heads/main:"+merged, actor="alice")
    assert tip("repositories/team") == rewritten
    # Independent SSH processes race two-ref updates from the same base.
    contenders = []
    for name in ("c", "d"):
        run("clone", url, name, actor="alice")
        run("--repo", name, "upgrade", "--quiescent")
        oid = commit(name, "concurrent " + name + "\n", "concurrent " + name)
        run("--repo", name, "branch", "race")
        contenders.append((name, oid))
    race_env = dict(environment, MYVCS_SSH=ssh.wrapper("alice"))
    jobs = [(name, oid, subprocess.Popen([str(binary), "--repo", name, "push", "--atomic", "origin", "main", "race"],
            cwd=root, env=race_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True))
            for name, oid in contenders]
    winners = []
    for name, oid, job in jobs:
        output, error = job.communicate(timeout=90)
        print("CONCURRENT", name, "exit="+str(job.returncode), output, error, flush=True)
        if job.returncode == 0:
            winners.append(oid)
    assert len(winners) == 1, winners
    assert tip("repositories/team") == tip("repositories/team", "race") == winners[0]
    run("--repo", "a", "push", "--atomic", "origin", ":main", actor="alice", fail="HEAD")
    # Remove the last live ref to the discarded merge: only reflog now protects it.
    run("--repo", "a", "push", "--atomic", "origin", ":refs/tags/v1", actor="alice")
    assert "refs/tags/v1" not in refs("repositories/team")
    # Server GC must retain replaced history through reflog and allow recovery.
    run("--repo", "repositories/team", "gc")
    run("--repo", "repositories/team", "recover", merged, "rescued")
    assert refs("repositories/team")["refs/heads/rescued"] == merged
    audit = run("--repo", "repositories/team", "audit").stdout
    assert "alice" in audit and "bob" in audit and "reader" in audit
    # Forced command prevents supplying another principal or executing a shell.
    rejected = ssh.client("reader", "myvcs serve --repository team --principal alice")
    assert rejected.returncode != 0
    rejected = ssh.client("reader", "echo forged")
    assert rejected.returncode != 0
    run("--repo", "repositories/team", "verify")
    print("PASS real SSH identities, line merge, atomic refs, tags, prune, explicit lease, GC/reflog recovery and audit", flush=True)
print("SSH acceptance workspace:", root)
