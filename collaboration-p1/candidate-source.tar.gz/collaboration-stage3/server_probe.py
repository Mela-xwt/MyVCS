"""Read-only server environment probe, with interactive credentials."""
import getpass
from pathlib import Path
import paramiko
import sys
import shlex

folder = Path(__file__).resolve().parent
client = paramiko.SSHClient()
client.load_host_keys(str(folder.parent / "collaboration-stage2/known_hosts"))
client.connect("192.168.220.129", username="oslab", password=getpass.getpass("SSH password: "),
               allow_agent=False, look_for_keys=False, timeout=15)
try:
    if "--sshd" in sys.argv:
        _, stdout, _ = client.exec_command("mktemp -d /home/oslab/os-lab/myvcs-stage3-probe.XXXXXX")
        remote = stdout.read().decode().strip()
        assert remote.startswith("/home/oslab/os-lab/myvcs-stage3-probe.")
        client.open_sftp().put(str(folder / "isolated_sshd.py"), remote + "/isolated_sshd.py")
        command = "python3 " + shlex.quote(remote + "/isolated_sshd.py")
        log = "server-sshd-probe.log"
    else:
        command = "uname -a; id; command -v sshd; command -v ssh-keygen; ls /usr/sbin/sshd"
        log = "server-probe.log"
    _, stdout, _ = client.exec_command("{ " + command + "; } 2>&1")
    data = stdout.read().decode("utf-8")
    (folder / log).write_text(data, encoding="utf-8")
    print(data)
    sys.exit(stdout.channel.recv_exit_status())
finally:
    client.close()
