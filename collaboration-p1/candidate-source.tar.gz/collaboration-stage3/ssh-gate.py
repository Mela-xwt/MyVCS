#!/usr/bin/env python3
"""OpenSSH forced command. Invoke with python3 -I and operator-owned fixed flags."""
import argparse
import os
from pathlib import Path
import re
import shlex
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--program", required=True)
    parser.add_argument("--principal", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9._@-]{1,128}", args.principal):
        raise ValueError("invalid fixed principal")
    root_arg, program_arg = Path(args.root), Path(args.program)
    if not root_arg.is_absolute() or not program_arg.is_absolute():
        raise ValueError("root and program must be absolute operator paths")
    root = root_arg.resolve(strict=True)
    program = program_arg.resolve(strict=True)
    command = os.environ.get("SSH_ORIGINAL_COMMAND", "")
    if len(command) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in command):
        raise ValueError("invalid requested command")
    words = shlex.split(command, posix=True)
    if len(words) != 4 or words[:3] != ["myvcs", "serve", "--repository"]:
        raise ValueError("only myvcs serve --repository <id> is allowed")
    repository = words[3]
    if len(repository) > 1024 or any(
        not re.fullmatch(r"[A-Za-z0-9._][A-Za-z0-9._-]*", part)
        or part in (".", "..") for part in repository.split("/")
    ):
        raise ValueError("invalid repository identifier")
    candidate = root / repository
    current = root
    for part in repository.split("/"):
        current = current / part
        if current.is_symlink():
            raise ValueError("repository symlinks are forbidden")
    actual = candidate.resolve(strict=True)
    if actual == root or root not in actual.parents or not actual.is_dir():
        raise ValueError("repository is outside fixed root")
    # The incoming SSH environment cannot select a binary, policy actor or loader.
    env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "MYVCS_PRINCIPAL": args.principal,
           "MYVCS_TRANSFER_TIMEOUT": "300"}
    os.execve(str(program), [str(program), "serve", "--root", str(root),
                             "--repository", repository], env)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print(f"SSH service denied: {error}", file=sys.stderr)
        sys.exit(1)
