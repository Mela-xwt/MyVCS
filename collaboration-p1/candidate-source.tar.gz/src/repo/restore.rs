use super::*;
use serde::Deserialize;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct WorkJournal {
    version: u32,
    head: String,
    head_oid: Option<String>,
    pin: String,
    pin_oid: String,
    rollback: bool,
    before: BTreeMap<String, Option<String>>,
    after: BTreeMap<String, Option<String>>,
    index_before: Index,
    index_after: Index,
}

impl Repo {
    pub(super) fn no_pending_work(&self) -> Result<()> {
        let p = self.meta.join("work-journal.json");
        self.check_internal_path(&p)?;
        if p.exists() {
            bail!(
                "unfinished worktree operation: run recover-worktree or recover-worktree --abort"
            );
        }
        Ok(())
    }

    pub(super) fn no_merge_operation(&self) -> Result<()> {
        if self.read_merge_state()?.is_some()
            || self.read_merge_head()?.is_some()
            || !self.read_merge_conflicts()?.is_empty()
        {
            bail!("unfinished merge; resolve or abort it first");
        }
        Ok(())
    }

    pub(super) fn next_tree(&self, index: &Index) -> Result<BTreeMap<String, String>> {
        let mut tree = self.head_tree()?;
        for name in &index.removed {
            tree.remove(name);
        }
        tree.extend(index.entries.clone());
        self.validate_tree(&tree)?;
        Ok(tree)
    }

    pub(super) fn work_oid(&self, name: &str) -> Result<Option<String>> {
        let p = self.work_path(name)?;
        if !p.exists() {
            return Ok(None);
        }
        if !p.is_file() {
            bail!("file/directory collision: {name}");
        }
        Ok(Some(hex_sha256_file(&p)?))
    }

    pub(super) fn snapshot_commit(
        &self,
        tree: BTreeMap<String, String>,
        parents: Vec<String>,
        message: String,
    ) -> Result<String> {
        self.validate_tree(&tree)?;
        let bytes = serde_json::to_vec(&Commit {
            tree,
            parents,
            parent: None,
            message,
            author: "MyVCS local snapshot".into(),
            timestamp: now_unix() as i64,
        })?;
        if bytes.len() > self.limits.metadata_bytes {
            bail!("snapshot metadata limit exceeded");
        }
        self.write_object(&bytes)
    }

    // A durable pin protects both sides, including from an older version's GC.
    pub(super) fn change_worktree(
        &self,
        after: BTreeMap<String, Option<String>>,
        index_after: Index,
    ) -> Result<()> {
        self.no_pending_work()?;
        let mut before = BTreeMap::new();
        for (name, oid) in &after {
            let path = self.work_path(name)?;
            if path.exists() && !path.is_file() {
                bail!("file/directory collision: {name}");
            }
            if let Some(id) = oid {
                self.read_blob_resolved(id)?;
            }
            for parent in path.ancestors().skip(1).take_while(|p| *p != self.root) {
                if parent.exists() && !parent.is_dir() {
                    bail!("file/directory collision: {name}");
                }
            }
            before.insert(
                name.clone(),
                if path.exists() {
                    Some(self.write_object_from_path(&path)?)
                } else {
                    None
                },
            );
        }
        self.validate_tree(&index_after.entries)?;
        for name in &index_after.removed {
            validate_tree_path(name)?;
        }
        if serde_json::to_vec_pretty(&index_after)?.len() > self.limits.metadata_bytes {
            bail!("index size limit exceeded");
        }
        let index_before = self.read_index()?;
        let mut parents = Vec::new();
        for tree in [&before, &after] {
            parents.push(
                self.snapshot_commit(
                    tree.iter()
                        .filter_map(|(p, id)| id.clone().map(|id| (p.clone(), id)))
                        .collect(),
                    vec![],
                    "worktree recovery".into(),
                )?,
            );
        }
        for idx in [&index_before, &index_after] {
            parents.push(self.snapshot_commit(
                idx.entries.clone(),
                vec![],
                "index recovery".into(),
            )?);
        }
        let pin_oid =
            self.snapshot_commit(BTreeMap::new(), parents, "worktree journal roots".into())?;
        let pin = format!("refs/pins/work-{}", unique_suffix());
        let journal = WorkJournal {
            version: 1,
            head: self.head_raw()?,
            head_oid: self.head_commit_id()?,
            pin: pin.clone(),
            pin_oid: pin_oid.clone(),
            rollback: false,
            before,
            after,
            index_before,
            index_after,
        };
        if serde_json::to_vec_pretty(&journal)?.len() > self.limits.metadata_bytes {
            bail!("worktree recovery journal limit exceeded");
        }
        self.apply_local_changes_locked(
            &[RefChange {
                name: pin,
                expected: None,
                new: Some(pin_oid),
            }],
            "worktree recovery pin",
        )?;
        self.atomic_write_json(&self.meta.join("work-journal.json"), &journal)?;
        self.work_checkpoint("prepared");
        self.finish_worktree(false)
    }

    fn work_checkpoint(&self, phase: &str) {
        // Fault injection uses a repository-local marker, never a remote request.
        #[cfg(debug_assertions)]
        if fs::read_to_string(self.meta.join("test-work-crash"))
            .ok()
            .as_deref()
            == Some(phase)
        {
            std::process::exit(86);
        }
        let _ = phase;
    }

    pub fn recover_worktree(&self, abort: bool) -> Result<()> {
        self.with_repo_lock_unchecked(|r| r.finish_worktree(abort))
    }

    fn finish_worktree(&self, abort: bool) -> Result<()> {
        self.require_worktree()?;
        let p = self.meta.join("work-journal.json");
        let mut j: WorkJournal = serde_json::from_str(&self.read_metadata(&p)?)?;
        if j.version != 1 || j.head != self.head_raw()? || j.head_oid != self.head_commit_id()? {
            bail!("recovery HEAD/version mismatch");
        }
        validate_ref(&j.pin)?;
        if !j.pin.starts_with("refs/pins/work-") {
            bail!("invalid recovery pin");
        }
        if j.before.keys().ne(j.after.keys()) {
            bail!("invalid recovery path set");
        }
        self.validate_tree(&j.index_before.entries)?;
        self.validate_tree(&j.index_after.entries)?;
        for name in j.index_before.removed.iter().chain(&j.index_after.removed) {
            validate_tree_path(name)?;
        }
        self.validate_closure(&j.pin_oid)?;
        for (name, before) in &j.before {
            let after = &j.after[name];
            let current = self.work_oid(name)?;
            if &current != before && &current != after {
                bail!("recovery refuses new edits at {name}; preserve them elsewhere first");
            }
            for id in [before, after].into_iter().flatten() {
                self.read_blob_resolved(id)?;
            }
        }
        let index = serde_json::to_value(self.read_index()?)?;
        if index != serde_json::to_value(&j.index_before)?
            && index != serde_json::to_value(&j.index_after)?
        {
            bail!("index changed since interrupted operation");
        }
        j.rollback |= abort;
        self.atomic_write_json(&p, &j)?;
        let target = if j.rollback { &j.before } else { &j.after };
        for (name, oid) in target {
            let path = self.work_path(name)?;
            if let Some(id) = oid {
                self.atomic_write(&path, &self.read_blob_resolved(id)?)?;
            } else if path.exists() {
                fs::remove_file(&path)?;
                sync_directory(path.parent().unwrap())?;
            }
            self.work_checkpoint("file");
        }
        self.write_index(if j.rollback {
            &j.index_before
        } else {
            &j.index_after
        })?;
        self.work_checkpoint("index");
        self.write_status_cache(&StatusCache::default())?;
        // Journal is removed first; an orphan pin after a crash is safe retention.
        fs::remove_file(&p)?;
        sync_directory(&self.meta)?;
        self.apply_local_changes_locked(
            &[RefChange {
                name: j.pin,
                expected: Some(j.pin_oid),
                new: None,
            }],
            "finish worktree recovery",
        )?;
        Ok(())
    }

    pub fn restore_file(&self, raw: &str, source: Option<&str>, staged: bool) -> Result<()> {
        self.require_worktree()?;
        self.no_merge_operation()?;
        let path = self.input_path(raw)?;
        let name = self.work_name(&path)?;
        validate_tree_path(&name)?;
        let tree = match source {
            Some(s) => self.read_commit(&self.resolve_commit(s)?)?.tree,
            None => self.head_tree()?,
        };
        let mut index = self.read_index()?;
        let head = self.head_tree()?;
        if !tree.contains_key(&name)
            && !head.contains_key(&name)
            && !index.entries.contains_key(&name)
            && !index.removed.contains(&name)
        {
            bail!("path is not tracked in source or index: {name}");
        }
        if staged {
            index.entries.remove(&name);
            index.removed.remove(&name);
            match tree.get(&name) {
                Some(id) if head.get(&name) != Some(id) => {
                    self.read_blob_resolved(id)?;
                    index.entries.insert(name.clone(), id.clone());
                }
                None if head.contains_key(&name) => {
                    index.removed.insert(name.clone());
                }
                _ => {}
            }
            if serde_json::to_vec_pretty(&index)?.len() > self.limits.metadata_bytes {
                bail!("index size limit exceeded");
            }
            self.write_index(&index)?;
        } else {
            if path.exists()
                && ((!head.contains_key(&name) && !index.entries.contains_key(&name))
                    || index.removed.contains(&name))
            {
                bail!("untracked/recreated path would be overwritten: {name}");
            }
            self.change_worktree(
                BTreeMap::from([(name.clone(), tree.get(&name).cloned())]),
                index,
            )?;
        }
        println!(
            "restored {name}{}",
            if staged { " (index)" } else { " (worktree)" }
        );
        Ok(())
    }

    pub fn diff_staged(&self, path: Option<&str>) -> Result<()> {
        self.require_worktree()?;
        let old = self.head_tree()?;
        let new = self.next_tree(&self.read_index()?)?;
        let names: BTreeSet<String> = match path {
            Some(p) => BTreeSet::from([self.work_name(&self.input_path(p)?)?]),
            None => old.keys().chain(new.keys()).cloned().collect(),
        };
        for p in names {
            validate_tree_path(&p)?;
            if old.get(&p) == new.get(&p) {
                continue;
            }
            let a = old
                .get(&p)
                .map(|id| self.read_blob_resolved(id))
                .transpose()?;
            let b = new
                .get(&p)
                .map(|id| self.read_blob_resolved(id))
                .transpose()?;
            println!("diff --staged -- {p}");
            print_text_diff_or_binary(&p, a.as_deref(), b.as_deref());
        }
        Ok(())
    }
}
