use super::*;
use crate::util::{
    BlobTemperature, advise_cold_blob, categorize_blob_temperature, detect_fs_type,
    detect_numa_topology,
};

impl Repo {
    // 标记可达对象，优化部分 blob，然后清理不可达对象。
    pub fn gc(&self) -> Result<()> {
        crate::util::maybe_set_background_nice();
        crate::debug_log!("gc start");

        // openEuler 优化：采集 FS/NUMA 信息用于调优决策
        if crate::util::should_enable_openeuler_io_hints() {
            let fs = detect_fs_type(&self.root);
            let numa = detect_numa_topology();
            crate::debug_log!(
                "gc env fs={} numa_nodes={} io_chunk={}",
                fs,
                numa.node_count,
                crate::util::io_chunk_size_bytes()
            );
        }

        let (reachable, _, _) = self.protected_objects()?;

        let optimized = if crate::util::should_run_deep_delta_gc() {
            self.optimize_reachable_blobs_with_delta(&reachable)?
        } else {
            println!("gc: deep-delta optimization skipped by load-aware policy");
            0
        };

        if crate::util::should_enable_openeuler_io_hints() {
            let blob_latest_ts = self.collect_blob_latest_timestamps()?;
            let mut cold_hinted = 0usize;
            for (oid, ts) in blob_latest_ts {
                if categorize_blob_temperature(ts) != BlobTemperature::Cold {
                    continue;
                }
                let Ok(path) = self.object_path(&oid) else {
                    continue;
                };
                if let Ok(f) = File::open(&path) {
                    advise_cold_blob(&f);
                    cold_hinted += 1;
                }
            }
            if cold_hinted > 0 {
                crate::debug_log!("gc cold-hinted {} reachable cold blob(s)", cold_hinted);
            }
        }

        let all = self.all_object_ids()?;
        let mut removed = 0usize;

        for oid in all {
            if !reachable.contains(&oid) {
                let p = self.object_path(&oid)?;
                if p.exists() {
                    fs::remove_file(&p)?;
                    removed += 1;
                }
            }
        }

        println!(
            "gc completed: optimized {} blob(s), removed {} unreachable object(s)",
            optimized, removed
        );
        crate::debug_log!(
            "gc done reachable={} optimized={} removed={}",
            reachable.len(),
            optimized,
            removed
        );
        Ok(())
    }

    pub fn verify(&self) -> Result<()> {
        let (objects, commits, blobs) = self.protected_objects()?;
        println!(
            "verify ok: {} commit(s), {} blob reference(s), {} reachable object(s)",
            commits,
            blobs,
            objects.len()
        );
        Ok(())
    }

    pub(super) fn commit_roots(&self) -> Result<Vec<String>> {
        let snapshot = self.refs_snapshot()?;
        let mut roots: Vec<_> = snapshot.refs.values().cloned().collect();
        for entry in &snapshot.reflog {
            roots.extend(entry.old.clone());
            roots.extend(entry.new.clone());
        }
        if let Some(id) = snapshot.head_commit_id() {
            roots.push(id);
        }
        if let Some(id) = self.read_merge_head()? {
            roots.push(id);
        }
        // The journal precedes MERGE_HEAD and survives interrupted abort cleanup.
        if let Some(state) = self.read_merge_state()? {
            roots.push(state.original_head);
            roots.push(state.target);
        }
        let fetch_head = self.meta.join("FETCH_HEAD");
        self.check_internal_path(&fetch_head)?;
        if fetch_head.exists() {
            let raw = self.read_metadata(&fetch_head)?;
            let (id, name) = raw
                .trim_end_matches('\n')
                .split_once('\t')
                .context("invalid FETCH_HEAD")?;
            validate_ref(name)?;
            if !id.is_empty() {
                validate_oid(id)?;
                roots.push(id.to_owned());
            }
        }
        Ok(roots)
    }

    pub(super) fn validate_closure(&self, id: &str) -> Result<BTreeSet<String>> {
        let mut marked = BTreeSet::new();
        self.mark_commits(vec![id.to_owned()], &mut marked)?;
        Ok(marked)
    }

    pub(super) fn protected_objects(&self) -> Result<(BTreeSet<String>, usize, usize)> {
        let mut marked = BTreeSet::new();
        let (commits, mut blobs) = self.mark_commits(self.commit_roots()?, &mut marked)?;
        if !self.bare {
            for oid in self.read_index()?.entries.values() {
                self.mark_object(oid, &mut marked)?;
                blobs += 1;
            }
        }
        Ok((marked, commits, blobs))
    }

    // Include physical delta dependencies even when their old commits are gone.
    fn mark_object(&self, start: &str, marked: &mut BTreeSet<String>) -> Result<()> {
        if marked.contains(start) {
            return Ok(());
        }
        self.read_blob_resolved(start)?;
        let mut id = start.to_owned();
        loop {
            if !marked.insert(id.clone()) {
                break;
            }
            self.check_graph_size(marked.len())?;
            let raw = self.read_object(&id)?;
            match self.stored_delta(&id, &raw)? {
                Some(delta) => id = delta.base,
                None => break,
            }
        }
        Ok(())
    }

    fn mark_commits(
        &self,
        mut stack: Vec<String>,
        marked: &mut BTreeSet<String>,
    ) -> Result<(usize, usize)> {
        let mut commits = BTreeSet::new();
        let mut blobs = 0;
        while let Some(id) = stack.pop() {
            if !commits.insert(id.clone()) {
                continue;
            }
            self.check_graph_size(commits.len())?;
            let commit = self.read_commit(&id)?;
            self.mark_object(&id, marked)?;
            for oid in commit.tree.values() {
                self.mark_object(oid, marked)?;
                blobs += 1;
            }
            stack.extend(Self::commit_parents(&commit));
        }
        Ok((commits.len(), blobs))
    }

    // 遍历可达提交，收集 blob 的最新提交时间戳。
    fn collect_blob_latest_timestamps(&self) -> Result<BTreeMap<String, i64>> {
        let mut out = BTreeMap::new();
        let mut commit_stack = self.commit_roots()?;

        let mut seen_commits = BTreeSet::new();
        while let Some(id) = commit_stack.pop() {
            if !seen_commits.insert(id.clone()) {
                continue;
            }
            let commit = self.read_commit(&id)?;
            for oid in commit.tree.values() {
                let entry = out.entry(oid.clone()).or_insert(commit.timestamp);
                if commit.timestamp > *entry {
                    *entry = commit.timestamp;
                }
            }
            for p in Self::commit_parents(&commit) {
                commit_stack.push(p);
            }
        }
        Ok(out)
    }

    // 枚举对象库存储的全部对象 ID。
    pub(super) fn all_object_ids(&self) -> Result<Vec<String>> {
        let mut out = Vec::new();
        let base = self.objects_dir();
        if !base.exists() {
            return Ok(out);
        }

        for d in fs::read_dir(&base)? {
            let d = d?;
            let prefix = d.file_name().to_string_lossy().to_string();
            self.check_internal_path(&d.path())?;
            if prefix.len() != 2
                || !prefix
                    .bytes()
                    .all(|c| c.is_ascii_hexdigit() && !c.is_ascii_uppercase())
                || !d.path().is_dir()
            {
                continue;
            }
            for f in fs::read_dir(d.path())? {
                let f = f?;
                self.check_internal_path(&f.path())?;
                if f.path().is_file() {
                    let name = f.file_name().to_string_lossy().to_string();
                    let id = format!("{}{}", prefix, name);
                    if validate_oid(&id).is_ok() {
                        out.push(id);
                    }
                }
            }
        }

        out.sort();
        Ok(out)
    }

    // 当压缩后更小且收益足够时，将可达 blob 重编码为 delta。
    fn optimize_reachable_blobs_with_delta(&self, reachable: &BTreeSet<String>) -> Result<usize> {
        let mut optimized = 0usize;
        let mut done_targets = BTreeSet::new();
        // Existing reverse dependencies must never grow when their base is rewritten.
        let mut bases_in_use = BTreeSet::new();
        for oid in reachable {
            if let Some(d) = self.stored_delta(oid, &self.read_object(oid)?)? {
                bases_in_use.insert(d.base);
            }
        }

        let mut commit_stack = self.commit_roots()?;

        let mut order = Vec::new();
        let mut visited = BTreeSet::new();
        let mut walk: Vec<_> = commit_stack.drain(..).map(|id| (id, false)).collect();
        while let Some((id, expanded)) = walk.pop() {
            if expanded {
                order.push(id);
                continue;
            }
            if !visited.insert(id.clone()) {
                continue;
            }
            let c = self.read_commit(&id)?;
            walk.push((id, true));
            for parent in Self::commit_parents(&c) {
                walk.push((parent, false));
            }
        }
        let mut seen_commits = BTreeSet::new();
        for id in order {
            if !seen_commits.insert(id.clone()) {
                continue;
            }

            let c = self.read_commit(&id)?;
            let parents = Self::commit_parents(&c);
            if let Some(parent_id) = parents.first() {
                let parent = self.read_commit(parent_id)?;
                for (path, target_oid) in &c.tree {
                    if !reachable.contains(target_oid)
                        || done_targets.contains(target_oid)
                        || bases_in_use.contains(target_oid)
                    {
                        continue;
                    }
                    let Some(base_oid) = parent.tree.get(path) else {
                        continue;
                    };
                    if base_oid == target_oid {
                        continue;
                    }
                    if !reachable.contains(base_oid) {
                        continue;
                    }

                    let current_raw = self.read_object(target_oid)?;
                    if self.stored_delta(target_oid, &current_raw)?.is_some() {
                        done_targets.insert(target_oid.clone());
                        continue;
                    }

                    // Never introduce a cycle or exceed the reader's chain budget.
                    let mut dependency = base_oid.clone();
                    let mut chain = BTreeSet::new();
                    let mut chain_bytes = current_raw.len();
                    loop {
                        if !chain.insert(dependency.clone()) {
                            bail!("delta dependency cycle");
                        }
                        let raw = self.read_object(&dependency)?;
                        chain_bytes = chain_bytes.saturating_add(raw.len());
                        if let Some(d) = self.stored_delta(&dependency, &raw)? {
                            chain_bytes = chain_bytes.saturating_add(d.size);
                            dependency = d.base;
                        } else {
                            break;
                        }
                    }
                    if chain.contains(target_oid)
                        || chain.len() + 1 > self.limits.delta_depth.min(8)
                    {
                        continue;
                    }
                    let base = self.read_blob_resolved(base_oid)?;
                    let target = current_raw;
                    let ops = build_delta(&base, &target);
                    if ops.is_empty() {
                        done_targets.insert(target_oid.clone());
                        continue;
                    }

                    let delta_blob = DeltaBlob {
                        base: base_oid.clone(),
                        ops,
                        size: target.len(),
                    };
                    let encoded = encode_delta_blob(&delta_blob)?;
                    if encoded.len() > self.limits.object_bytes
                        || delta_blob.ops.len() > self.limits.delta_ops
                        || chain_bytes.saturating_add(encoded.len()) > self.limits.chain_bytes
                    {
                        continue;
                    }

                    // 比较真实磁盘大小；候选按最终 Cold 级别只压缩一次。
                    let target_path = self.object_path(target_oid)?;
                    let stored_size = fs::metadata(&target_path)
                        .with_context(|| format!("failed to stat object {}", target_oid))?
                        .len();
                    let compressed_new = compress_bytes(
                        &encoded,
                        crate::util::adaptive_compression(BlobTemperature::Cold),
                    )?;
                    if (compressed_new.len() as u64).saturating_add(16) >= stored_size {
                        done_targets.insert(target_oid.clone());
                        continue;
                    }

                    // 写入刚才参与收益比较的同一份字节，保留原子替换语义。
                    let restored = crate::util::apply_delta_limited(
                        &base,
                        &delta_blob.ops,
                        self.limits.object_bytes,
                    )?;
                    if hex_sha256(&restored) != *target_oid {
                        bail!("GC candidate hash mismatch");
                    }
                    self.atomic_write_object(&target_path, &compressed_new)?;
                    bases_in_use.insert(base_oid.clone());
                    optimized += 1;
                    done_targets.insert(target_oid.clone());
                }
            }

            for p in parents {
                commit_stack.push(p);
            }
        }

        Ok(optimized)
    }
}
