use super::*;

pub(super) struct IgnoreRules(Vec<(usize, String, String, bool, bool)>);

// Bounded dynamic programming: '*' stays in a component; '**' crosses '/'.
fn matches(pattern: &str, text: &str) -> bool {
    let p: Vec<char> = pattern.chars().collect();
    let t: Vec<char> = text.chars().collect();
    let mut prev = vec![false; t.len() + 1];
    prev[0] = true;
    let mut i = 0;
    while i < p.len() {
        let mut next = vec![false; t.len() + 1];
        if p[i] == '*' {
            let double = i + 1 < p.len() && p[i + 1] == '*';
            if double {
                i += 1;
            }
            next[0] = prev[0];
            for j in 1..=t.len() {
                next[j] = prev[j] || (next[j - 1] && (double || t[j - 1] != '/'));
            }
        } else {
            for j in 1..=t.len() {
                next[j] = prev[j - 1] && (p[i] == t[j - 1] || (p[i] == '?' && t[j - 1] != '/'));
            }
        }
        prev = next;
        i += 1;
    }
    prev[t.len()]
}

impl IgnoreRules {
    pub(super) fn decision(&self, name: &str, is_dir: bool) -> Option<(usize, &str, bool)> {
        let parts: Vec<_> = name.split('/').collect();
        let mut result = None;
        for (line, original, pattern, negative, directory) in &self.0 {
            let anchored = pattern.starts_with('/');
            let pat = pattern.trim_start_matches('/');
            let hit = (1..=parts.len()).any(|n| {
                if *directory && n == parts.len() && !is_dir {
                    return false;
                }
                if anchored || pat.contains('/') {
                    matches(pat, &parts[..n].join("/"))
                } else {
                    matches(pat, parts[n - 1])
                }
            });
            if hit {
                result = Some((*line, original.as_str(), !negative));
            }
        }
        result
    }
    pub(super) fn ignored(&self, name: &str) -> bool {
        self.decision(name, false)
            .is_some_and(|(_, _, ignored)| ignored)
    }
}

impl Repo {
    pub(super) fn ignore_rules(&self) -> Result<IgnoreRules> {
        self.require_worktree()?;
        let p = self.work_path(".myvcsignore")?;
        let mut rules = Vec::new();
        if p.exists() {
            let raw = self.read_metadata(&p)?;
            for (i, line) in raw.lines().enumerate() {
                let line = line.trim_end_matches('\r');
                if line.is_empty() || line.starts_with('#') {
                    continue;
                }
                if rules.len() >= 1024 || line.len() > 512 {
                    bail!("ignore rule limit exceeded");
                }
                let negative = line.starts_with('!');
                let pattern = if negative { &line[1..] } else { line };
                if pattern.is_empty() || pattern.contains(['[', ']', '\\']) {
                    bail!("unsupported ignore pattern at .myvcsignore:{}", i + 1);
                }
                rules.push((
                    i + 1,
                    line.to_owned(),
                    pattern.trim_end_matches('/').to_owned(),
                    negative,
                    pattern.ends_with('/'),
                ));
            }
        }
        Ok(IgnoreRules(rules))
    }

    pub fn check_ignore(&self, paths: &[String]) -> Result<()> {
        let rules = self.ignore_rules()?;
        let tracked = tracked_working_set(&self.head_tree()?, &self.read_index()?);
        for raw in paths {
            let path = self.input_path(raw)?;
            let name = self.work_name(&path)?;
            if tracked.contains(&name) {
                println!("tracked\t{name}");
                continue;
            }
            if let Some((line, rule, ignored)) = rules.decision(&name, path.is_dir()) {
                println!(
                    "{}\t.myvcsignore:{line}\t{rule}\t{name}",
                    if ignored { "ignored" } else { "included" }
                );
            } else {
                println!("included\t{name}");
            }
        }
        Ok(())
    }
}
