use super::*;
use serde::Deserialize;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct StashInfo {
    version: u32,
    message: String,
    base: Option<String>,
    index: Index,
    untracked: BTreeMap<String, String>,
}

// Conservative three-way restoration. Conflicting paths cause no mutation.
fn combine(
    base: &BTreeMap<String, String>,
    current: &BTreeMap<String, String>,
    saved: &BTreeMap<String, String>,
) -> Result<BTreeMap<String, String>> {
    let names: BTreeSet<_> = base
        .keys()
        .chain(current.keys())
        .chain(saved.keys())
        .collect();
    let mut result = BTreeMap::new();
    for name in names {
        let b = base.get(name);
        let c = current.get(name);
        let s = saved.get(name);
        let value = if s == b {
            c
        } else if c == b || c == s {
            s
        } else {
            bail!("stash conflict at {name}; snapshot retained, no files changed");
        };
        if let Some(id) = value {
            result.insert(name.clone(), id.clone());
        }
    }
    Ok(result)
}

impl Repo {
    fn stash_refs(&self) -> Result<Vec<(String, String)>> {
        let mut refs: Vec<_> = self
            .list_refs()?
            .into_iter()
            .filter(|(n, _)| n.starts_with("refs/pins/stash/"))
            .collect();
        refs.reverse();
        Ok(refs)
    }
    fn select_stash(&self, selector: &str) -> Result<(String, String)> {
        let refs = self.stash_refs()?;
        if let Ok(n) = selector.parse::<usize>() {
            return refs.get(n).cloned().context("stash index out of range");
        }
        refs.into_iter()
            .find(|(n, _)| n.strip_prefix("refs/pins/stash/") == Some(selector))
            .context("unknown stash ID")
    }
    fn read_stash(&self, id: &str) -> Result<(Commit, StashInfo)> {
        self.validate_closure(id)?;
        let commit = self.read_commit(id)?;
        let info: StashInfo =
            serde_json::from_str(&commit.message).context("invalid stash metadata")?;
        if info.version != 1 {
            bail!("unsupported stash version");
        }
        self.validate_tree(&info.index.entries)?;
        self.validate_tree(&info.untracked)?;
        for n in &info.index.removed {
            validate_tree_path(n)?;
        }
        if let Some(base) = &info.base {
            self.read_commit(base)?;
        }
        for oid in info.index.entries.values().chain(info.untracked.values()) {
            self.read_blob_resolved(oid)?;
        }
        Ok((commit, info))
    }
    pub fn stash_list(&self) -> Result<()> {
        for (n, (name, id)) in self.stash_refs()?.iter().enumerate() {
            let (_, info) = self.read_stash(id)?;
            println!(
                "{n}\t{}\t{}\t{}",
                name.trim_start_matches("refs/pins/stash/"),
                short_id(id),
                serde_json::to_string(&info.message)?
            );
        }
        Ok(())
    }
    pub fn stash_show(&self, selector: &str) -> Result<()> {
        let (_, id) = self.select_stash(selector)?;
        let (c, info) = self.read_stash(&id)?;
        let base = info
            .base
            .as_ref()
            .map(|id| self.read_commit(id).map(|c| c.tree))
            .transpose()?
            .unwrap_or_default();
        let names: BTreeSet<_> = base
            .keys()
            .chain(c.tree.keys())
            .chain(info.index.entries.keys())
            .chain(info.index.removed.iter())
            .chain(info.untracked.keys())
            .collect();
        println!("stash {id}: {}", serde_json::to_string(&info.message)?);
        for p in names {
            if base.get(p) != c.tree.get(p)
                || info.index.entries.contains_key(p)
                || info.index.removed.contains(p)
                || info.untracked.contains_key(p)
            {
                println!(
                    "{}\t{p}",
                    if info.untracked.contains_key(p) {
                        "untracked"
                    } else {
                        "tracked/index"
                    }
                );
            }
        }
        Ok(())
    }
    pub fn stash_push(&self, message: &str, include_untracked: bool) -> Result<()> {
        self.require_worktree()?;
        self.no_merge_operation()?;
        let head = self.head_tree()?;
        let index = self.read_index()?;
        let staged = self.next_tree(&index)?;
        let tracked = tracked_working_set(&head, &index);
        let mut work = BTreeMap::new();
        for name in &tracked {
            let p = self.work_path(name)?;
            if p.exists() {
                if !p.is_file() {
                    bail!("file/directory conflict: {name}");
                }
                work.insert(name.clone(), self.write_object_from_path(&p)?);
            }
        }
        let mut untracked = BTreeMap::new();
        if include_untracked {
            for name in self.tracked_working_files()? {
                if !tracked.contains(&name) {
                    untracked.insert(
                        name.clone(),
                        self.write_object_from_path(&self.work_path(&name)?)?,
                    );
                }
            }
        }
        if work == head && staged == head && untracked.is_empty() {
            println!("no local changes to save");
            return Ok(());
        }
        let info = StashInfo {
            version: 1,
            message: message.into(),
            base: self.head_commit_id()?,
            index,
            untracked,
        };
        let mut parents: Vec<_> = info.base.clone().into_iter().collect();
        parents.push(self.snapshot_commit(
            info.index.entries.clone(),
            vec![],
            "stash index objects".into(),
        )?);
        parents.push(self.snapshot_commit(
            info.untracked.clone(),
            vec![],
            "stash untracked objects".into(),
        )?);
        let oid = self.snapshot_commit(work, parents, serde_json::to_string(&info)?)?;
        let time = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)?
            .as_nanos();
        let name = format!("refs/pins/stash/{time:032}-{}", unique_suffix());
        self.apply_local_changes_locked(
            &[RefChange {
                name: name.clone(),
                expected: None,
                new: Some(oid),
            }],
            "stash push",
        )?;
        let changes = tracked
            .iter()
            .chain(info.untracked.keys())
            .map(|n| (n.clone(), head.get(n).cloned()))
            .collect();
        self.change_worktree(changes, Index::default())?;
        println!(
            "saved stash {}",
            name.trim_start_matches("refs/pins/stash/")
        );
        Ok(())
    }
    pub fn stash_apply(&self, selector: &str, pop: bool) -> Result<()> {
        self.require_worktree()?;
        self.no_merge_operation()?;
        let (name, id) = self.select_stash(selector)?;
        let (c, info) = self.read_stash(&id)?;
        let head = self.head_tree()?;
        let idx = self.read_index()?;
        if !idx.entries.is_empty() || !idx.removed.is_empty() {
            bail!("stash apply requires clean index");
        }
        for (p, oid) in &head {
            if self.work_oid(p)?.as_ref() != Some(oid) {
                bail!("stash apply would overwrite local changes: {p}");
            }
        }
        let base = info
            .base
            .as_ref()
            .map(|id| self.read_commit(id).map(|c| c.tree))
            .transpose()?
            .unwrap_or_default();
        let mut staged = base.clone();
        for n in &info.index.removed {
            staged.remove(n);
        }
        staged.extend(info.index.entries.clone());
        let next_index = combine(&base, &head, &staged)?;
        let mut next_work = combine(&base, &head, &c.tree)?;
        for (n, oid) in &info.untracked {
            if head.contains_key(n) || next_work.contains_key(n) || self.work_path(n)?.exists() {
                bail!("untracked stash conflict: {n}");
            }
            next_work.insert(n.clone(), oid.clone());
        }
        self.validate_tree(&next_work)?;
        self.validate_tree(&next_index)?;
        let names: BTreeSet<_> = head
            .keys()
            .chain(next_work.keys())
            .chain(next_index.keys())
            .cloned()
            .collect();
        for n in &names {
            if !head.contains_key(n) && self.work_path(n)?.exists() {
                bail!("untracked path would be overwritten: {n}");
            }
        }
        let index = if info.base == self.head_commit_id()? {
            info.index
        } else {
            Index {
                entries: next_index
                    .iter()
                    .filter(|(p, id)| head.get(*p) != Some(*id))
                    .map(|(p, id)| (p.clone(), id.clone()))
                    .collect(),
                removed: head
                    .keys()
                    .filter(|p| !next_index.contains_key(*p))
                    .cloned()
                    .collect(),
            }
        };
        self.change_worktree(
            names
                .iter()
                .map(|n| (n.clone(), next_work.get(n).cloned()))
                .collect(),
            index,
        )?;
        if pop {
            self.apply_local_changes_locked(
                &[RefChange {
                    name,
                    expected: Some(id),
                    new: None,
                }],
                "stash pop",
            )?;
        }
        println!(
            "stash restored{}",
            if pop {
                " and removed"
            } else {
                "; snapshot retained"
            }
        );
        Ok(())
    }
    pub fn stash_drop(&self, selector: &str) -> Result<()> {
        let (name, id) = self.select_stash(selector)?;
        self.apply_local_changes_locked(
            &[RefChange {
                name,
                expected: Some(id),
                new: None,
            }],
            "stash drop",
        )?;
        println!("stash dropped; retained reflog may still protect its objects");
        Ok(())
    }
}
